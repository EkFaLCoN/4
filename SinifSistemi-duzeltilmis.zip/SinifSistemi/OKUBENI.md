# Sınıf Sistemi — %100 Türkçe Minecraft Class Eklentisi

Paper/Spigot sunucuları için sıfırdan yazılmış, tamamen Türkçe bir sınıf (class) sistemi.
Oyuncular sunucuya girdiğinde bir GUI açılır ve **hayatlarında yalnızca bir kez** sınıf seçerler.

---

## Sınıflar

| Sıra | Sınıf | Menü Simgesi |
|------|-------|--------------|
| 1 | **Savaşçı** | Netherite Balta |
| 2 | **Suikastçı** | Elmas Kılıç |
| 3 | **Rahip** | Anında Can İksiri |
| 4 | **Okçu** | Yay |
| 5 | **Büyücü** | Denizin Kalbi |
| 6 | **Avcı** | Netherite Spear |

Her sınıfın menüde kendi hikâyesi, alıntısı ve yetenek listesi vardır.

### Yetenekler (hepsi `config.yml` üzerinden ayarlanabilir)

Kalıcı özellikler **potion effect ile değil, attribute modifier ile** verilir.
Ekranda efekt ikonu çıkmaz, süre dolmaz, oyuncunun içtiği iksirlerle çakışmaz.

| Sınıf | Attribute ile verilenler | Olay tabanlı |
|-------|--------------------------|--------------|
| **Savaşçı** | +2 kalp, +2 zırh, +2 zırh sağlamlığı, saldırı gücü %20, geri tepme direnci | Oklardan %15 az hasar |
| **Suikastçı** | Hareket hızı %20, saldırı hızı %15, -1 kalp | Kılıçla %25, arkadan %60 hasar; %10 fazla hasar alır |
| **Rahip** | +1 kalp, +1 zırh, şans | Sürekli can yenilenmesi, 6 blok şifa aurası, aldığı şifa %50 güçlü, yakın dövüşü zayıf |
| **Okçu** | Hareket hızı %12, uzatılmış etkileşim menzili | Ok hasarı %35, düşme hasarı yok, yakın dövüşü zayıf |
| **Büyücü** | -1 kalp, uzatılmış etkileşim menzili, hareket hızı %5 | Büyü/iksir hasarına %50 direnç, attığı iksirler %40 güçlü |
| **Avcı** | +1 kalp, +0.5 zırh, saldırı hızı %15, hareket hızı %8 | Tüm mızrak türlerinde %30 ekstra hasar; mızrak dışı silahlarla %15 zayıf |

### Avcı hakkında

Avcı, Okçu'ya benzer şekilde **silaha bağlı** bir sınıftır: doğru silahla güçlü,
onun dışında zayıf.

- **Tüm mızrak türlerinde %30 ekstra hasar.** Buna `_SPEAR` ile biten her eşya
  (wooden, stone, copper, iron, golden, diamond, netherite) ve üç dişli mızrak
  (trident) dahildir. Fırlatılan üç dişli mızrak da aynı bonusu alır.
- Mızrak dışındaki her silahla %15 daha az hasar.

Saldırı hızı bonusu, mızrağın yavaş temposunu dengelemek içindir; mızrak zaten
düşük saldırı hızına sahip bir silahtır. Mızrak tespiti materyal adının
`_SPEAR` ile bitmesine bakar, yani ileride yeni bir mızrak türü eklenirse
kod değiştirmeden otomatik kapsanır.

Menü ikonu `NETHERITE_SPEAR`'dır. İkonlar Material sabiti yerine isimle
tutulup çalışma zamanında çözülür; sunucu sürümünde bulunamazsa yedeğe
(Avcı için `TRIDENT`) düşer. Menü slotları da sınıf sayısına göre otomatik
ortalanır, yeni sınıf eklerken slot ayarlamaya gerek yoktur.

Attribute isimleri Minecraft 1.21.3'te değişti (`GENERIC_MAX_HEALTH` → `MAX_HEALTH`).
Eklenti her iki ismi de deneyerek çözer, bu yüzden sürüm farkı sorun çıkarmaz.
Bulunamayan bir attribute konsola uyarı yazıp sessizce atlanır.

---

## Kurulum

1. Jar dosyasını sunucunun `plugins/` klasörüne at.
2. Sunucuyu yeniden başlat.
3. `plugins/SinifSistemi/config.yml` dosyasından her şeyi özelleştir.

**Gereksinimler:** Paper 26.2 ve Java 25.

`pom.xml` bağımlılığı `[26.2.build,)` aralığını kullanır, yani en güncel 26.2
derlemesini otomatik çeker. Sabit bir derlemeye kilitlemek istersen
`26.2.build.112-stable` gibi tam sürüm yazabilirsin.

## Derleme

Bilgisayarında Maven varsa:

```bash
mvn clean package
```

Jar dosyası `target/SinifSistemi.jar` yolunda oluşur. Java 25 gerekir.

Maven kurmak istemiyorsan: proje içindeki `.github/workflows/derle.yml` dosyası hazır.
Projeyi GitHub'a yükle, Actions sekmesinden derlenmiş jar'ı indir.

---

## Komutlar

### Oyuncu komutları

| Komut | Açıklama |
|-------|----------|
| `/sinif` | Sınıf seçim menüsünü açar |
| `/sinif bilgi` | Kendi sınıfını ve yeteneklerini gösterir |
| `/sinif liste` | Tüm sınıfları listeler |

Kısayollar: `/class`, `/sinifim`

### Yetkili komutları

| Komut | Açıklama |
|-------|----------|
| `/sinifyonetim ver <oyuncu> <sınıf>` | Oyuncuya zorla sınıf verir |
| `/sinifyonetim sifirla <oyuncu>` | Sınıfı siler, oyuncu yeniden seçebilir |
| `/sinifyonetim bilgi <oyuncu>` | Oyuncunun sınıfını ve seçim tarihini gösterir |
| `/sinifyonetim menu <oyuncu>` | Oyuncuya seçim menüsünü açar |
| `/sinifyonetim yenile` | Ayarları yeniden yükler |

Kısayollar: `/sy`, `/sinifadmin`

Sınıf adları: `savasci`, `suikastci`, `rahip`, `okcu`, `buyucu`

---

## İzinler

| İzin | Varsayılan | Açıklama |
|------|-----------|----------|
| `sinif.kullan` | herkes | `/sinif` komutunu kullanabilir |
| `sinif.admin` | OP | Yönetim komutlarını kullanabilir |
| `sinif.degistir` | OP | Tek seferlik kilidi aşar, istediği zaman değiştirir |

---

## Önemli Ayarlar

```yaml
ayarlar:
  bir-kere-secim: true        # false = herkes istediği zaman değiştirebilir
  menu-kapatilabilir: false   # false = sınıf seçmeden menü KAPATILAMAZ
  menu-denetim-araligi: 20    # zorunlu menü denetiminin sıklığı (tick)
```

### Zorunlu sınıf seçim menüsü

`menu-kapatilabilir: false` iken menü gerçekten zorunludur:

- ESC ile kapatılırsa **1 tick içinde** geri açılır
- Ayrıca bir denetim görevi her saniye tüm çevrimiçi oyuncuları tarar;
  sınıfsız bir oyuncunun menüsü herhangi bir sebeple kapalıysa
  (ölüm, dünya değişimi, başka bir eklenti, komut) menüyü tekrar önüne getirir
- Girişte sınıfsız oyuncuya menü koşulsuz açılır
- Uyarı mesajı 4 saniyede birden sık gönderilmez, sohbet dolmaz

Tek kaçış yolu `sinif.menu.muaf` iznidir. Bu izin **varsayılan olarak kimsede yoktur** —
OP'larda bile. Sunucuda kendini kilitlemekten çekiniyorsan bu izni kendine ver;
aksi halde sınıf seçmeden hiçbir şey yapamazsın.

Tüm mesajlar `config.yml` içindeki `mesajlar:` bölümündedir ve MiniMessage
formatını destekler (`<red>`, `<gradient:#FFD200:#FF8A00>`, `<bold>` vb.).

---

## Veriler

Oyuncu sınıfları `plugins/SinifSistemi/veriler.yml` dosyasında UUID bazlı tutulur.
Oyuncu adını değiştirse bile sınıfı korunur.

---

# Özel Silahlar

Sınıflara özel, yalnızca kendi sınıfının kullanabildiği silahlar.

## Kanlı Savaş Baltası — Savaşçı

Çift ağızlı bir savaş baltası. **Sağ ağız** cilalı çelik, **sol ağız** kanla kaplı ve
üzerinden sürekli kan akıyor. Sol ağzın altındaki çapraz saydam düzlemlerde
kan damlaları aşağı doğru düşer — 12 kareli animasyonlu texture ile.

**Verme:** `/silah ver kanli_savas_baltasi [oyuncu]`

**Yetenekler**
- Vuruş hasarı %30 artar
- Vurduğu hedefe 4 saniye **Kanama** uygular (saniyede yarım kalp, zırhı delip geçer)
- Kanama hasarının %35'i kullanıcıya can olarak döner
- **Sağ tık — Kan Çağrısı:** 4.5 blok çevredeki tüm canlılara 5 saniye kanama,
  kullanıcıya 5 saniye Güç I. 20 saniye bekleme süresi.

**Sınıf kısıtı**
Savaşçı olmayan biri baltayı eline alırsa uyarı alır ve balta otomatik olarak
elinden envanterine geri konur. Vuruş ve sağ tık da engellenir.
`sinif.silah.serbest` izni bu kısıtı aşar.

## Komutlar

| Komut | Açıklama |
|-------|----------|
| `/silah ver <silah> [oyuncu]` | Özel silahı verir |
| `/silah liste` | Tüm özel silahları listeler |

## İzinler

| İzin | Varsayılan |
|------|-----------|
| `sinif.silah.yonet` | OP |
| `sinif.silah.serbest` | OP |

## Resourcepack

Balta varlıkları `Created_By_MRWQLF.zip` paketinin içine eklendi:

```
assets/cursedclasses/items/kanli_savas_baltasi.json
assets/cursedclasses/models/item/kanli_savas_baltasi.json
assets/cursedclasses/textures/item/kanli_savas_baltasi.png        (384x4608, 12 kare)
assets/cursedclasses/textures/item/kanli_savas_baltasi.png.mcmeta (frametime 2, interpolate)
```

Model 26 elemandan oluşur, `texture_size` [64, 64] atlas kullanır.
Eklenti eşyayı `netherite_axe` tabanı üzerine `item_model` bileşeniyle bağlar —
mevcut eşyalarının hiçbiriyle çakışmaz.

Ayarlar `config.yml` içindeki `silahlar:` bölümündedir.

### Modeli düzenleme

`kanli_savas_baltasi.bbmodel` dosyası Blockbench ile doğrudan açılabilir.
Texture içine gömülüdür, ayrıca dosya yüklemen gerekmez.

Elde tutuş görünümünü ayarlamak için: Blockbench'te sağ üstteki **Display**
sekmesine geç, soldan **First Person / Third Person** pozlarını seç ve
modeli sürükleyerek konumlandır. İşin bitince `File > Export > Export Block/Item Model`
ile dışa aktar ve çıkan JSON'u
`assets/cursedclasses/models/item/kanli_savas_baltasi.json` üzerine yaz.

Dışa aktarırken dikkat: Blockbench `texture_size` alanı ekleyebilir. Minecraft
bu alanı yok sayıp UV'leri her zaman 0-16 aralığında okuduğu için, alan eklenirse
sil — aksi halde doku kayar.
