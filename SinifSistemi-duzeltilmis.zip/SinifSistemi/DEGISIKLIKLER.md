# SinifSistemi — QA raporu sonrasi duzeltmeler

## 1. Sinif pasifleri artik config odakli (asil duzeltme)

**Sorun:** `YetenekYoneticisi` icinde her sinifin pasifleri elle yazilmis metotlardaydi
(`savasci()`, `suikastci()`, `rahip()` ...). Bu metotlar config'teki ayarlarin sadece
bir kismini okuyordu:

| Sinif | Config'de vardi | Kodda uygulaniyordu |
|---|---|---|
| savasci | zirh-saglamligi, geri-tepme-direnci | hayir |
| suikastci | max-can | hayir |
| rahip | max-can, zirh, sans | hayir — metot govdesi tamamen bostu |
| okcu | etkilesim-menzili | hayir |
| buyucu | etkilesim-menzili | hayir |
| avci | hepsi | evet (tek eksiksiz sinif) |

Yani config oyuncuya bir soz veriyor, kod tutmuyordu. Sessiz hataydi: ne konsola bir sey
dusuyor ne oyunda belli oluyordu.

**Cozum:** Alti sinif metodu kaldirildi. `uygula()` artik `siniflar.<sinif>` bolumunu
tarayip **orada ne yaziyorsa onu uyguluyor**:

```java
for (var giris : attributeAyarlari().entrySet()) {
    String tamYol = "siniflar." + sinif.kod() + "." + giris.getKey();
    if (!config.contains(tamYol)) continue;
    ...
}
```

Tanidigi anahtarlar: `max-can`, `zirh`, `zirh-saglamligi`, `geri-tepme-direnci`,
`sans`, `etkilesim-menzili`, `saldiri-hasari-yuzde`, `hareket-hizi-yuzde`,
`saldiri-hizi-yuzde`.

Artik **hangi sinifa hangi ayari yazarsan o uygulanir**. Config'e yeni bir satir
eklediginde kod degistirmen gerekmiyor, ve ikisi bir daha birbirinden ayri dusemez.

Sunucu surumunde karsiligi olmayan bir attribute istenirse sessizce atlanmak yerine
konsola uyari dusuyor.

## 2. Kanama creative moddaki oyuncuyu olduruyordu

`KanamaYoneticisi.tik()` hasari `hedef.setHealth()` ile dogrudan uyguluyor — bu zirhi
ve dokunulmazligi bilerek atliyor (istenen davranis), ama ayni zamanda **creative ve
spectator korumasini da atliyordu**. Creative moddaki bir oyuncu kanamadan olebiliyordu.

Artik hedef oyuncuysa ve creative/spectator modda ya da `isInvulnerable()` ise kanama
kaydi dusuruluyor.

## 3. Can emisi tavani yanlis attribute'tan okunuyordu

Emis `kaynak.getMaxHealth()` kullaniyordu. Bu metot deprecated ve sinif modifier'lari
devredeyken guncel tavani her zaman dogru vermiyor. Artik `MAX_HEALTH` attribute'unun
`getValue()` degeri okunuyor, yani sinifin +2 kalbi de tavana dahil.

Ayrica oyuncu zaten tam candayken gereksiz `setHealth` cagrisi yapilmiyor.

## 4. config.yml koda esitlendi

Kodun artik destekledigi tum anahtarlar varsayilan config'e islendi ve basina hangi
anahtarin ne yaptigini anlatan bir aciklama blogu eklendi.

**Onemli:** Bukkit mevcut `plugins/SinifSistemi/config.yml` dosyasinin uzerine
yazmaz. Sunucundaki config'de zaten bu ayarlar varsa (QA raporu oyle gosteriyordu)
yeni jar'i atar atmaz uygulanmaya baslarlar — dosyaya dokunman gerekmez.
Yeni eklenen anahtarlari gormek istersen config'i yeniden olusturt.

## Hala acik olan konu

QA raporundaki **"Yetenek hicbir etki uretmedi"** ve **"bekleme suresi yok"** bulgulari
test hatasiydi: genel tarama balta testinden once yetenegi tetikliyor, 20 saniyelik
bekleme balta testine sarkiyordu. QATest'in yeni surumu once beklemeyi bosaltiyor,
o yuzden bir sonraki kosuda bu iki satir kaybolmali. Kaybolmazsa gercek bir sorun var
demektir; raporu tekrar gonder.
