package com.sinifsistemi;

import com.sinifsistemi.dinleyici.MenuDinleyici;
import com.sinifsistemi.dinleyici.OyuncuDinleyici;
import com.sinifsistemi.dinleyici.SavasDinleyici;
import com.sinifsistemi.duello.DuelloKomutu;
import com.sinifsistemi.duello.DuelloYoneticisi;
import com.sinifsistemi.irk.IrkKomutu;
import com.sinifsistemi.irk.IrkSistemi;
import com.sinifsistemi.kozmetik.KozmetikDinleyici;
import com.sinifsistemi.kozmetik.KozmetikKomutu;
import com.sinifsistemi.kozmetik.KozmetikYoneticisi;
import com.sinifsistemi.dinleyici.SilahDinleyici;
import com.sinifsistemi.komut.SilahKomutu;
import com.sinifsistemi.komut.SinifKomutu;
import com.sinifsistemi.komut.SinifYonetimKomutu;
import com.sinifsistemi.silah.GolgeYoneticisi;
import com.sinifsistemi.silah.KanamaYoneticisi;
import com.sinifsistemi.silah.SilahYoneticisi;
import com.sinifsistemi.yetenek.YetenekYoneticisi;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class SinifSistemi extends JavaPlugin {

    private SinifDeposu depo;
    private YetenekYoneticisi yetenekYoneticisi;
    private SilahYoneticisi silahYoneticisi;
    private KanamaYoneticisi kanamaYoneticisi;
    private GolgeYoneticisi golgeYoneticisi;
    private SilahDinleyici silahDinleyici;
    private MenuDinleyici menuDinleyici;
    private IrkSistemi irkSistemi;
    private DuelloYoneticisi duelloYoneticisi;
    private KozmetikYoneticisi kozmetikYoneticisi;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        Mesaj.baslat(this);

        this.depo = new SinifDeposu(this);
        this.yetenekYoneticisi = new YetenekYoneticisi(this);
        this.silahYoneticisi = new SilahYoneticisi(this);
        this.kanamaYoneticisi = new KanamaYoneticisi(this);
        this.golgeYoneticisi = new GolgeYoneticisi(this);
        this.silahDinleyici = new SilahDinleyici(this);
        this.menuDinleyici = new MenuDinleyici(this);

        komutKaydet("sinif", new SinifKomutu(this));
        komutKaydet("sinifyonetim", new SinifYonetimKomutu(this));
        komutKaydet("silah", new SilahKomutu(this));

        Bukkit.getPluginManager().registerEvents(menuDinleyici, this);
        Bukkit.getPluginManager().registerEvents(new OyuncuDinleyici(this), this);
        Bukkit.getPluginManager().registerEvents(new SavasDinleyici(this), this);
        Bukkit.getPluginManager().registerEvents(silahDinleyici, this);

        yetenekYoneticisi.baslat();
        kanamaYoneticisi.baslat();
        golgeYoneticisi.baslat();
        silahDinleyici.gorevBaslat();
        menuDinleyici.gorevBaslat();

        // Reload sonrasi cevrimici oyunculara efektleri geri ver
        for (Player oyuncu : Bukkit.getOnlinePlayers()) {
            yetenekYoneticisi.uygula(oyuncu);
        }

        // ---- Irk ve duello sistemleri ----
        this.irkSistemi = new IrkSistemi(this);
        this.irkSistemi.baslat();

        this.duelloYoneticisi = new DuelloYoneticisi(this);
        this.duelloYoneticisi.baslat();

        komutKaydet("irk", new IrkKomutu(this, irkSistemi, false));
        komutKaydet("irkyonetim", new IrkKomutu(this, irkSistemi, true));
        komutKaydet("duello", new DuelloKomutu(this, duelloYoneticisi, false));
        komutKaydet("duelloalan", new DuelloKomutu(this, duelloYoneticisi, true));

        // ---- Kozmetik sistemi ----
        this.kozmetikYoneticisi = new KozmetikYoneticisi(this);
        this.kozmetikYoneticisi.baslat();

        Bukkit.getPluginManager().registerEvents(
                new KozmetikDinleyici(this, kozmetikYoneticisi), this);

        komutKaydet("kozmetik", new KozmetikKomutu(this, kozmetikYoneticisi, false));
        komutKaydet("kozmetikyonetim", new KozmetikKomutu(this, kozmetikYoneticisi, true));

        // Reload sonrasi cevrimici oyunculara kozmetikleri geri ver
        for (Player oyuncu : Bukkit.getOnlinePlayers()) {
            kozmetikYoneticisi.yenidenUygula(oyuncu);
        }

        getLogger().info("ClassAndRegion etkinlestirildi. Iyi oyunlar!");
    }

    @Override
    public void onDisable() {
        if (kozmetikYoneticisi != null) {
            kozmetikYoneticisi.durdur();
            kozmetikYoneticisi.hepsiniTemizle();
            kozmetikYoneticisi.kaydet();
        }
        if (duelloYoneticisi != null) {
            duelloYoneticisi.durdur();
        }
        if (irkSistemi != null) {
            irkSistemi.durdur();
        }
        if (menuDinleyici != null) {
            menuDinleyici.gorevDurdur();
        }
        if (silahDinleyici != null) {
            silahDinleyici.gorevDurdur();
        }
        if (kanamaYoneticisi != null) {
            kanamaYoneticisi.durdur();
        }
        if (golgeYoneticisi != null) {
            golgeYoneticisi.durdur();
        }
        if (yetenekYoneticisi != null) {
            yetenekYoneticisi.durdur();
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                yetenekYoneticisi.temizle(oyuncu);
            }
        }
        if (depo != null) {
            depo.kaydet();
        }
        getLogger().info("ClassAndRegion devre disi birakildi.");
    }

    private <T extends CommandExecutor & TabCompleter> void komutKaydet(String ad, T calistirici) {
        PluginCommand komut = getCommand(ad);
        if (komut == null) {
            getLogger().severe("Komut bulunamadi: " + ad);
            return;
        }
        komut.setExecutor(calistirici);
        komut.setTabCompleter(calistirici);
    }

    public SinifDeposu getDepo() {
        return depo;
    }

    public YetenekYoneticisi getYetenekYoneticisi() {
        return yetenekYoneticisi;
    }

    public MenuDinleyici getMenuDinleyici() {
        return menuDinleyici;
    }

    public IrkSistemi getIrkSistemi() {
        return irkSistemi;
    }

    public DuelloYoneticisi getDuelloYoneticisi() {
        return duelloYoneticisi;
    }

    public SilahYoneticisi getSilahYoneticisi() {
        return silahYoneticisi;
    }

    public GolgeYoneticisi getGolgeYoneticisi() {
        return golgeYoneticisi;
    }

    public KozmetikYoneticisi getKozmetikYoneticisi() {
        return kozmetikYoneticisi;
    }

    public KanamaYoneticisi getKanamaYoneticisi() {
        return kanamaYoneticisi;
    }
}
