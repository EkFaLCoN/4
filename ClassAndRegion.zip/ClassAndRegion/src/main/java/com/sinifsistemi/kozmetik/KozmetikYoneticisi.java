package com.sinifsistemi.kozmetik;

import com.sinifsistemi.SinifSistemi;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Kozmetiklerin tamami buradan yonetilir:
 *
 *  - Gorunum: oyuncuya binen (passenger) bir ItemDisplay. Boylece zirh
 *    slotlari bosta kalir, kozmetik oyunun kendi esyalariyla catismaz.
 *  - Guc: kozmetik_ onekli AttributeModifier'lar + surekli iksir etkileri.
 *    Sinif yeteneklerinden tamamen bagimsizdir, birbirini silmez.
 *  - Kayit: kozmetikler.yml (acilan kozmetikler + takili olanlar).
 */
public class KozmetikYoneticisi {

    private final SinifSistemi eklenti;

    /** Oyuncu -> kategori -> takili kozmetik */
    private final Map<UUID, Map<Kozmetik.Kategori, Kozmetik>> takililar = new HashMap<>();
    /** Oyuncu -> acilmis kozmetikler */
    private final Map<UUID, Set<Kozmetik>> acilanlar = new HashMap<>();
    /** Oyuncu -> kategori -> canli gorunum varligi */
    private final Map<UUID, Map<Kozmetik.Kategori, UUID>> gorunumler = new HashMap<>();

    private final Map<String, NamespacedKey> anahtarlar = new HashMap<>();

    private final Attribute MAX_CAN;
    private final Attribute HAREKET_HIZI;
    private final Attribute ZIRH;
    private final Attribute ZIRH_SAGLAMLIGI;
    private final Attribute GERI_TEPME_DIRENCI;
    private final Attribute SALDIRI_HASARI;

    private File dosya;
    private FileConfiguration veri;
    private BukkitTask gorev;
    private BukkitTask yonGorevi;
    private int sayac;

    /** Oyuncu -> kategori -> o an gosterilen animasyon karesi */
    private final Map<UUID, Map<Kozmetik.Kategori, Integer>> kareler = new HashMap<>();
    /** Oyuncu -> kategori -> animasyon fazi (kare cinsinden, ondalikli) */
    private final Map<UUID, Map<Kozmetik.Kategori, Double>> animFazi = new HashMap<>();
    /** Oyuncu -> son konum (hareket hizini olcmek icin) */
    private final Map<UUID, Location> sonKonum = new HashMap<>();


    public KozmetikYoneticisi(SinifSistemi eklenti) {
        this.eklenti = eklenti;

        MAX_CAN = coz("MAX_HEALTH", "GENERIC_MAX_HEALTH");
        HAREKET_HIZI = coz("MOVEMENT_SPEED", "GENERIC_MOVEMENT_SPEED");
        ZIRH = coz("ARMOR", "GENERIC_ARMOR");
        ZIRH_SAGLAMLIGI = coz("ARMOR_TOUGHNESS", "GENERIC_ARMOR_TOUGHNESS");
        GERI_TEPME_DIRENCI = coz("KNOCKBACK_RESISTANCE", "GENERIC_KNOCKBACK_RESISTANCE");
        SALDIRI_HASARI = coz("ATTACK_DAMAGE", "GENERIC_ATTACK_DAMAGE");

        yukle();
    }

    /** Attribute alan adlari surumler arasi degisti; adaylari sirayla dener. */
    private Attribute coz(String... adaylar) {
        for (String ad : adaylar) {
            try {
                Object deger = Attribute.class.getField(ad).get(null);
                if (deger instanceof Attribute attribute) {
                    return attribute;
                }
            } catch (ReflectiveOperationException | RuntimeException yoksay) {
                // sonraki aday
            }
        }
        return null;
    }

    private NamespacedKey anahtar(String ad) {
        return anahtarlar.computeIfAbsent(ad, a -> new NamespacedKey(eklenti, "kozmetik_" + a));
    }

    // ------------------------------------------------------------------
    //  Veri
    // ------------------------------------------------------------------

    public void yukle() {
        takililar.clear();
        acilanlar.clear();

        dosya = new File(eklenti.getDataFolder(), "kozmetikler.yml");
        if (!dosya.exists()) {
            try {
                if (!eklenti.getDataFolder().exists() && !eklenti.getDataFolder().mkdirs()) {
                    eklenti.getLogger().warning("Eklenti klasoru olusturulamadi!");
                }
                if (!dosya.createNewFile()) {
                    eklenti.getLogger().warning("kozmetikler.yml olusturulamadi!");
                }
            } catch (IOException hata) {
                eklenti.getLogger().log(Level.SEVERE, "kozmetikler.yml olusturulurken hata", hata);
            }
        }
        veri = YamlConfiguration.loadConfiguration(dosya);

        if (veri.isConfigurationSection("oyuncular")) {
            for (String ham : veri.getConfigurationSection("oyuncular").getKeys(false)) {
                UUID kimlik;
                try {
                    kimlik = UUID.fromString(ham);
                } catch (IllegalArgumentException yoksay) {
                    eklenti.getLogger().warning("Gecersiz UUID atlandi: " + ham);
                    continue;
                }

                Set<Kozmetik> acik = new LinkedHashSet<>();
                for (String kod : veri.getStringList("oyuncular." + ham + ".acilanlar")) {
                    Kozmetik k = Kozmetik.bul(kod);
                    if (k != null) {
                        acik.add(k);
                    }
                }
                if (!acik.isEmpty()) {
                    acilanlar.put(kimlik, acik);
                }

                Map<Kozmetik.Kategori, Kozmetik> takili = new EnumMap<>(Kozmetik.Kategori.class);
                for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
                    Kozmetik k = Kozmetik.bul(
                            veri.getString("oyuncular." + ham + ".takili." + kategori.kod()));
                    if (k != null && k.kategori() == kategori) {
                        takili.put(kategori, k);
                    }
                }
                if (!takili.isEmpty()) {
                    takililar.put(kimlik, takili);
                }
            }
        }
        eklenti.getLogger().info(takililar.size() + " oyuncunun kozmetik verisi yuklendi.");
    }

    public void kaydet() {
        if (veri == null || dosya == null) {
            return;
        }
        try {
            veri.save(dosya);
        } catch (IOException hata) {
            eklenti.getLogger().log(Level.SEVERE, "kozmetikler.yml kaydedilemedi", hata);
        }
    }

    private void diskeYaz(UUID kimlik) {
        String yol = "oyuncular." + kimlik;

        List<String> acikKodlar = new ArrayList<>();
        for (Kozmetik k : acilanlar.getOrDefault(kimlik, Collections.emptySet())) {
            acikKodlar.add(k.kod());
        }
        veri.set(yol + ".acilanlar", acikKodlar.isEmpty() ? null : acikKodlar);

        Map<Kozmetik.Kategori, Kozmetik> takili = takililar.get(kimlik);
        for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
            Kozmetik k = takili == null ? null : takili.get(kategori);
            veri.set(yol + ".takili." + kategori.kod(), k == null ? null : k.kod());
        }
        kaydet();
    }

    // ------------------------------------------------------------------
    //  Erisim / kilit
    // ------------------------------------------------------------------

    /** Oyuncu bu kozmetigi kullanabiliyor mu? */
    public boolean acikMi(Player oyuncu, Kozmetik kozmetik) {
        if (eklenti.getConfig().getBoolean("kozmetik.hepsi-acik", false)) {
            return true;
        }
        if (oyuncu.hasPermission("kozmetik.hepsi")
                || oyuncu.hasPermission("kozmetik." + kozmetik.kod())) {
            return true;
        }
        return acilanlar.getOrDefault(oyuncu.getUniqueId(), Collections.emptySet()).contains(kozmetik);
    }

    /** Kozmetigi kalici olarak acar. true -> yeni acildi, false -> zaten aciktI. */
    public boolean ac(UUID kimlik, Kozmetik kozmetik) {
        Set<Kozmetik> kume = acilanlar.computeIfAbsent(kimlik, k -> new LinkedHashSet<>());
        if (!kume.add(kozmetik)) {
            return false;
        }
        diskeYaz(kimlik);
        return true;
    }

    /** Acilmis kozmetigi geri alir. Takiliysa cikarilir. */
    public boolean kilitle(UUID kimlik, Kozmetik kozmetik) {
        Set<Kozmetik> kume = acilanlar.get(kimlik);
        boolean vardi = kume != null && kume.remove(kozmetik);

        Map<Kozmetik.Kategori, Kozmetik> takili = takililar.get(kimlik);
        if (takili != null && takili.get(kozmetik.kategori()) == kozmetik) {
            Player oyuncu = Bukkit.getPlayer(kimlik);
            if (oyuncu != null) {
                cikar(oyuncu, kozmetik.kategori());
            } else {
                takili.remove(kozmetik.kategori());
            }
        }
        if (vardi) {
            diskeYaz(kimlik);
        }
        return vardi;
    }

    public Set<Kozmetik> acilanlari(UUID kimlik) {
        return Collections.unmodifiableSet(
                acilanlar.getOrDefault(kimlik, Collections.emptySet()));
    }

    public Kozmetik takili(Player oyuncu, Kozmetik.Kategori kategori) {
        Map<Kozmetik.Kategori, Kozmetik> harita = takililar.get(oyuncu.getUniqueId());
        return harita == null ? null : harita.get(kategori);
    }

    // ------------------------------------------------------------------
    //  Takma / cikarma
    // ------------------------------------------------------------------

    public void tak(Player oyuncu, Kozmetik kozmetik) {
        UUID kimlik = oyuncu.getUniqueId();
        Map<Kozmetik.Kategori, Kozmetik> harita =
                takililar.computeIfAbsent(kimlik, k -> new EnumMap<>(Kozmetik.Kategori.class));

        Kozmetik eski = harita.get(kozmetik.kategori());
        if (eski != null) {
            gucKaldir(oyuncu, eski);
        }
        harita.put(kozmetik.kategori(), kozmetik);

        gorunumKaldir(oyuncu, kozmetik.kategori());
        gorunumKur(oyuncu, kozmetik);
        if (kozmetik.kategori().ucucu()) {
            periIsaretiVer(oyuncu);
        }
        gucVer(oyuncu, kozmetik);
        diskeYaz(kimlik);
    }

    public void cikar(Player oyuncu, Kozmetik.Kategori kategori) {
        UUID kimlik = oyuncu.getUniqueId();
        Map<Kozmetik.Kategori, Kozmetik> harita = takililar.get(kimlik);
        if (harita == null) {
            return;
        }
        Kozmetik kozmetik = harita.remove(kategori);
        if (kozmetik == null) {
            return;
        }
        gucKaldir(oyuncu, kozmetik);
        gorunumKaldir(oyuncu, kategori);
        if (kategori.ucucu()) {
            periIsaretiAl(oyuncu);
        }
        if (harita.isEmpty()) {
            takililar.remove(kimlik);
        }
        diskeYaz(kimlik);
    }

    /** Giris / respawn / dunya degisimi sonrasi her seyi yeniden kurar. */
    public void yenidenUygula(Player oyuncu) {
        Map<Kozmetik.Kategori, Kozmetik> harita = takililar.get(oyuncu.getUniqueId());
        tumGucleriKaldir(oyuncu);
        gorunumleriKaldir(oyuncu);
        if (harita == null) {
            return;
        }
        for (Kozmetik kozmetik : harita.values()) {
            gucVer(oyuncu, kozmetik);
            gorunumKur(oyuncu, kozmetik);
            if (kozmetik.kategori().ucucu()) {
                periIsaretiVer(oyuncu);
            }
        }
    }

    // ------------------------------------------------------------------
    //  Gorunum (ItemDisplay)
    // ------------------------------------------------------------------

    private void gorunumKur(Player oyuncu, Kozmetik kozmetik) {
        if (!eklenti.getConfig().getBoolean("kozmetik.gorunum-acik", true)) {
            return;
        }
        if (eklenti.getGolgeYoneticisi() != null && eklenti.getGolgeYoneticisi().gizliMi(oyuncu)) {
            return; // Golge Pelerini ile gizliyken kozmetik de gorunmez
        }

        String yol = "kozmetik.gorunum." + kozmetik.kod() + ".";
        ItemStack esya = kareEsyasi(kozmetik, 0);

        float yukseklik = (float) eklenti.getConfig().getDouble(yol + "yukseklik", varsayilanYukseklik(kozmetik));
        float derinlik = (float) eklenti.getConfig().getDouble(yol + "derinlik", varsayilanDerinlik(kozmetik));
        float olcek = (float) eklenti.getConfig().getDouble(yol + "olcek", 1.0);
        // Peri govdenin ortasinda degil, sag omuz hizasinda durur
        float yana = (float) eklenti.getConfig().getDouble(yol + "yana",
                kozmetik.kategori().ucucu() ? 0.42 : 0.0);

        Location konum = oyuncu.getLocation().clone();
        konum.setYaw(govdeYonu(oyuncu));
        konum.setPitch(0f);
        try {
            ItemDisplay ekran = oyuncu.getWorld().spawn(konum, ItemDisplay.class, varlik -> {
                varlik.setItemStack(esya);
                varlik.setPersistent(false);
                varlik.setBillboard(Display.Billboard.FIXED);
                // Modelin "fixed" display blogu uygulansin diye baglam FIXED secilir
                varlik.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                varlik.setTransformation(new Transformation(
                        new Vector3f(yana, yukseklik, derinlik),
                        new AxisAngle4f(0f, 0f, 0f, 1f),
                        new Vector3f(olcek, olcek, olcek),
                        new AxisAngle4f(0f, 0f, 0f, 1f)));
                varlik.setViewRange(0.7f);
                varlik.setInterpolationDuration(2);
                varlik.setTeleportDuration(0);
                varlik.getPersistentDataContainer().set(
                        anahtar("gorunum"), org.bukkit.persistence.PersistentDataType.STRING,
                        kozmetik.kod());
            });
            oyuncu.addPassenger(ekran);
            gorunumler.computeIfAbsent(oyuncu.getUniqueId(),
                    k -> new EnumMap<>(Kozmetik.Kategori.class)).put(kozmetik.kategori(), ekran.getUniqueId());
        } catch (RuntimeException hata) {
            eklenti.getLogger().warning("Kozmetik gorunumu olusturulamadi ("
                    + kozmetik.kod() + "): " + hata.getMessage());
        }
    }

    /**
     * Kozmetigin verilen animasyon karesi icin gosterilecek esyayi uretir.
     * Kare 0 ana model, digerleri "_1", "_2" ... son ekli modellerdir.
     */
    private ItemStack kareEsyasi(Kozmetik kozmetik, int kare) {
        String yol = "kozmetik.gorunum." + kozmetik.kod() + ".";
        Material materyal = materyalGetir(
                eklenti.getConfig().getString(yol + "materyal"), kozmetik.varsayilanModel());

        ItemStack esya = new ItemStack(materyal);
        ItemMeta meta = esya.getItemMeta();
        if (meta == null) {
            return esya;
        }
        String modelAnahtari = eklenti.getConfig().getString(yol + "model-anahtari");
        if (modelAnahtari != null && !modelAnahtari.isBlank()) {
            itemModelAyarla(meta, kare > 0 ? modelAnahtari + "_" + kare : modelAnahtari);
        }
        int modelVerisi = eklenti.getConfig().getInt(yol + "model-verisi", 0);
        if (modelVerisi > 0) {
            modelVerisiAyarla(meta, modelVerisi + kare);
        }
        esya.setItemMeta(meta);
        return esya;
    }

    /** Kategoriye gore makul varsayilan yukseklik (oyuncunun sirti hizasi). */
    private float varsayilanYukseklik(Kozmetik kozmetik) {
        return switch (kozmetik.kategori()) {
            case KANAT -> -0.52f;
            case PELERIN -> -0.44f;
            case PERI -> -0.12f;
        };
    }

    private float varsayilanDerinlik(Kozmetik kozmetik) {
        return switch (kozmetik.kategori()) {
            case KANAT -> -0.26f;
            case PELERIN -> -0.24f;
            case PERI -> -0.10f;
        };
    }

    private void gorunumKaldir(Player oyuncu, Kozmetik.Kategori kategori) {
        Map<Kozmetik.Kategori, UUID> harita = gorunumler.get(oyuncu.getUniqueId());
        if (harita == null) {
            return;
        }
        Map<Kozmetik.Kategori, Integer> kareHaritasi = kareler.get(oyuncu.getUniqueId());
        if (kareHaritasi != null) {
            kareHaritasi.remove(kategori);
        }
        UUID varlikKimligi = harita.remove(kategori);
        if (varlikKimligi != null) {
            var varlik = Bukkit.getEntity(varlikKimligi);
            if (varlik != null) {
                varlik.remove();
            }
        }
        if (harita.isEmpty()) {
            gorunumler.remove(oyuncu.getUniqueId());
        }
    }

    public void gorunumleriKaldir(Player oyuncu) {
        for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
            gorunumKaldir(oyuncu, kategori);
        }
        kareler.remove(oyuncu.getUniqueId());
        animFazi.remove(oyuncu.getUniqueId());
        egimi.remove(oyuncu.getUniqueId());
        sonKonum.remove(oyuncu.getUniqueId());
    }

    /** Cikista peri isaretini de silmek icin dinleyicinin cagirdigi metot. */
    public void oyuncuAyrildi(Player oyuncu) {
        gorunumleriKaldir(oyuncu);
        periIsaretiAl(oyuncu);
    }

    /**
     * Gorunumler olum, dunya degisimi veya chunk bosalmasi gibi durumlarda
     * kopabilir. Bu gorev her saniye kontrol edip eksigi tamamlar.
     */
    public void baslat() {
        durdur();
        gorev = Bukkit.getScheduler().runTaskTimer(eklenti, () -> {
            sayac++;
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                Map<Kozmetik.Kategori, Kozmetik> harita = takililar.get(oyuncu.getUniqueId());
                if (harita == null || harita.isEmpty()) {
                    continue;
                }
                boolean gizli = eklenti.getGolgeYoneticisi() != null
                        && eklenti.getGolgeYoneticisi().gizliMi(oyuncu);

                for (Map.Entry<Kozmetik.Kategori, Kozmetik> giris : harita.entrySet()) {
                    if (gizli) {
                        gorunumKaldir(oyuncu, giris.getKey());
                        continue;
                    }
                    gorunumTazele(oyuncu, giris.getKey(), giris.getValue());
                    if (sayac % 2 == 0) {
                        parcacikCal(oyuncu, giris.getValue());
                    }
                }
                // Peri takiliysa isareti canli tut (baska eklenti silmis olabilir)
                if (harita.containsKey(Kozmetik.Kategori.PERI)) {
                    periIsaretiVer(oyuncu);
                }

                // Surekli iksir etkileri
                for (Kozmetik kozmetik : harita.values()) {
                    if (kozmetik.bonus().surekliEtki() != null) {
                        oyuncu.addPotionEffect(new PotionEffect(
                                kozmetik.bonus().surekliEtki(), 60, 0, true, false, false));
                    }
                }
            }
        }, 40L, 20L);

        yonGoreviBaslat();
    }

    private void gorunumTazele(Player oyuncu, Kozmetik.Kategori kategori, Kozmetik kozmetik) {
        Map<Kozmetik.Kategori, UUID> harita = gorunumler.get(oyuncu.getUniqueId());
        UUID varlikKimligi = harita == null ? null : harita.get(kategori);
        if (varlikKimligi != null) {
            var varlik = Bukkit.getEntity(varlikKimligi);
            if (varlik != null && varlik.isValid()
                    && oyuncu.getPassengers().contains(varlik)
                    && varlik.getWorld().equals(oyuncu.getWorld())) {
                return; // her sey yolunda
            }
            gorunumKaldir(oyuncu, kategori);
        }
        gorunumKur(oyuncu, kozmetik);
    }

    private void parcacikCal(Player oyuncu, Kozmetik kozmetik) {
        if (!eklenti.getConfig().getBoolean("kozmetik.parcacik-acik", true)) {
            return;
        }
        if (kozmetik.parcacik() == null) {
            return;
        }
        try {
            org.bukkit.Particle parcacik =
                    org.bukkit.Particle.valueOf(kozmetik.parcacik().toUpperCase(Locale.ROOT));
            if (parcacik.getDataType() != Void.class) {
                return; // ek veri isteyen parcaciklari atla
            }
            oyuncu.getWorld().spawnParticle(parcacik,
                    oyuncu.getLocation().add(0, 1.0, 0), 4, 0.25, 0.3, 0.25, 0.01);
        } catch (RuntimeException yoksay) {
            // Bu surumde bulunmayan parcacik adi -> sessizce gec
        }
    }

    public void durdur() {
        if (gorev != null) {
            gorev.cancel();
            gorev = null;
        }
        if (yonGorevi != null) {
            yonGorevi.cancel();
            yonGorevi = null;
        }
    }

    /**
     * Oyuncuya binen ItemDisplay kendi yonunu mount'tan DEVRALMAZ; oyuncu
     * donunce model oldugu yerde kalir ve yanda/onde gorunur. Bu gorev her
     * tick modelin yonunu oyuncunun govde yonune esitler.
     */
    private void yonGoreviBaslat() {
        yonGorevi = Bukkit.getScheduler().runTaskTimer(eklenti, () -> {
            for (Map.Entry<UUID, Map<Kozmetik.Kategori, UUID>> giris : gorunumler.entrySet()) {
                Player oyuncu = Bukkit.getPlayer(giris.getKey());
                if (oyuncu == null || !oyuncu.isOnline()) {
                    continue;
                }
                float yon = govdeYonu(oyuncu);
                for (UUID varlikKimligi : giris.getValue().values()) {
                    var varlik = Bukkit.getEntity(varlikKimligi);
                    if (varlik == null || !varlik.isValid()) {
                        continue;
                    }
                    if (Math.abs(varlik.getLocation().getYaw() - yon) > 0.6f) {
                        varlik.setRotation(yon, 0f);
                    }
                }
                animasyonIlerlet(oyuncu);
                konumTazele(oyuncu);
            }
        }, 1L, 1L);
    }

    /**
     * Kanat carpma / pelerin savrulma animasyonu.
     *
     * Hiz arttikca kare degistirme araligi kisalir; oyuncu dururken kanatlar
     * yavasca dinlenme karesine doner. Kareler resourcepack'teki ayri
     * modellerdir, ItemDisplay'in esyasi degistirilerek gecis yapilir.
     */
    private void animasyonIlerlet(Player oyuncu) {
        if (!eklenti.getConfig().getBoolean("kozmetik.animasyon-acik", true)) {
            return;
        }
        Map<Kozmetik.Kategori, Kozmetik> takili = takililar.get(oyuncu.getUniqueId());
        Map<Kozmetik.Kategori, UUID> ekranlar = gorunumler.get(oyuncu.getUniqueId());
        if (takili == null || ekranlar == null) {
            return;
        }

        UUID kimlik = oyuncu.getUniqueId();
        Location simdi = oyuncu.getLocation();
        Location onceki = sonKonum.put(kimlik, simdi.clone());

        double hiz = 0.0;
        if (onceki != null && onceki.getWorld() != null
                && onceki.getWorld().equals(simdi.getWorld())) {
            hiz = onceki.distance(simdi);
        }
        boolean havada = !oyuncu.isOnGround();
        // Havadayken kanatlar her zaman calisir (suzulme hissi)
        double etki = havada ? Math.max(hiz, 0.16) : hiz;

        double carpan = eklenti.getConfig().getDouble("kozmetik.animasyon-hizi", 1.0);

        Map<Kozmetik.Kategori, Double> fazlar =
                animFazi.computeIfAbsent(kimlik, k -> new EnumMap<>(Kozmetik.Kategori.class));

        for (Map.Entry<Kozmetik.Kategori, UUID> giris : ekranlar.entrySet()) {
            Kozmetik.Kategori kategori = giris.getKey();
            Kozmetik kozmetik = takili.get(kategori);
            if (kozmetik == null) {
                continue;
            }
            int toplam = kategori.kareSayisi();
            if (toplam <= 1) {
                continue;
            }

            // Kare hizi TICK BASINA KARE cinsindendir ve ustten sinirlidir.
            // Sinir olmazsa hizli kosarken birkac kare birden atlanir ve
            // gecis puruzlu gorunur. 0.5 = iki tickte bir kare.
            double taban, tepki, tavan;
            switch (kategori) {
                case KANAT -> { taban = 0.16; tepki = 1.5; tavan = 0.55; }
                // Peri canlidir: oyuncu dursa bile kanat cirpmayi birakmaz
                case PERI -> { taban = 0.50; tepki = 0.8; tavan = 0.85; }
                default -> { taban = 0.0; tepki = 1.9; tavan = 0.42; }
            }

            double hizKare = Math.min(tavan, (taban + etki * tepki) * carpan);

            double faz = fazlar.getOrDefault(kategori, 0.0);
            if (hizKare < 0.012 && kategori != Kozmetik.Kategori.PERI) {
                // Duruyor: pelerin dinlenme karesine yumusakca dogru kayar
                if (faz > 0.05) {
                    faz = Math.max(0.0, faz - 0.25);
                } else {
                    faz = 0.0;
                }
            } else {
                faz = (faz + hizKare) % toplam;
            }
            fazlar.put(kategori, faz);

            kareUygula(oyuncu, kategori, kozmetik, giris.getValue(), (int) faz % toplam);
        }
    }

    /** Gosterilen kare degistiyse ItemDisplay'in esyasini gunceller. */
    private void kareUygula(Player oyuncu, Kozmetik.Kategori kategori, Kozmetik kozmetik,
                            UUID varlikKimligi, int kare) {
        if (kozmetik == null) {
            return;
        }
        Map<Kozmetik.Kategori, Integer> harita =
                kareler.computeIfAbsent(oyuncu.getUniqueId(),
                        k -> new EnumMap<>(Kozmetik.Kategori.class));
        Integer mevcut = harita.get(kategori);
        if (mevcut != null && mevcut == kare) {
            return;   // zaten bu karede, bosuna paket gonderme
        }
        var varlik = Bukkit.getEntity(varlikKimligi);
        if (!(varlik instanceof ItemDisplay ekran) || !ekran.isValid()) {
            return;
        }
        ekran.setItemStack(kareEsyasi(kozmetik, kare));
        harita.put(kategori, kare);
    }

    // ------------------------------------------------------------------
    //  PERI: ganimet toplama isareti
    // ------------------------------------------------------------------
    //
    // Ganimet sandiklari CursedValleyMobs eklentisine ait. Iki eklenti
    // birbirine bagimli olmasin diye iletisim tek bir SCOREBOARD ETIKETI
    // uzerinden yapilir: peri takiliyken oyuncuya "cv_peri" etiketi eklenir,
    // mob eklentisi bu etiketi goren sahibin sandigini otomatik bosaltir.

    public static final String PERI_ETIKETI = "cv_peri";

    private void periIsaretiVer(Player oyuncu) {
        if (!oyuncu.getScoreboardTags().contains(PERI_ETIKETI)) {
            oyuncu.addScoreboardTag(PERI_ETIKETI);
        }
    }

    private void periIsaretiAl(Player oyuncu) {
        oyuncu.removeScoreboardTag(PERI_ETIKETI);
    }

    /**
     * Peri yerinde durmaz: sag omuz hizasinda hafifce inip cikar, one arkaya
     * salinir ve kendi ekseninde yalpalar. Bu hareket ItemDisplay'in
     * transformation'i her tick guncellenerek verilir; ItemDisplay
     * interpolasyonu sayesinde gecis akici gorunur.
     */
    private void konumTazele(Player oyuncu) {
        Map<Kozmetik.Kategori, UUID> ekranlar = gorunumler.get(oyuncu.getUniqueId());
        Map<Kozmetik.Kategori, Kozmetik> takili = takililar.get(oyuncu.getUniqueId());
        if (ekranlar == null || takili == null) {
            return;
        }

        // Oyuncu shift'teyken govdesi one egilir ve ~0.3 blok alcalir.
        // Kozmetikler bunu takip etmezse sirtta bosluk kalir ya da govdeye gomulur.
        boolean egik = oyuncu.isSneaking();
        double egimFazi = egimi.merge(oyuncu.getUniqueId(),
                egik ? 0.16 : -0.16, (a, b) -> Math.max(0.0, Math.min(1.0, a + b)));

        for (Map.Entry<Kozmetik.Kategori, UUID> giris : ekranlar.entrySet()) {
            Kozmetik.Kategori kategori = giris.getKey();
            Kozmetik kozmetik = takili.get(kategori);
            if (kozmetik == null) {
                continue;
            }
            var varlik = Bukkit.getEntity(giris.getValue());
            if (!(varlik instanceof ItemDisplay ekran) || !ekran.isValid()) {
                continue;
            }

            String yol = "kozmetik.gorunum." + kozmetik.kod() + ".";
            float yana = (float) eklenti.getConfig().getDouble(yol + "yana",
                    kategori.ucucu() ? 0.45 : 0.0);
            float yukseklik = (float) eklenti.getConfig().getDouble(
                    yol + "yukseklik", varsayilanYukseklik(kozmetik));
            float derinlik = (float) eklenti.getConfig().getDouble(
                    yol + "derinlik", varsayilanDerinlik(kozmetik));
            float olcek = (float) eklenti.getConfig().getDouble(yol + "olcek", 1.0);

            float ekY = 0f, ekZ = 0f, egimAci = 0f;

            if (kategori.ucucu()) {
                // Peri: sekiz cizerek suzulur, oyuncuyla birlikte egilmez ama
                // shift'te biraz alcalir ki omuz hizasinda kalsin.
                double faz = oyuncu.getTicksLived() * 0.09
                        + (Math.abs(oyuncu.getUniqueId().hashCode()) % 100) * 0.06;
                ekY = (float) (Math.sin(faz) * 0.085 - egimFazi * 0.22);
                ekZ = (float) (Math.cos(faz * 0.7) * 0.045);
                yana += (float) (Math.sin(faz * 0.5) * 0.055);
                egimAci = (float) (Math.sin(faz * 0.8) * 0.22);   // yalpalama (Y ekseni)
            } else {
                // Kanat / pelerin: govdeyle birlikte one egilir ve alcalir.
                ekY = (float) (-0.30 * egimFazi);
                ekZ = (float) (-0.16 * egimFazi);
                egimAci = (float) Math.toRadians(30 * egimFazi);  // X ekseninde one yatis
            }

            ekran.setInterpolationDelay(0);
            ekran.setInterpolationDuration(2);
            ekran.setTransformation(new Transformation(
                    new Vector3f(yana, yukseklik + ekY, derinlik + ekZ),
                    kategori.ucucu()
                            ? new AxisAngle4f(egimAci, 0f, 1f, 0f)
                            : new AxisAngle4f(egimAci, 1f, 0f, 0f),
                    new Vector3f(olcek, olcek, olcek),
                    new AxisAngle4f(0f, 0f, 0f, 1f)));
        }
    }

    /** Oyuncu -> shift egiminin yumusatilmis degeri (0 = dik, 1 = tam egik) */
    private final Map<UUID, Double> egimi = new HashMap<>();

    /**
     * Oyuncunun GOVDE yonu. Bas yonu kullanilirsa kanatlar saga sola bakinca
     * savruluyor; Paper'da getBodyYaw varsa o tercih edilir.
     */
    private float govdeYonu(Player oyuncu) {
        try {
            Object deger = oyuncu.getClass().getMethod("getBodyYaw").invoke(oyuncu);
            if (deger instanceof Float f) {
                return f;
            }
        } catch (ReflectiveOperationException | RuntimeException yoksay) {
            // Bu surumde yok -> bas yonuna dus
        }
        return oyuncu.getLocation().getYaw();
    }

    /** Sunucu kapanirken / oyuncu cikarken artik varlik birakmamak icin. */
    public void hepsiniTemizle() {
        for (Player oyuncu : Bukkit.getOnlinePlayers()) {
            gorunumleriKaldir(oyuncu);
            tumGucleriKaldir(oyuncu);
            periIsaretiAl(oyuncu);
        }
        gorunumler.clear();
        kareler.clear();
        animFazi.clear();
        egimi.clear();
        sonKonum.clear();
    }

    // ------------------------------------------------------------------
    //  Guc (attribute)
    // ------------------------------------------------------------------

    private void gucVer(Player oyuncu, Kozmetik kozmetik) {
        Kozmetik.Bonus bonus = kozmetik.bonus();
        String ek = kozmetik.kategori().kod();

        ekle(oyuncu, MAX_CAN, "can_" + ek, bonus.maxCan(), AttributeModifier.Operation.ADD_NUMBER);
        ekle(oyuncu, HAREKET_HIZI, "hiz_" + ek, bonus.hizYuzde(), AttributeModifier.Operation.ADD_SCALAR);
        ekle(oyuncu, ZIRH, "zirh_" + ek, bonus.zirh(), AttributeModifier.Operation.ADD_NUMBER);
        ekle(oyuncu, ZIRH_SAGLAMLIGI, "saglamlik_" + ek, bonus.zirhSaglamlik(), AttributeModifier.Operation.ADD_NUMBER);
        ekle(oyuncu, GERI_TEPME_DIRENCI, "tepme_" + ek, bonus.geriTepme(), AttributeModifier.Operation.ADD_NUMBER);
        ekle(oyuncu, SALDIRI_HASARI, "hasar_" + ek, bonus.saldiriHasari(), AttributeModifier.Operation.ADD_NUMBER);
    }

    private void gucKaldir(Player oyuncu, Kozmetik kozmetik) {
        String ek = kozmetik.kategori().kod();
        kaldir(oyuncu, MAX_CAN, "can_" + ek);
        kaldir(oyuncu, HAREKET_HIZI, "hiz_" + ek);
        kaldir(oyuncu, ZIRH, "zirh_" + ek);
        kaldir(oyuncu, ZIRH_SAGLAMLIGI, "saglamlik_" + ek);
        kaldir(oyuncu, GERI_TEPME_DIRENCI, "tepme_" + ek);
        kaldir(oyuncu, SALDIRI_HASARI, "hasar_" + ek);
        canDuzelt(oyuncu);
    }

    /** Oyuncudaki TUM kozmetik_ modifier'larini siler (sinif yeteneklerine dokunmaz). */
    public void tumGucleriKaldir(Player oyuncu) {
        Attribute[] hepsi = {MAX_CAN, HAREKET_HIZI, ZIRH, ZIRH_SAGLAMLIGI,
                GERI_TEPME_DIRENCI, SALDIRI_HASARI};
        Set<String> silinen = new HashSet<>();
        for (Attribute attribute : hepsi) {
            if (attribute == null) {
                continue;
            }
            AttributeInstance ornek = oyuncu.getAttribute(attribute);
            if (ornek == null) {
                continue;
            }
            for (AttributeModifier mod : new ArrayList<>(ornek.getModifiers())) {
                NamespacedKey k = mod.getKey();
                if (k != null && k.getNamespace().equals(anahtar("x").getNamespace())
                        && k.getKey().startsWith("kozmetik_")) {
                    ornek.removeModifier(mod);
                    silinen.add(k.getKey());
                }
            }
        }
        if (!silinen.isEmpty()) {
            canDuzelt(oyuncu);
        }
    }

    private void ekle(Player oyuncu, Attribute attribute, String ad, double miktar,
                      AttributeModifier.Operation islem) {
        if (attribute == null || miktar == 0) {
            return;
        }
        try {
            AttributeInstance ornek = oyuncu.getAttribute(attribute);
            if (ornek == null) {
                return;
            }
            NamespacedKey k = anahtar(ad);
            for (AttributeModifier mevcut : new ArrayList<>(ornek.getModifiers())) {
                if (k.equals(mevcut.getKey())) {
                    ornek.removeModifier(mevcut);
                }
            }
            ornek.addModifier(new AttributeModifier(k, miktar, islem, EquipmentSlotGroup.ANY));
        } catch (RuntimeException hata) {
            eklenti.getLogger().warning("Kozmetik attribute eklenemedi (" + ad + "): " + hata.getMessage());
        }
    }

    private void kaldir(Player oyuncu, Attribute attribute, String ad) {
        if (attribute == null) {
            return;
        }
        try {
            AttributeInstance ornek = oyuncu.getAttribute(attribute);
            if (ornek == null) {
                return;
            }
            NamespacedKey k = anahtar(ad);
            for (AttributeModifier mod : new ArrayList<>(ornek.getModifiers())) {
                if (k.equals(mod.getKey())) {
                    ornek.removeModifier(mod);
                }
            }
        } catch (RuntimeException yoksay) {
            // gec
        }
    }

    /** Max can dustuyse mevcut cani tasirmamak icin kirpar. */
    private void canDuzelt(Player oyuncu) {
        try {
            if (MAX_CAN == null) {
                return;
            }
            AttributeInstance ornek = oyuncu.getAttribute(MAX_CAN);
            if (ornek != null && oyuncu.getHealth() > ornek.getValue()) {
                oyuncu.setHealth(Math.max(1.0, ornek.getValue()));
            }
        } catch (RuntimeException yoksay) {
            // gec
        }
    }

    // ------------------------------------------------------------------
    //  Yardimcilar
    // ------------------------------------------------------------------

    private Material materyalGetir(String ad, Material varsayilan) {
        if (ad == null || ad.isBlank()) {
            return varsayilan;
        }
        Material materyal = Material.matchMaterial(ad.toUpperCase(Locale.ROOT));
        return materyal == null ? varsayilan : materyal;
    }

    /** ItemMeta#setItemModel surum farkliliklarina karsi reflection ile cagrilir. */
    private void itemModelAyarla(ItemMeta meta, String anahtarMetni) {
        try {
            NamespacedKey k = NamespacedKey.fromString(anahtarMetni.toLowerCase(Locale.ROOT));
            if (k == null) {
                return;
            }
            meta.getClass().getMethod("setItemModel", NamespacedKey.class).invoke(meta, k);
        } catch (ReflectiveOperationException | RuntimeException yoksay) {
            // Bu surumde item-model bilesenin yok -> model-verisi kullanilsin
        }
    }

    /** setCustomModelData(Integer) surumden bagimsiz cagrilir. */
    private void modelVerisiAyarla(ItemMeta meta, int deger) {
        try {
            meta.getClass().getMethod("setCustomModelData", Integer.class).invoke(meta, deger);
        } catch (ReflectiveOperationException | RuntimeException yoksay) {
            // gec
        }
    }
}
