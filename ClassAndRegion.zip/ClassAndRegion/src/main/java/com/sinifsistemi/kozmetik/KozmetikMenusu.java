package com.sinifsistemi.kozmetik;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Kozmetik menusu. Ust satirda kategori sekmeleri, ortada o kategorinin
 * kozmetikleri, altta "cikar" butonu bulunur.
 */
public class KozmetikMenusu implements InventoryHolder {

    private static final int SATIR = 6;

    private final SinifSistemi eklenti;
    private final KozmetikYoneticisi yonetici;
    private final Player oyuncu;
    private final Kozmetik.Kategori kategori;

    private final Map<Integer, Kozmetik> kozmetikSlotlari = new HashMap<>();
    private final Map<Integer, Kozmetik.Kategori> sekmeSlotlari = new HashMap<>();
    private int cikarSlotu = -1;

    private Inventory envanter;

    public KozmetikMenusu(SinifSistemi eklenti, KozmetikYoneticisi yonetici,
                          Player oyuncu, Kozmetik.Kategori kategori) {
        this.eklenti = eklenti;
        this.yonetici = yonetici;
        this.oyuncu = oyuncu;
        this.kategori = kategori == null ? Kozmetik.Kategori.KANAT : kategori;
        olustur();
    }

    private void olustur() {
        String baslik = eklenti.getConfig().getString("kozmetik.menu-basligi",
                "<dark_purple><bold>Kozmetikler");
        envanter = Bukkit.createInventory(this, SATIR * 9,
                Mesaj.ayristir(baslik + " <dark_gray>| " + kategori.renkliAd().replace("<bold>", "")));

        ItemStack dolgu = basitEsya(Material.BLACK_STAINED_GLASS_PANE, null);
        for (int i = 0; i < envanter.getSize(); i++) {
            envanter.setItem(i, dolgu);
        }

        // Ust satir: kategori sekmeleri (2, 4, 6. slotlar)
        Kozmetik.Kategori[] kategoriler = Kozmetik.Kategori.values();
        int[] sekmeSlot = {2, 4, 6};
        for (int i = 0; i < kategoriler.length && i < sekmeSlot.length; i++) {
            sekmeSlotlari.put(sekmeSlot[i], kategoriler[i]);
            envanter.setItem(sekmeSlot[i], sekmeEsyasi(kategoriler[i]));
        }

        // Ayirici
        ItemStack ayirici = basitEsya(Material.GRAY_STAINED_GLASS_PANE, null);
        for (int i = 9; i < 18; i++) {
            envanter.setItem(i, ayirici);
        }

        // Kozmetikler
        List<Kozmetik> liste = new ArrayList<>();
        for (Kozmetik k : Kozmetik.values()) {
            if (k.kategori() == kategori) {
                liste.add(k);
            }
        }
        int basla = 19 + Math.max(0, (7 - liste.size()) / 2);
        for (int i = 0; i < liste.size(); i++) {
            int slot = basla + i;
            if (slot >= 26) {
                slot = 28 + (slot - 26); // ikinci satira tas
            }
            if (slot >= envanter.getSize() - 9) {
                eklenti.getLogger().warning("Kozmetik menude yer bulamadi: " + liste.get(i).kod());
                continue;
            }
            kozmetikSlotlari.put(slot, liste.get(i));
            envanter.setItem(slot, kozmetikEsyasi(liste.get(i)));
        }

        // Alt satir: cikar butonu
        cikarSlotu = envanter.getSize() - 5;
        envanter.setItem(cikarSlotu, cikarEsyasi());
    }

    private ItemStack sekmeEsyasi(Kozmetik.Kategori hedef) {
        ItemStack esya = new ItemStack(hedef.ikon());
        ItemMeta meta = esya.getItemMeta();
        meta.displayName(Mesaj.esya(hedef.renkliAd()));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        Kozmetik takili = yonetici.takili(oyuncu, hedef);
        lore.add(Mesaj.esya("<gray>Takılı: " + (takili == null
                ? "<dark_gray>yok" : takili.basitRenkliAd())));
        lore.add(Component.empty());
        if (hedef == kategori) {
            lore.add(Mesaj.esya("<green><bold>» ŞU AN BURADASIN «"));
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
        } else {
            lore.add(Mesaj.esya("<yellow><bold>» GÖRMEK İÇİN TIKLA «"));
        }
        meta.lore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES,
                ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        esya.setItemMeta(meta);
        return esya;
    }

    private ItemStack kozmetikEsyasi(Kozmetik kozmetik) {
        boolean acik = yonetici.acikMi(oyuncu, kozmetik);
        boolean takili = yonetici.takili(oyuncu, kozmetik.kategori()) == kozmetik;

        ItemStack esya = new ItemStack(acik ? kozmetik.ikon() : Material.GRAY_DYE);
        ItemMeta meta = esya.getItemMeta();
        if (acik) {
            // Menude de kozmetigin kendi 3D modeli gorunsun
            menuModeliUygula(meta, kozmetik);
        }
        meta.displayName(Mesaj.esya(acik ? kozmetik.renkliAd()
                : "<dark_gray><bold>???  <gray>(" + kozmetik.basitRenkliAd() + "<gray>)"));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        for (String satir : kozmetik.aciklama()) {
            lore.add(Mesaj.esya(satir));
        }
        lore.add(Component.empty());
        lore.add(Mesaj.esya("<gold><bold>Güç"));
        for (String satir : kozmetik.gucSatirlari()) {
            lore.add(Mesaj.esya(satir));
        }
        lore.add(Component.empty());

        if (!acik) {
            lore.add(Mesaj.esya("<red><bold>» KİLİTLİ «"));
            lore.add(Mesaj.esya("<dark_gray>Bir yetkiliden açtırabilirsin."));
        } else if (takili) {
            lore.add(Mesaj.esya("<green><bold>» TAKILI «"));
            lore.add(Mesaj.esya("<gray>Çıkarmak için tıkla."));
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
        } else {
            lore.add(Mesaj.esya("<green><bold>» TAKMAK İÇİN TIKLA «"));
            lore.add(Mesaj.esya("<dark_gray>Aynı kategoriden tek parça takılır."));
        }

        meta.lore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES,
                ItemFlag.HIDE_ADDITIONAL_TOOLTIP, ItemFlag.HIDE_UNBREAKABLE);
        esya.setItemMeta(meta);
        return esya;
    }

    private ItemStack cikarEsyasi() {
        Kozmetik takili = yonetici.takili(oyuncu, kategori);
        ItemStack esya = new ItemStack(takili == null ? Material.BARRIER : Material.BUCKET);
        ItemMeta meta = esya.getItemMeta();
        meta.displayName(Mesaj.esya("<red><bold>Bu Kategoriyi Çıkar"));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        if (takili == null) {
            lore.add(Mesaj.esya("<dark_gray>Bu kategoride takılı bir şey yok."));
        } else {
            lore.add(Mesaj.esya("<gray>Çıkarılacak: " + takili.basitRenkliAd()));
            lore.add(Component.empty());
            lore.add(Mesaj.esya("<yellow><bold>» ÇIKARMAK İÇİN TIKLA «"));
        }
        meta.lore(lore);
        esya.setItemMeta(meta);
        return esya;
    }

    /**
     * Resourcepack'te kozmetigin modeli varsa menu ikonunu da ona bagla.
     * config.yml -> kozmetik.gorunum.<kod>.menu-modeli: false ile kapatilabilir.
     */
    private void menuModeliUygula(ItemMeta meta, Kozmetik kozmetik) {
        String yol = "kozmetik.gorunum." + kozmetik.kod() + ".";
        if (!eklenti.getConfig().getBoolean(yol + "menu-modeli", true)) {
            return;
        }
        String modelAnahtari = eklenti.getConfig().getString(yol + "model-anahtari");
        if (modelAnahtari == null || modelAnahtari.isBlank()) {
            return;
        }
        try {
            org.bukkit.NamespacedKey k = org.bukkit.NamespacedKey.fromString(
                    modelAnahtari.toLowerCase(java.util.Locale.ROOT));
            if (k != null) {
                meta.getClass().getMethod("setItemModel", org.bukkit.NamespacedKey.class)
                        .invoke(meta, k);
            }
        } catch (ReflectiveOperationException | RuntimeException yoksay) {
            // Bu surumde item-model bileseni yok -> vanilla ikon kalsin
        }
    }

    private ItemStack basitEsya(Material materyal, String ad) {
        ItemStack esya = new ItemStack(materyal);
        ItemMeta meta = esya.getItemMeta();
        meta.displayName(ad == null ? Component.empty() : Mesaj.esya(ad));
        esya.setItemMeta(meta);
        return esya;
    }

    public void ac() {
        oyuncu.openInventory(envanter);
    }

    public Kozmetik kozmetikSlotta(int slot) {
        return kozmetikSlotlari.get(slot);
    }

    public Kozmetik.Kategori sekmeSlotta(int slot) {
        return sekmeSlotlari.get(slot);
    }

    public boolean cikarSlotuMu(int slot) {
        return slot == cikarSlotu;
    }

    public Kozmetik.Kategori getKategori() {
        return kategori;
    }

    public Player getOyuncu() {
        return oyuncu;
    }

    @Override
    public Inventory getInventory() {
        return envanter;
    }
}
