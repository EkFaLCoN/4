package com.sinifsistemi.kozmetik;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.Inventory;

import java.util.Locale;

public class KozmetikDinleyici implements Listener {

    private final SinifSistemi eklenti;
    private final KozmetikYoneticisi yonetici;

    public KozmetikDinleyici(SinifSistemi eklenti, KozmetikYoneticisi yonetici) {
        this.eklenti = eklenti;
        this.yonetici = yonetici;
    }

    @EventHandler
    public void tiklamaOlayi(InventoryClickEvent olay) {
        Inventory ust = olay.getView().getTopInventory();
        if (!(ust.getHolder() instanceof KozmetikMenusu menu)) {
            return;
        }
        olay.setCancelled(true);

        if (!(olay.getWhoClicked() instanceof Player oyuncu)) {
            return;
        }
        int slot = olay.getRawSlot();
        if (slot < 0 || slot >= ust.getSize()) {
            return;
        }

        // Kategori sekmesi
        Kozmetik.Kategori sekme = menu.sekmeSlotta(slot);
        if (sekme != null) {
            if (sekme != menu.getKategori()) {
                ses(oyuncu, "ui.button.click");
                new KozmetikMenusu(eklenti, yonetici, oyuncu, sekme).ac();
            }
            return;
        }

        // Cikar butonu
        if (menu.cikarSlotuMu(slot)) {
            Kozmetik takili = yonetici.takili(oyuncu, menu.getKategori());
            if (takili == null) {
                ses(oyuncu, "entity.villager.no");
                return;
            }
            yonetici.cikar(oyuncu, menu.getKategori());
            ses(oyuncu, "item.armor.equip_leather");
            Mesaj.gonder(oyuncu, "kozmetik-cikarildi",
                    Mesaj.degisken("kozmetik", takili.basitRenkliAd()));
            new KozmetikMenusu(eklenti, yonetici, oyuncu, menu.getKategori()).ac();
            return;
        }

        // Kozmetik
        Kozmetik secilen = menu.kozmetikSlotta(slot);
        if (secilen == null) {
            return;
        }
        if (!yonetici.acikMi(oyuncu, secilen)) {
            ses(oyuncu, "entity.villager.no");
            Mesaj.gonder(oyuncu, "kozmetik-kilitli",
                    Mesaj.degisken("kozmetik", secilen.basitRenkliAd()));
            return;
        }

        if (yonetici.takili(oyuncu, secilen.kategori()) == secilen) {
            yonetici.cikar(oyuncu, secilen.kategori());
            ses(oyuncu, "item.armor.equip_leather");
            Mesaj.gonder(oyuncu, "kozmetik-cikarildi",
                    Mesaj.degisken("kozmetik", secilen.basitRenkliAd()));
        } else {
            yonetici.tak(oyuncu, secilen);
            ses(oyuncu, eklenti.getConfig().getString("kozmetik.takma-sesi",
                    "item.armor.equip_elytra"));
            Mesaj.gonder(oyuncu, "kozmetik-takildi",
                    Mesaj.degisken("kozmetik", secilen.basitRenkliAd()));
        }
        new KozmetikMenusu(eklenti, yonetici, oyuncu, secilen.kategori()).ac();
    }

    @EventHandler
    public void surukleOlayi(InventoryDragEvent olay) {
        if (olay.getView().getTopInventory().getHolder() instanceof KozmetikMenusu) {
            olay.setCancelled(true);
        }
    }

    @EventHandler
    public void girisOlayi(PlayerJoinEvent olay) {
        Bukkit.getScheduler().runTaskLater(eklenti,
                () -> {
                    if (olay.getPlayer().isOnline()) {
                        yonetici.yenidenUygula(olay.getPlayer());
                    }
                }, 20L);
    }

    @EventHandler
    public void cikisOlayi(PlayerQuitEvent olay) {
        yonetici.oyuncuAyrildi(olay.getPlayer());
        yonetici.tumGucleriKaldir(olay.getPlayer());
    }

    /**
     * Kostum, oyuncunun UZERINDEKI zirhin gorunumunu degistirdigi icin yeni
     * bir zirh giyildiginde ona da islenmeli.
     */
    private void ses(Player oyuncu, String sesAdi) {
        if (sesAdi == null || sesAdi.isBlank()) {
            return;
        }
        String anahtar = sesAdi.toLowerCase(Locale.ROOT).replace('_', '.');
        try {
            oyuncu.playSound(oyuncu.getLocation(), anahtar, 1.0f, 1.0f);
        } catch (Exception yoksay) {
            // gec
        }
    }
}
