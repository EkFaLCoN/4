package com.sinifsistemi.kozmetik;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * /kozmetik           -> menuyu acar
 * /kozmetik liste     -> tum kozmetikleri listeler
 * /kozmetik cikar     -> takili her seyi cikarir
 *
 * /kozmetikyonetim ac <oyuncu> <kod|hepsi>
 * /kozmetikyonetim kilitle <oyuncu> <kod|hepsi>
 * /kozmetikyonetim bilgi <oyuncu>
 */
public class KozmetikKomutu implements CommandExecutor, TabCompleter {

    private final SinifSistemi eklenti;
    private final KozmetikYoneticisi yonetici;
    private final boolean yonetim;

    public KozmetikKomutu(SinifSistemi eklenti, KozmetikYoneticisi yonetici, boolean yonetim) {
        this.eklenti = eklenti;
        this.yonetici = yonetici;
        this.yonetim = yonetim;
    }

    @Override
    public boolean onCommand(CommandSender gonderen, Command komut, String etiket, String[] argumanlar) {
        if (yonetim) {
            return yonetimKomutu(gonderen, argumanlar);
        }
        return oyuncuKomutu(gonderen, argumanlar);
    }

    // ---------------- /kozmetik ----------------

    private boolean oyuncuKomutu(CommandSender gonderen, String[] argumanlar) {
        if (!(gonderen instanceof Player oyuncu)) {
            Mesaj.gonder(gonderen, "sadece-oyuncu");
            return true;
        }
        if (!oyuncu.hasPermission("kozmetik.kullan")) {
            Mesaj.gonder(oyuncu, "yetkin-yok");
            return true;
        }

        if (argumanlar.length == 0) {
            new KozmetikMenusu(eklenti, yonetici, oyuncu, Kozmetik.Kategori.KANAT).ac();
            return true;
        }

        switch (argumanlar[0].toLowerCase(Locale.ROOT)) {
            case "liste" -> {
                gonderen.sendMessage(Mesaj.ayristir("<dark_gray><strikethrough>                                        "));
                gonderen.sendMessage(Mesaj.ayristir(" <dark_purple><bold>KOZMETİKLER"));
                for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
                    gonderen.sendMessage(Mesaj.ayristir(""));
                    gonderen.sendMessage(Mesaj.ayristir(" " + kategori.renkliAd()));
                    for (Kozmetik k : Kozmetik.values()) {
                        if (k.kategori() != kategori) {
                            continue;
                        }
                        boolean acik = yonetici.acikMi(oyuncu, k);
                        gonderen.sendMessage(Mesaj.ayristir("  " + (acik ? "<green>✔ " : "<red>✖ ")
                                + k.basitRenkliAd() + " <dark_gray>(" + k.kod() + ")"));
                    }
                }
                gonderen.sendMessage(Mesaj.ayristir("<dark_gray><strikethrough>                                        "));
            }
            case "cikar" -> {
                boolean birSey = false;
                for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
                    if (yonetici.takili(oyuncu, kategori) != null) {
                        yonetici.cikar(oyuncu, kategori);
                        birSey = true;
                    }
                }
                Mesaj.gonder(oyuncu, birSey ? "kozmetik-hepsi-cikarildi" : "kozmetik-takili-yok");
            }
            default -> new KozmetikMenusu(eklenti, yonetici, oyuncu,
                    Kozmetik.Kategori.bul(argumanlar[0])).ac();
        }
        return true;
    }

    // ---------------- /kozmetikyonetim ----------------

    private boolean yonetimKomutu(CommandSender gonderen, String[] argumanlar) {
        if (!gonderen.hasPermission("kozmetik.admin")) {
            Mesaj.gonder(gonderen, "yetkin-yok");
            return true;
        }
        if (argumanlar.length < 2) {
            Mesaj.gonderHam(gonderen, "kozmetik-yonetim-kullanim");
            return true;
        }

        String islem = argumanlar[0].toLowerCase(Locale.ROOT);
        OfflinePlayer hedef = hedefBul(argumanlar[1]);
        if (hedef == null) {
            Mesaj.gonder(gonderen, "oyuncu-bulunamadi", Mesaj.degisken("oyuncu", argumanlar[1]));
            return true;
        }
        UUID kimlik = hedef.getUniqueId();

        switch (islem) {
            case "bilgi" -> {
                gonderen.sendMessage(Mesaj.ayristir("<dark_gray><strikethrough>                                        "));
                gonderen.sendMessage(Mesaj.ayristir(" <dark_purple><bold>KOZMETİK BİLGİSİ <dark_gray>| <white>"
                        + (hedef.getName() == null ? argumanlar[1] : hedef.getName())));
                gonderen.sendMessage(Mesaj.ayristir(""));
                Player cevrimici = hedef.getPlayer();
                for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
                    Kozmetik takili = cevrimici == null ? null : yonetici.takili(cevrimici, kategori);
                    gonderen.sendMessage(Mesaj.ayristir(" <gray>" + kategori.kod() + ": "
                            + (takili == null ? "<dark_gray>yok" : takili.basitRenkliAd())));
                }
                gonderen.sendMessage(Mesaj.ayristir(""));
                gonderen.sendMessage(Mesaj.ayristir(" <gray>Açık kozmetikler:"));
                var acik = yonetici.acilanlari(kimlik);
                if (acik.isEmpty()) {
                    gonderen.sendMessage(Mesaj.ayristir("  <dark_gray>- yok -"));
                } else {
                    for (Kozmetik k : acik) {
                        gonderen.sendMessage(Mesaj.ayristir("  <green>✔ " + k.basitRenkliAd()));
                    }
                }
                gonderen.sendMessage(Mesaj.ayristir("<dark_gray><strikethrough>                                        "));
            }
            case "ac", "kilitle" -> {
                if (argumanlar.length < 3) {
                    Mesaj.gonderHam(gonderen, "kozmetik-yonetim-kullanim");
                    return true;
                }
                boolean acma = islem.equals("ac");
                String kod = argumanlar[2];

                if (kod.equalsIgnoreCase("hepsi")) {
                    int sayi = 0;
                    for (Kozmetik k : Kozmetik.values()) {
                        boolean degisti = acma ? yonetici.ac(kimlik, k) : yonetici.kilitle(kimlik, k);
                        if (degisti) {
                            sayi++;
                        }
                    }
                    Mesaj.gonder(gonderen, acma ? "kozmetik-toplu-acildi" : "kozmetik-toplu-kilitlendi",
                            Mesaj.degisken("sayi", String.valueOf(sayi),
                                    "oyuncu", hedef.getName() == null ? argumanlar[1] : hedef.getName()));
                    bildir(hedef, acma, null, sayi);
                    return true;
                }

                Kozmetik kozmetik = Kozmetik.bul(kod);
                if (kozmetik == null) {
                    Mesaj.gonder(gonderen, "kozmetik-bulunamadi", Mesaj.degisken("kozmetik", kod));
                    return true;
                }
                boolean degisti = acma ? yonetici.ac(kimlik, kozmetik) : yonetici.kilitle(kimlik, kozmetik);
                Mesaj.gonder(gonderen, degisti
                                ? (acma ? "kozmetik-acildi" : "kozmetik-kilitlendi")
                                : "kozmetik-degisiklik-yok",
                        Mesaj.degisken("kozmetik", kozmetik.basitRenkliAd(),
                                "oyuncu", hedef.getName() == null ? argumanlar[1] : hedef.getName()));
                if (degisti) {
                    bildir(hedef, acma, kozmetik, 1);
                }
            }
            default -> Mesaj.gonderHam(gonderen, "kozmetik-yonetim-kullanim");
        }
        return true;
    }

    private void bildir(OfflinePlayer hedef, boolean acma, Kozmetik kozmetik, int sayi) {
        Player oyuncu = hedef.getPlayer();
        if (oyuncu == null || !acma) {
            return;
        }
        if (kozmetik == null) {
            Mesaj.gonder(oyuncu, "kozmetik-sana-toplu-acildi",
                    Mesaj.degisken("sayi", String.valueOf(sayi)));
        } else {
            Mesaj.gonder(oyuncu, "kozmetik-sana-acildi",
                    Mesaj.degisken("kozmetik", kozmetik.basitRenkliAd()));
        }
    }

    private OfflinePlayer hedefBul(String ad) {
        Player cevrimici = Bukkit.getPlayerExact(ad);
        if (cevrimici != null) {
            return cevrimici;
        }
        OfflinePlayer cevrimdisi = Bukkit.getOfflinePlayer(ad);
        return cevrimdisi.hasPlayedBefore() ? cevrimdisi : null;
    }

    // ---------------- Tab tamamlama ----------------

    @Override
    public List<String> onTabComplete(CommandSender gonderen, Command komut,
                                      String etiket, String[] argumanlar) {
        List<String> sonuc = new ArrayList<>();

        if (!yonetim) {
            if (argumanlar.length == 1) {
                ekle(sonuc, argumanlar[0], "liste", "cikar", "kanat", "pelerin", "kostum");
            }
            return sonuc;
        }

        if (!gonderen.hasPermission("kozmetik.admin")) {
            return sonuc;
        }
        if (argumanlar.length == 1) {
            ekle(sonuc, argumanlar[0], "ac", "kilitle", "bilgi");
        } else if (argumanlar.length == 2) {
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                ekle(sonuc, argumanlar[1], oyuncu.getName());
            }
        } else if (argumanlar.length == 3
                && (argumanlar[0].equalsIgnoreCase("ac") || argumanlar[0].equalsIgnoreCase("kilitle"))) {
            ekle(sonuc, argumanlar[2], "hepsi");
            for (Kozmetik k : Kozmetik.values()) {
                ekle(sonuc, argumanlar[2], k.kod());
            }
        }
        return sonuc;
    }

    private void ekle(List<String> hedef, String yazilan, String... adaylar) {
        String kucuk = yazilan == null ? "" : yazilan.toLowerCase(Locale.ROOT);
        for (String aday : adaylar) {
            if (aday.toLowerCase(Locale.ROOT).startsWith(kucuk)) {
                hedef.add(aday);
            }
        }
    }
}
