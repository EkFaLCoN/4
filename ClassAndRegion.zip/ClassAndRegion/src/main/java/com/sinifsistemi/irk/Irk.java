package com.sinifsistemi.irk;

import org.bukkit.Material;

import java.util.List;
import java.util.Locale;

/**
 * Sunucudaki iki irk.
 *
 * Ayni irktan oyuncular birbirine zarar veremez (arena / duello haric).
 * Farkli irklar her yerde birbirine saldirabilir.
 */
public enum Irk {

    EMBERON(
            "emberon",
            "Emberon",
            "<red>",
            "#FF6B4A",
            "#8B1A0A",
            "RED_BANNER",
            "RED_WOOL",
            List.of(
                    "<gray>Külün altında sönmeyen közden doğdular.",
                    "<gray>Bittikleri sanılır, sonra yeniden alevlenirler.",
                    "<gray>Onları öldürmek değil, <red>söndürmek gerekir<gray>.",
                    "",
                    "<dark_gray>\"Kor, üflendikçe büyür.\""
            ),
            "Kor Kabuğu",
            List.of(
                    "<red>✦ <gray>Külün altındaki kor gibi sertleşir",
                    "<red>✦ <gray>Yakın dövüşten aldığı hasar <white>%8 <gray>azalır"
            )
    ),

    RHODAR(
            "rhodar",
            "Rhodar",
            "<aqua>",
            "#6BC4FF",
            "#0A3A8B",
            "BLUE_BANNER",
            "BLUE_WOOL",
            List.of(
                    "<gray>Derin suların ve seher göğünün halkı.",
                    "<gray>Hafif adımlı, sabırlı ve hesaplı bir soy;",
                    "<gray>vururlar ve <aqua>gökyüzü kadar sessiz çekilirler<gray>.",
                    "",
                    "<dark_gray>\"Rüzgârı kovalayan onu asla yakalayamaz.\""
            ),
            "Gelgit Adımı",
            List.of(
                    "<aqua>✦ <gray>Gelgit gibi gelir, gelgit gibi çekilir",
                    "<aqua>✦ <gray>Hareket hızı <white>%6 <gray>daha yüksektir"
            )
    );

    private final String kod;
    private final String ad;
    private final String renk;
    private final String gradyanBas;
    private final String gradyanSon;
    private final String ikonAdi;
    private final String yedekIkonAdi;
    private final List<String> aciklama;
    private final String pasifAdi;
    private final List<String> pasifler;

    Irk(String kod, String ad, String renk, String gradyanBas, String gradyanSon,
        String ikonAdi, String yedekIkonAdi, List<String> aciklama,
        String pasifAdi, List<String> pasifler) {
        this.kod = kod;
        this.ad = ad;
        this.renk = renk;
        this.gradyanBas = gradyanBas;
        this.gradyanSon = gradyanSon;
        this.ikonAdi = ikonAdi;
        this.yedekIkonAdi = yedekIkonAdi;
        this.aciklama = aciklama;
        this.pasifAdi = pasifAdi;
        this.pasifler = pasifler;
    }

    public String kod() {
        return kod;
    }

    public String ad() {
        return ad;
    }

    public String renkliAd() {
        return "<gradient:" + gradyanBas + ":" + gradyanSon + "><bold>" + ad + "</bold></gradient>";
    }

    public String basitRenkliAd() {
        return renk + ad;
    }

    public String pasifAdi() {
        return pasifAdi;
    }

    public List<String> aciklama() {
        return aciklama;
    }

    public List<String> pasifler() {
        return pasifler;
    }

    /** Ikon materyalini calisma zamaninda cozer; bulunamazsa yedege duser. */
    public Material ikon() {
        Material m = Material.matchMaterial(ikonAdi);
        if (m == null) {
            m = Material.matchMaterial(yedekIkonAdi);
        }
        return m == null ? Material.BARRIER : m;
    }

    public static Irk bul(String metin) {
        if (metin == null || metin.isBlank()) {
            return null;
        }
        String temiz = metin.trim()
                .toLowerCase(Locale.forLanguageTag("tr"))
                .replace('ı', 'i').replace('ş', 's').replace('ç', 'c')
                .replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o');
        for (Irk irk : values()) {
            if (irk.kod.equals(temiz) || irk.name().equalsIgnoreCase(temiz)) {
                return irk;
            }
        }
        return null;
    }
}
