package com.sinifsistemi.irk;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * /irk           - irkini gosterir, yoksa secim ekranini acar
 * /irk liste     - iki irki ve pasiflerini listeler
 * /irk uyeler    - cevrimici irk dagilimini gosterir
 *
 * /irkyonetim ver <oyuncu> <irk>
 * /irkyonetim sifirla <oyuncu>
 * /irkyonetim bilgi <oyuncu>
 * /irkyonetim duello <oyuncu1> <oyuncu2>   (gecici vurusma izni)
 */
public class IrkKomutu implements CommandExecutor, TabCompleter {

    private final SinifSistemi eklenti;
    private final IrkSistemi sistem;
    private final boolean yonetim;

    public IrkKomutu(SinifSistemi eklenti, IrkSistemi sistem, boolean yonetim) {
        this.eklenti = eklenti;
        this.sistem = sistem;
        this.yonetim = yonetim;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender gonderen, @NotNull Command komut,
                             @NotNull String etiket, @NotNull String[] a) {
        return yonetim ? yonetimKomutu(gonderen, a) : oyuncuKomutu(gonderen, a);
    }

    // ---------------- /irk ----------------

    private boolean oyuncuKomutu(CommandSender gonderen, String[] a) {
        if (!(gonderen instanceof Player oyuncu)) {
            Mesaj.gonder(gonderen, "sadece-oyuncu");
            return true;
        }

        if (a.length == 0) {
            Irk irk = sistem.getIrk(oyuncu);
            if (irk == null) {
                if (!eklenti.getDepo().sinifiVar(oyuncu)) {
                    Mesaj.gonder(oyuncu, "irk-once-sinif");
                    return true;
                }
                sistem.menuAc(oyuncu, false);
                return true;
            }
            bilgiGoster(oyuncu, irk);
            return true;
        }

        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "liste" -> {
                gonderen.sendMessage(Mesaj.ayristir(Mesaj.ham("bilgi-baslik")));
                for (Irk irk : Irk.values()) {
                    gonderen.sendMessage(Mesaj.ayristir(
                            " " + sistem.bayrak(irk) + " " + irk.renkliAd()));
                    gonderen.sendMessage(Mesaj.ayristir("   " + irk.aciklama().get(0)));
                    for (String satir : irk.pasifler()) {
                        gonderen.sendMessage(Mesaj.ayristir("   " + satir));
                    }
                    gonderen.sendMessage(Mesaj.ayristir(""));
                }
                gonderen.sendMessage(Mesaj.ayristir(Mesaj.ham("bilgi-baslik")));
            }
            case "uyeler", "uye" -> {
                gonderen.sendMessage(Mesaj.ayristir(Mesaj.ham("bilgi-baslik")));
                for (Irk irk : Irk.values()) {
                    List<Player> liste = sistem.irktakiler(irk);
                    gonderen.sendMessage(Mesaj.ayristir(" " + sistem.bayrak(irk) + " "
                            + irk.renkliAd() + " <dark_gray>- <white>" + liste.size()
                            + " <gray>çevrimiçi"));
                }
                gonderen.sendMessage(Mesaj.ayristir(Mesaj.ham("bilgi-baslik")));
            }
            default -> Mesaj.gonder(gonderen, "irk-kullanim");
        }
        return true;
    }

    private void bilgiGoster(Player oyuncu, Irk irk) {
        oyuncu.sendMessage(Mesaj.ayristir(Mesaj.ham("bilgi-baslik")));
        oyuncu.sendMessage(Mesaj.ayristir(" " + sistem.bayrak(irk) + " " + irk.renkliAd()));
        oyuncu.sendMessage(Mesaj.ayristir(""));
        for (String satir : irk.aciklama()) {
            oyuncu.sendMessage(Mesaj.ayristir(" " + satir));
        }
        oyuncu.sendMessage(Mesaj.ayristir(""));
        oyuncu.sendMessage(Mesaj.ayristir(" <gold><bold>" + irk.pasifAdi()));
        for (String satir : irk.pasifler()) {
            oyuncu.sendMessage(Mesaj.ayristir(" " + satir));
        }
        oyuncu.sendMessage(Mesaj.ayristir(""));
        oyuncu.sendMessage(Mesaj.ayristir(" <gray>Seçim tarihi: <white>"
                + sistem.getTarih(oyuncu.getUniqueId())));
        oyuncu.sendMessage(Mesaj.ayristir(Mesaj.ham("bilgi-baslik")));
    }

    // ---------------- /irkyonetim ----------------

    private boolean yonetimKomutu(CommandSender gonderen, String[] a) {
        if (!gonderen.hasPermission("irk.admin")) {
            Mesaj.gonder(gonderen, "yetkin-yok");
            return true;
        }
        if (a.length == 0) {
            Mesaj.gonderHam(gonderen, "irk-kullanim-yonetim");
            return true;
        }

        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "ver" -> {
                if (a.length < 3) {
                    Mesaj.gonderHam(gonderen, "irk-kullanim-yonetim");
                    return true;
                }
                OfflinePlayer hedef = oyuncuBul(a[1]);
                if (hedef == null) {
                    Mesaj.gonder(gonderen, "oyuncu-bulunamadi", Mesaj.degisken("oyuncu", a[1]));
                    return true;
                }
                Irk irk = Irk.bul(a[2]);
                if (irk == null) {
                    Mesaj.gonder(gonderen, "irk-bulunamadi",
                            Mesaj.degisken("irk", a[2], "liste", sistem.kodListesi()));
                    return true;
                }
                String ad = hedef.getName() == null ? a[1] : hedef.getName();
                sistem.ayarla(hedef.getUniqueId(), ad, irk);
                Mesaj.gonder(gonderen, "irk-verildi",
                        Mesaj.degisken("oyuncu", ad, "irk", irk.renkliAd()));
                Player cevrimici = hedef.getPlayer();
                if (cevrimici != null) {
                    Mesaj.gonder(cevrimici, "irk-verildi-hedef",
                            Mesaj.degisken("irk", irk.renkliAd()));
                }
            }
            case "sifirla" -> {
                if (a.length < 2) {
                    Mesaj.gonderHam(gonderen, "irk-kullanim-yonetim");
                    return true;
                }
                OfflinePlayer hedef = oyuncuBul(a[1]);
                if (hedef == null) {
                    Mesaj.gonder(gonderen, "oyuncu-bulunamadi", Mesaj.degisken("oyuncu", a[1]));
                    return true;
                }
                sistem.sifirla(hedef.getUniqueId());
                String ad = hedef.getName() == null ? a[1] : hedef.getName();
                Mesaj.gonder(gonderen, "irk-sifirlandi", Mesaj.degisken("oyuncu", ad));
            }
            case "bilgi" -> {
                if (a.length < 2) {
                    Mesaj.gonderHam(gonderen, "irk-kullanim-yonetim");
                    return true;
                }
                OfflinePlayer hedef = oyuncuBul(a[1]);
                if (hedef == null) {
                    Mesaj.gonder(gonderen, "oyuncu-bulunamadi", Mesaj.degisken("oyuncu", a[1]));
                    return true;
                }
                Irk irk = sistem.getIrk(hedef.getUniqueId());
                String ad = hedef.getName() == null ? a[1] : hedef.getName();
                if (irk == null) {
                    Mesaj.gonder(gonderen, "irk-yok-hedef", Mesaj.degisken("oyuncu", ad));
                    return true;
                }
                gonderen.sendMessage(Mesaj.ayristir(Mesaj.ham("bilgi-baslik")));
                gonderen.sendMessage(Mesaj.ayristir(" <gray>Oyuncu: <white>" + ad));
                gonderen.sendMessage(Mesaj.ayristir(" <gray>Irk: " + sistem.bayrak(irk)
                        + " " + irk.renkliAd()));
                gonderen.sendMessage(Mesaj.ayristir(" <gray>Seçim tarihi: <white>"
                        + sistem.getTarih(hedef.getUniqueId())));
                gonderen.sendMessage(Mesaj.ayristir(Mesaj.ham("bilgi-baslik")));
            }
            case "duello" -> {
                if (a.length < 3) {
                    Mesaj.gonderHam(gonderen, "irk-kullanim-yonetim");
                    return true;
                }
                Player p1 = Bukkit.getPlayerExact(a[1]);
                Player p2 = Bukkit.getPlayerExact(a[2]);
                if (p1 == null || p2 == null) {
                    Mesaj.gonder(gonderen, "oyuncu-bulunamadi",
                            Mesaj.degisken("oyuncu", p1 == null ? a[1] : a[2]));
                    return true;
                }
                if (sistem.duelloVar(p1, p2)) {
                    sistem.duelloIzniKaldir(p1.getUniqueId(), p2.getUniqueId());
                    Mesaj.gonder(gonderen, "irk-duello-kapandi",
                            Mesaj.degisken("oyuncu", p1.getName(), "oyuncu2", p2.getName()));
                } else {
                    sistem.duelloIzniVer(p1.getUniqueId(), p2.getUniqueId());
                    Mesaj.gonder(gonderen, "irk-duello-acildi",
                            Mesaj.degisken("oyuncu", p1.getName(), "oyuncu2", p2.getName()));
                }
            }
            default -> Mesaj.gonderHam(gonderen, "irk-kullanim-yonetim");
        }
        return true;
    }

    @SuppressWarnings("deprecation")
    private OfflinePlayer oyuncuBul(String ad) {
        Player cevrimici = Bukkit.getPlayerExact(ad);
        if (cevrimici != null) {
            return cevrimici;
        }
        OfflinePlayer cevrimdisi = Bukkit.getOfflinePlayer(ad);
        return cevrimdisi.hasPlayedBefore() ? cevrimdisi : null;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender gonderen, @NotNull Command komut,
                                      @NotNull String etiket, @NotNull String[] a) {
        List<String> sonuc = new ArrayList<>();
        if (!yonetim) {
            if (a.length == 1) {
                for (String s : List.of("liste", "uyeler")) {
                    if (s.startsWith(a[0].toLowerCase(Locale.ROOT))) {
                        sonuc.add(s);
                    }
                }
            }
            return sonuc;
        }
        if (!gonderen.hasPermission("irk.admin")) {
            return sonuc;
        }
        if (a.length == 1) {
            for (String s : List.of("ver", "sifirla", "bilgi", "duello")) {
                if (s.startsWith(a[0].toLowerCase(Locale.ROOT))) {
                    sonuc.add(s);
                }
            }
        } else if (a.length == 2 || (a.length == 3 && a[0].equalsIgnoreCase("duello"))) {
            String onek = a[a.length - 1].toLowerCase(Locale.ROOT);
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                if (oyuncu.getName().toLowerCase(Locale.ROOT).startsWith(onek)) {
                    sonuc.add(oyuncu.getName());
                }
            }
        } else if (a.length == 3 && a[0].equalsIgnoreCase("ver")) {
            for (Irk irk : Irk.values()) {
                if (irk.kod().startsWith(a[2].toLowerCase(Locale.ROOT))) {
                    sonuc.add(irk.kod());
                }
            }
        }
        return sonuc;
    }
}
