package com.sinifsistemi.dinleyici;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.Sinif;
import com.sinifsistemi.SinifSistemi;
import com.sinifsistemi.silah.KanamaYoneticisi;
import com.sinifsistemi.silah.Silah;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Ozel silahlarin sinif kisiti, pasif efektleri ve yetenekleri.
 */
public class SilahDinleyici implements Listener {

    private final SinifSistemi eklenti;
    private final Map<UUID, Long> uyariZamani = new HashMap<>();
    private final Map<UUID, Long> yetenekBekleme = new HashMap<>();
    private final Map<UUID, Long> firtinaBekleme = new HashMap<>();
    private final java.util.Set<UUID> firtinaIcinde = new java.util.HashSet<>();
    private final Map<UUID, Long> hancerBekleme = new HashMap<>();
    private final Map<UUID, Long> pelerinBekleme = new HashMap<>();
    /** Safak'in isik yukleri: oyuncu -> (hedef, sayi, son vurus zamani) */
    private final Map<UUID, IsikYuku> isikYukleri = new HashMap<>();

    private static final class IsikYuku {
        UUID hedef;
        int sayi;
        long sonVurus;
    }
    private BukkitTask denetimGorevi;

    public SilahDinleyici(SinifSistemi eklenti) {
        this.eklenti = eklenti;
    }

    /** Elde tutma denetimi + kan damlama parcaciklari. */
    public void gorevBaslat() {
        gorevDurdur();
        denetimGorevi = Bukkit.getScheduler().runTaskTimer(eklenti, () -> {
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                ItemStack elde = oyuncu.getInventory().getItemInMainHand();
                Silah silah = eklenti.getSilahYoneticisi().tani(elde);
                if (silah == null) {
                    continue;
                }

                if (!kullanabilir(oyuncu, silah)) {
                    elindenAl(oyuncu, silah, elde);
                    continue;
                }

                // Sol agizdan sizan kan (yalnizca balta)
                if (silah == Silah.KANLI_SAVAS_BALTASI
                        && eklenti.getConfig().getBoolean("silahlar.kan-damlama-efekti", true)) {
                    damlaEfekti(oyuncu);
                }
            }
        }, 20L, 10L);
    }

    public void gorevDurdur() {
        if (denetimGorevi != null) {
            denetimGorevi.cancel();
            denetimGorevi = null;
        }
    }

    // ---------------- Sinif kisiti ----------------

    private boolean kullanabilir(Player oyuncu, Silah silah) {
        if (oyuncu.hasPermission("sinif.silah.serbest")) {
            return true;
        }
        return eklenti.getDepo().getSinif(oyuncu) == silah.gerekliSinif();
    }

    private void uyar(Player oyuncu, Silah silah) {
        long simdi = System.currentTimeMillis();
        Long son = uyariZamani.get(oyuncu.getUniqueId());
        if (son != null && simdi - son < 3000L) {
            return;
        }
        uyariZamani.put(oyuncu.getUniqueId(), simdi);

        Mesaj.gonder(oyuncu, "silah-sinif-uyusmuyor", Mesaj.degisken(
                "silah", silah.renkliAd(),
                "sinif", silah.gerekliSinif().basitRenkliAd()));
        oyuncu.playSound(oyuncu.getLocation(), "entity.villager.no", 1.0f, 0.8f);
    }

    /** Yanlis sinif silahi elinde tutamaz: envantere geri konur. */
    private void elindenAl(Player oyuncu, Silah silah, ItemStack esya) {
        uyar(oyuncu, silah);

        if (!eklenti.getConfig().getBoolean("silahlar.yanlis-sinifta-elden-cikar", true)) {
            return;
        }

        oyuncu.getInventory().setItemInMainHand(null);
        Map<Integer, ItemStack> artan = oyuncu.getInventory().addItem(esya);
        for (ItemStack kalan : artan.values()) {
            oyuncu.getWorld().dropItemNaturally(oyuncu.getLocation(), kalan);
        }
        oyuncu.updateInventory();
    }

    // ---------------- Vurus ----------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void vurus(EntityDamageByEntityEvent olay) {
        if (!(olay.getDamager() instanceof Player saldiran)) {
            return;
        }
        ItemStack elde = saldiran.getInventory().getItemInMainHand();
        Silah silah = eklenti.getSilahYoneticisi().tani(elde);
        if (silah == null) {
            return;
        }

        if (!kullanabilir(saldiran, silah)) {
            olay.setCancelled(true);
            uyar(saldiran, silah);
            return;
        }

        // Kan Firtinasi'nin kendi hasari pasiflerle iki kez carpilmasin
        if (firtinaIcinde.contains(saldiran.getUniqueId())) {
            return;
        }

        // Saldiran gizliyse gölge dagilir
        if (eklenti.getConfig().getBoolean(
                "silahlar.golge_pelerini.vanish-saldirinca-bozulur", true)) {
            eklenti.getGolgeYoneticisi().boz(saldiran);
        }

        switch (silah) {
            case ALACAKARANLIK -> hancerVurus(olay, saldiran, silah, true);
            case SAFAK -> hancerVurus(olay, saldiran, silah, false);
            case GOLGE_PELERINI -> {
                // Pelerin bir silah degil, vurus bonusu yok
            }
            default -> baltaVurus(olay, saldiran, silah);
        }
    }

    // ---------------- Kanli Savas Baltasi ----------------

    private void baltaVurus(EntityDamageByEntityEvent olay, Player saldiran, Silah silah) {
        String yol = "silahlar." + silah.kod() + ".";
        double carpan = eklenti.getConfig().getDouble(yol + "hasar-carpani", 1.00);

        // ---- Pasif 1: Öfke — kendi canin azaldikca daha sert vurursun
        double ofkeTavan = eklenti.getConfig().getDouble(yol + "ofke-en-fazla", 0.40);
        double eksikOran = 1.0 - oran(saldiran);
        carpan += ofkeTavan * Math.max(0.0, eksikOran);

        LivingEntity hedef = (olay.getEntity() instanceof LivingEntity canli) ? canli : null;

        boolean hasat = false;
        if (hedef != null) {
            // ---- Pasif 2: Kanli Hasat — zaten kanayan hedefe fazladan hasar
            if (eklenti.getKanamaYoneticisi().kaniyorMu(hedef)) {
                carpan += eklenti.getConfig().getDouble(yol + "hasat-bonusu", 0.25);
                hasat = true;
            }
        }

        olay.setDamage(olay.getDamage() * carpan);

        if (hedef == null) {
            return;
        }

        if (hasat) {
            KanamaYoneticisi.parcacik(hedef.getLocation());
        }

        int sure = eklenti.getConfig().getInt(yol + "kanama-suresi", 6);
        double kanamaHasari = eklenti.getConfig().getDouble(yol + "kanama-hasari", 2.5);
        double emis = eklenti.getConfig().getDouble(yol + "can-emis-orani", 0.35);

        if (sure > 0 && kanamaHasari > 0) {
            eklenti.getKanamaYoneticisi().uygula(hedef, saldiran, sure, kanamaHasari, emis);
        }

        KanamaYoneticisi.parcacik(hedef.getLocation());
        saldiran.playSound(hedef.getLocation(), "entity.player.attack.crit", 0.8f, 0.7f);
    }

    // ---------------- Kan Zirhi: cevredeki kanayanlar seni korur ----------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void hasarAlma(EntityDamageEvent olay) {
        if (!(olay.getEntity() instanceof Player oyuncu)) {
            return;
        }

        // Gizliyken hasar alinca gölge dagilir
        if (eklenti.getConfig().getBoolean(
                "silahlar.golge_pelerini.vanish-hasar-alinca-bozulur", true)) {
            eklenti.getGolgeYoneticisi().boz(oyuncu);
        }

        Silah silah = eklenti.getSilahYoneticisi()
                .tani(oyuncu.getInventory().getItemInMainHand());
        if (silah != Silah.KANLI_SAVAS_BALTASI || !kullanabilir(oyuncu, silah)) {
            return;
        }

        String yol = "silahlar." + silah.kod() + ".";
        double menzil = eklenti.getConfig().getDouble(yol + "zirh-menzili", 6.0);
        double basina = eklenti.getConfig().getDouble(yol + "zirh-hedef-basina", 0.08);
        double tavan = eklenti.getConfig().getDouble(yol + "zirh-en-fazla", 0.32);

        int kanayan = 0;
        for (var varlik : oyuncu.getNearbyEntities(menzil, menzil, menzil)) {
            if (varlik instanceof LivingEntity canli
                    && eklenti.getKanamaYoneticisi().kaniyorMu(canli)) {
                kanayan++;
            }
        }
        if (kanayan == 0) {
            return;
        }

        double indirim = Math.min(tavan, basina * kanayan);
        olay.setDamage(olay.getDamage() * (1.0 - indirim));
        oyuncu.spawnParticle(Particle.DUST, oyuncu.getLocation().add(0, 1.1, 0),
                6, 0.4, 0.5, 0.4, 0.0,
                new Particle.DustOptions(Color.fromRGB(150, 12, 16), 1.0f));
    }

    // ---------------- Hancerler: Alacakaranlik & Safak ----------------

    private void hancerVurus(EntityDamageByEntityEvent olay, Player saldiran,
                             Silah silah, boolean karanlik) {
        String yol = "silahlar." + silah.kod() + ".";
        double carpan = 1.0;

        // Kardes Agiz: iki hancer birlikte tasiniyorsa
        Silah digerEl = eklenti.getSilahYoneticisi()
                .tani(saldiran.getInventory().getItemInOffHand());
        Silah beklenen = karanlik ? Silah.SAFAK : Silah.ALACAKARANLIK;
        if (digerEl == beklenen) {
            carpan += eklenti.getConfig().getDouble(yol + "ikili-bonus", 0.15);
        }

        LivingEntity hedef = (olay.getEntity() instanceof LivingEntity canli) ? canli : null;

        if (karanlik) {
            // Golgeden Vurus: arkadan veya gorunmezken
            boolean gizli = eklenti.getGolgeYoneticisi().gizliMi(saldiran)
                    || saldiran.hasPotionEffect(PotionEffectType.INVISIBILITY);
            if (hedef != null && (gizli || arkadanMi(saldiran, hedef))) {
                carpan += eklenti.getConfig().getDouble(yol + "golge-bonusu", 0.80);
                int korluk = eklenti.getConfig().getInt(yol + "korluk-suresi", 2);
                if (korluk > 0) {
                    hedef.addPotionEffect(new PotionEffect(
                            PotionEffectType.BLINDNESS, korluk * 20, 0, false, true, true));
                }
                saldiran.playSound(saldiran.getLocation(),
                        "entity.illusioner.prepare_blindness", 0.9f, 1.3f);
                saldiran.spawnParticle(Particle.SMOKE,
                        hedef.getLocation().add(0, 1.0, 0), 15, 0.3, 0.4, 0.3, 0.02);
            }
            olay.setDamage(olay.getDamage() * carpan);
            return;
        }

        // Safak: Isik Yuku
        double yukBasina = eklenti.getConfig().getDouble(yol + "yuk-basina", 0.12);
        int yukTavani = eklenti.getConfig().getInt(yol + "yuk-tavani", 5);
        int unutma = eklenti.getConfig().getInt(yol + "yuk-unutma-suresi", 6);

        IsikYuku yuk = isikYukleri.computeIfAbsent(saldiran.getUniqueId(), k -> new IsikYuku());
        long simdi = System.currentTimeMillis();
        boolean ayniHedef = hedef != null && hedef.getUniqueId().equals(yuk.hedef);
        if (!ayniHedef || simdi - yuk.sonVurus > unutma * 1000L) {
            yuk.sayi = 0;
            yuk.hedef = hedef == null ? null : hedef.getUniqueId();
        }
        yuk.sonVurus = simdi;
        yuk.sayi++;

        carpan += yukBasina * (yuk.sayi - 1);
        olay.setDamage(olay.getDamage() * carpan);

        if (yuk.sayi >= yukTavani && hedef != null) {
            yuk.sayi = 0;
            double ekHasar = eklenti.getConfig().getDouble(yol + "yuk-patlama-hasari", 6.0);
            double sifa = eklenti.getConfig().getDouble(yol + "yuk-patlama-sifasi", 4.0);
            olay.setDamage(olay.getDamage() + ekHasar);
            iyilestir(saldiran, sifa);
            hedef.getWorld().spawnParticle(Particle.END_ROD,
                    hedef.getLocation().add(0, 1.0, 0), 30, 0.4, 0.6, 0.4, 0.05);
            hedef.getWorld().playSound(hedef.getLocation(),
                    "block.beacon.activate", 0.8f, 1.6f);
            Mesaj.gonder(saldiran, "isik-patlamasi", null);
        } else {
            saldiran.spawnParticle(Particle.END_ROD,
                    saldiran.getLocation().add(0, 1.2, 0), yuk.sayi * 2, 0.3, 0.3, 0.3, 0.01);
        }
    }

    /** Hedefin arkasindan mi vuruluyor? */
    private boolean arkadanMi(Player saldiran, LivingEntity hedef) {
        Vector bakis = hedef.getLocation().getDirection().setY(0);
        Vector fark = saldiran.getLocation().toVector()
                .subtract(hedef.getLocation().toVector()).setY(0);
        if (bakis.lengthSquared() < 0.0001 || fark.lengthSquared() < 0.0001) {
            return false;
        }
        return bakis.normalize().dot(fark.normalize()) < -0.4;
    }

    @SuppressWarnings("deprecation")
    private void iyilestir(Player oyuncu, double miktar) {
        double tavan = oyuncu.getMaxHealth();
        oyuncu.setHealth(Math.min(tavan, oyuncu.getHealth() + miktar));
    }

    // ---------------- Sag tik yetenegi: Kan Cagrisi ----------------

    @EventHandler
    public void sagTik(PlayerInteractEvent olay) {
        Action eylem = olay.getAction();
        if (eylem != Action.RIGHT_CLICK_AIR && eylem != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (olay.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) {
            return;
        }

        Player oyuncu = olay.getPlayer();
        Silah silah = eklenti.getSilahYoneticisi()
                .tani(oyuncu.getInventory().getItemInMainHand());
        if (silah == null) {
            return;
        }

        olay.setCancelled(true);

        if (!kullanabilir(oyuncu, silah)) {
            uyar(oyuncu, silah);
            return;
        }

        switch (silah) {
            case ALACAKARANLIK -> {
                golgeSicramasi(oyuncu, silah);
                return;
            }
            case SAFAK -> {
                safakKesisi(oyuncu, silah);
                return;
            }
            case GOLGE_PELERINI -> {
                golgeyeKaris(oyuncu, silah);
                return;
            }
            default -> {
                // Balta asagidaki Kan Cagrisi / Kan Firtinasi ile devam eder
            }
        }

        if (oyuncu.isSneaking()) {
            firtina(oyuncu, silah);
            return;
        }

        int bekleme = eklenti.getConfig()
                .getInt("silahlar." + silah.kod() + ".yetenek-bekleme", 20);
        long simdi = System.currentTimeMillis();
        Long son = yetenekBekleme.get(oyuncu.getUniqueId());
        if (son != null && simdi - son < bekleme * 1000L) {
            long kalan = (bekleme * 1000L - (simdi - son) + 999) / 1000;
            Mesaj.gonder(oyuncu, "yetenek-bekleme",
                    Mesaj.degisken("saniye", String.valueOf(kalan)));
            return;
        }
        yetenekBekleme.put(oyuncu.getUniqueId(), simdi);

        kanCagrisi(oyuncu, silah);
    }

    private void kanCagrisi(Player oyuncu, Silah silah) {
        double menzil = eklenti.getConfig()
                .getDouble("silahlar." + silah.kod() + ".yetenek-menzili", 5.0);
        int sure = eklenti.getConfig()
                .getInt("silahlar." + silah.kod() + ".yetenek-kanama-suresi", 7);
        double hasar = eklenti.getConfig()
                .getDouble("silahlar." + silah.kod() + ".kanama-hasari", 2.5);
        double emis = eklenti.getConfig()
                .getDouble("silahlar." + silah.kod() + ".can-emis-orani", 0.35);

        int sayac = 0;
        for (var varlik : oyuncu.getNearbyEntities(menzil, menzil, menzil)) {
            if (!(varlik instanceof LivingEntity hedef) || hedef.equals(oyuncu)) {
                continue;
            }
            eklenti.getKanamaYoneticisi().uygula(hedef, oyuncu, sure, hasar, emis);
            KanamaYoneticisi.parcacik(hedef.getLocation());
            sayac++;
        }

        // Kullaniciya kisa sureli guc (potion effect degil, gecici attribute)
        double gucOrani = eklenti.getConfig()
                .getDouble("silahlar." + silah.kod() + ".yetenek-guc-yuzde", 0.25);
        long gucSuresi = eklenti.getConfig()
                .getLong("silahlar." + silah.kod() + ".yetenek-guc-suresi", 5) * 20L;
        eklenti.getYetenekYoneticisi().geciciSaldiriGucu(oyuncu, gucOrani, gucSuresi);

        // Gorsel halka
        Location merkez = oyuncu.getLocation();
        if (merkez.getWorld() != null) {
            for (int i = 0; i < 40; i++) {
                double aci = Math.PI * 2 * i / 40.0;
                Location nokta = merkez.clone().add(
                        Math.cos(aci) * menzil, 0.25, Math.sin(aci) * menzil);
                merkez.getWorld().spawnParticle(Particle.DUST, nokta, 2, 0.05, 0.1, 0.05, 0.0,
                        new Particle.DustOptions(Color.fromRGB(170, 14, 18), 1.4f));
            }
            merkez.getWorld().playSound(merkez, "entity.ravager.roar", 0.7f, 1.4f);
        }

        Mesaj.gonder(oyuncu, "kan-cagrisi", Mesaj.degisken("sayi", String.valueOf(sayac)));
    }

    // ---------------- Shift + sag tik: Kan Firtinasi ----------------

    private void firtina(Player oyuncu, Silah silah) {
        String yol = "silahlar." + silah.kod() + ".";
        int bekleme = eklenti.getConfig().getInt(yol + "firtina-bekleme", 35);
        long simdi = System.currentTimeMillis();
        Long son = firtinaBekleme.get(oyuncu.getUniqueId());
        if (son != null && simdi - son < bekleme * 1000L) {
            long kalan = (bekleme * 1000L - (simdi - son) + 999) / 1000;
            Mesaj.gonder(oyuncu, "yetenek-bekleme",
                    Mesaj.degisken("saniye", String.valueOf(kalan)));
            return;
        }
        firtinaBekleme.put(oyuncu.getUniqueId(), simdi);

        double menzil = eklenti.getConfig().getDouble(yol + "firtina-menzili", 4.0);
        double hasar = eklenti.getConfig().getDouble(yol + "firtina-hasari", 8.0);
        double savurma = eklenti.getConfig().getDouble(yol + "firtina-savurma", 1.1);
        int kanamaSuresi = eklenti.getConfig().getInt(yol + "firtina-kanama-suresi", 5);
        double kanamaHasari = eklenti.getConfig().getDouble(yol + "kanama-hasari", 2.5);
        double emis = eklenti.getConfig().getDouble(yol + "can-emis-orani", 0.35);

        int sayac = 0;
        firtinaIcinde.add(oyuncu.getUniqueId());
        try {
        for (var varlik : oyuncu.getNearbyEntities(menzil, menzil, menzil)) {
            if (!(varlik instanceof LivingEntity hedef) || hedef.equals(oyuncu)) {
                continue;
            }
            hedef.damage(hasar, oyuncu);
            var yon = hedef.getLocation().toVector()
                    .subtract(oyuncu.getLocation().toVector()).setY(0);
            if (yon.lengthSquared() > 0.0001) {
                hedef.setVelocity(yon.normalize().multiply(savurma).setY(0.45));
            }
            eklenti.getKanamaYoneticisi()
                    .uygula(hedef, oyuncu, kanamaSuresi, kanamaHasari, emis);
            KanamaYoneticisi.parcacik(hedef.getLocation());
            sayac++;
        }
        } finally {
            firtinaIcinde.remove(oyuncu.getUniqueId());
        }

        Location merkez = oyuncu.getLocation();
        if (merkez.getWorld() != null) {
            for (int tur = 0; tur < 3; tur++) {
                double yaricap = menzil * (0.4 + tur * 0.3);
                for (int i = 0; i < 30; i++) {
                    double aci = Math.PI * 2 * i / 30.0 + tur * 0.4;
                    Location nokta = merkez.clone().add(
                            Math.cos(aci) * yaricap, 0.4 + tur * 0.35, Math.sin(aci) * yaricap);
                    merkez.getWorld().spawnParticle(Particle.DUST, nokta, 1, 0, 0, 0, 0.0,
                            new Particle.DustOptions(Color.fromRGB(190, 20, 24), 1.5f));
                }
            }
            merkez.getWorld().playSound(merkez, "entity.wither.shoot", 0.8f, 0.6f);
            merkez.getWorld().playSound(merkez, "item.trident.riptide_3", 1.0f, 0.7f);
        }

        Mesaj.gonder(oyuncu, "kan-firtinasi", Mesaj.degisken("sayi", String.valueOf(sayac)));
    }

    // ---------------- Alacakaranlik: Golge Sicramasi ----------------

    private void golgeSicramasi(Player oyuncu, Silah silah) {
        String yol = "silahlar." + silah.kod() + ".";
        if (!beklemeUygun(hancerBekleme, oyuncu,
                eklenti.getConfig().getInt(yol + "sicrama-bekleme", 12))) {
            return;
        }

        double menzil = eklenti.getConfig().getDouble(yol + "sicrama-menzili", 8.0);
        LivingEntity hedef = null;
        double enYakin = Double.MAX_VALUE;
        for (var varlik : oyuncu.getNearbyEntities(menzil, menzil, menzil)) {
            if (!(varlik instanceof LivingEntity canli) || canli.equals(oyuncu)) {
                continue;
            }
            double uzaklik = canli.getLocation().distanceSquared(oyuncu.getLocation());
            if (uzaklik < enYakin) {
                enYakin = uzaklik;
                hedef = canli;
            }
        }

        if (hedef == null) {
            hancerBekleme.remove(oyuncu.getUniqueId());
            Mesaj.gonder(oyuncu, "golge-hedef-yok", null);
            return;
        }

        Location eski = oyuncu.getLocation().clone();
        Location arka = hedef.getLocation().clone();
        Vector bakis = arka.getDirection().setY(0);
        if (bakis.lengthSquared() > 0.0001) {
            arka.add(bakis.normalize().multiply(-1.3));
        }
        arka.setDirection(hedef.getLocation().getDirection());
        arka.setY(hedef.getLocation().getY());

        oyuncu.teleport(arka);
        oyuncu.addPotionEffect(new PotionEffect(
                PotionEffectType.SPEED, 60, 1, false, false, true));

        if (eski.getWorld() != null) {
            eski.getWorld().spawnParticle(Particle.SMOKE, eski.add(0, 1, 0),
                    30, 0.3, 0.6, 0.3, 0.03);
            eski.getWorld().playSound(eski, "entity.enderman.teleport", 0.8f, 0.6f);
        }
        oyuncu.getWorld().spawnParticle(Particle.SMOKE,
                oyuncu.getLocation().add(0, 1, 0), 30, 0.3, 0.6, 0.3, 0.03);

        String ad = hedef instanceof Player kisi ? kisi.getName()
                : hedef.getType().name().toLowerCase(java.util.Locale.ROOT);
        Mesaj.gonder(oyuncu, "golge-sicramasi", Mesaj.degisken("hedef", ad));
    }

    // ---------------- Safak: Safak Kesisi ----------------

    private void safakKesisi(Player oyuncu, Silah silah) {
        String yol = "silahlar." + silah.kod() + ".";
        if (!beklemeUygun(hancerBekleme, oyuncu,
                eklenti.getConfig().getInt(yol + "kesis-bekleme", 14))) {
            return;
        }

        double menzil = eklenti.getConfig().getDouble(yol + "kesis-menzili", 4.5);
        double hasar = eklenti.getConfig().getDouble(yol + "kesis-hasari", 6.0);
        double atilma = eklenti.getConfig().getDouble(yol + "kesis-atilma", 0.9);

        Vector bakis = oyuncu.getLocation().getDirection().setY(0);
        if (bakis.lengthSquared() > 0.0001) {
            oyuncu.setVelocity(bakis.normalize().multiply(atilma).setY(0.25));
        }

        int sayac = 0;
        firtinaIcinde.add(oyuncu.getUniqueId());
        try {
            for (var varlik : oyuncu.getNearbyEntities(menzil, menzil, menzil)) {
                if (!(varlik instanceof LivingEntity hedef) || hedef.equals(oyuncu)) {
                    continue;
                }
                // Yalnizca onundekiler (yarim daire)
                Vector fark = hedef.getLocation().toVector()
                        .subtract(oyuncu.getLocation().toVector()).setY(0);
                if (fark.lengthSquared() < 0.0001
                        || bakis.lengthSquared() < 0.0001
                        || bakis.clone().normalize().dot(fark.normalize()) < 0.35) {
                    continue;
                }
                hedef.damage(hasar, oyuncu);
                hedef.getWorld().spawnParticle(Particle.END_ROD,
                        hedef.getLocation().add(0, 1.0, 0), 12, 0.3, 0.4, 0.3, 0.02);
                sayac++;
            }
        } finally {
            firtinaIcinde.remove(oyuncu.getUniqueId());
        }

        Location merkez = oyuncu.getLocation();
        if (merkez.getWorld() != null) {
            for (int i = 0; i < 25; i++) {
                double aci = -Math.PI / 3 + (Math.PI * 2 / 3) * i / 24.0;
                Vector yon = bakis.clone().normalize().rotateAroundY(aci);
                merkez.getWorld().spawnParticle(Particle.END_ROD,
                        merkez.clone().add(yon.multiply(menzil * 0.7)).add(0, 1.0, 0),
                        1, 0, 0, 0, 0.0);
            }
            merkez.getWorld().playSound(merkez, "entity.player.attack.sweep", 1.0f, 1.5f);
        }

        Mesaj.gonder(oyuncu, "safak-kesisi", Mesaj.degisken("sayi", String.valueOf(sayac)));
    }

    // ---------------- Golge Pelerini: Golgeye Karis ----------------

    private void golgeyeKaris(Player oyuncu, Silah silah) {
        String yol = "silahlar." + silah.kod() + ".";
        if (eklenti.getGolgeYoneticisi().gizliMi(oyuncu)) {
            eklenti.getGolgeYoneticisi().boz(oyuncu);
            return;
        }
        if (!beklemeUygun(pelerinBekleme, oyuncu,
                eklenti.getConfig().getInt(yol + "vanish-bekleme", 45))) {
            return;
        }
        int sure = eklenti.getConfig().getInt(yol + "vanish-suresi", 10);
        eklenti.getGolgeYoneticisi().gizle(oyuncu, sure);
    }

    /** Ortak bekleme kontrolu: uygunsa zamani isler ve true doner. */
    private boolean beklemeUygun(Map<UUID, Long> harita, Player oyuncu, int saniye) {
        long simdi = System.currentTimeMillis();
        Long son = harita.get(oyuncu.getUniqueId());
        if (son != null && simdi - son < saniye * 1000L) {
            long kalan = (saniye * 1000L - (simdi - son) + 999) / 1000;
            Mesaj.gonder(oyuncu, "yetenek-bekleme",
                    Mesaj.degisken("saniye", String.valueOf(kalan)));
            return false;
        }
        harita.put(oyuncu.getUniqueId(), simdi);
        return true;
    }

    @EventHandler
    public void cikis(PlayerQuitEvent olay) {
        eklenti.getGolgeYoneticisi().boz(olay.getPlayer());
        isikYukleri.remove(olay.getPlayer().getUniqueId());
    }

    // ---------------- Oldurme odulu: Kan Kalkani ----------------

    @EventHandler(priority = EventPriority.MONITOR)
    public void olum(EntityDeathEvent olay) {
        LivingEntity olen = olay.getEntity();
        Player katil = olen.getKiller();
        if (katil == null) {
            return;
        }
        Silah silah = eklenti.getSilahYoneticisi()
                .tani(katil.getInventory().getItemInMainHand());
        if (silah == null || !kullanabilir(katil, silah)) {
            return;
        }

        String yol = "silahlar." + silah.kod() + ".";
        double kalkan = eklenti.getConfig().getDouble(yol + "kalkan-miktari", 4.0);
        double tavan = eklenti.getConfig().getDouble(yol + "kalkan-tavani", 8.0);
        int indirim = eklenti.getConfig().getInt(yol + "oldurme-bekleme-indirimi", 5);

        if (kalkan > 0) {
            double yeni = Math.min(tavan, katil.getAbsorptionAmount() + kalkan);
            katil.setAbsorptionAmount(yeni);
        }

        // Bekleme sureleri kisalir: her oldurme yeteneklerini one ceker
        indirimUygula(yetenekBekleme, katil.getUniqueId(), indirim);
        indirimUygula(firtinaBekleme, katil.getUniqueId(), indirim);

        KanamaYoneticisi.parcacik(olen.getLocation());
        katil.playSound(katil.getLocation(), "entity.player.levelup", 0.5f, 0.6f);
        Mesaj.gonder(katil, "kan-kalkani",
                Mesaj.degisken("kalp", bicim(katil.getAbsorptionAmount() / 2.0)));
    }

    private void indirimUygula(Map<UUID, Long> harita, UUID kimlik, int saniye) {
        Long son = harita.get(kimlik);
        if (son != null) {
            harita.put(kimlik, son - saniye * 1000L);
        }
    }

    /** Varligin can orani (0.0 - 1.0). */
    @SuppressWarnings("deprecation")
    private double oran(LivingEntity varlik) {
        double tavan = varlik.getMaxHealth();
        if (tavan <= 0) {
            return 1.0;
        }
        return Math.max(0.0, Math.min(1.0, varlik.getHealth() / tavan));
    }

    private String bicim(double deger) {
        return String.valueOf(Math.round(deger * 10.0) / 10.0);
    }

    // ---------------- Damlama efekti ----------------

    private void damlaEfekti(Player oyuncu) {
        Location konum = oyuncu.getLocation();
        if (konum.getWorld() == null || Math.random() > 0.55) {
            return;
        }
        Location nokta = konum.clone().add(
                (Math.random() - 0.5) * 0.7, 1.05, (Math.random() - 0.5) * 0.7);
        konum.getWorld().spawnParticle(Particle.DUST, nokta, 1, 0.02, 0.02, 0.02, 0.0,
                new Particle.DustOptions(Color.fromRGB(126, 10, 14), 0.8f));
    }
}
