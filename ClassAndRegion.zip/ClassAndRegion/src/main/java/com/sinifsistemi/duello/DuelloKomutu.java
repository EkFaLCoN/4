package com.sinifsistemi.duello;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * /duello <oyuncu>   - 10 blok icindeki oyuncuya davet gonderir
 * /duello kabul      - daveti kabul eder
 * /duello ret        - daveti reddeder
 *
 * /duelloalan olustur <ad> r=<yaricap>  - durdugun yeri merkez alir
 * /duelloalan sil <ad>
 * /duelloalan liste
 * /duelloalan bilgi
 */
public class DuelloKomutu implements CommandExecutor, TabCompleter {

    private final SinifSistemi eklenti;
    private final DuelloYoneticisi yonetici;
    private final boolean alanKomutu;

    public DuelloKomutu(SinifSistemi eklenti, DuelloYoneticisi yonetici, boolean alanKomutu) {
        this.eklenti = eklenti;
        this.yonetici = yonetici;
        this.alanKomutu = alanKomutu;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender gonderen, @NotNull Command komut,
                             @NotNull String etiket, @NotNull String[] a) {
        return alanKomutu ? alan(gonderen, a) : duello(gonderen, a);
    }

    // ---------------- /duello ----------------

    private boolean duello(CommandSender gonderen, String[] a) {
        if (!(gonderen instanceof Player oyuncu)) {
            Mesaj.gonder(gonderen, "sadece-oyuncu");
            return true;
        }
        if (a.length == 0) {
            Mesaj.gonderHam(oyuncu, "duello-kullanim");
            return true;
        }

        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "kabul", "accept" -> yonetici.kabulEt(oyuncu);
            case "ret", "reddet", "deny" -> yonetici.reddet(oyuncu);
            default -> {
                Player hedef = Bukkit.getPlayerExact(a[0]);
                if (hedef == null) {
                    Mesaj.gonder(oyuncu, "oyuncu-bulunamadi", Mesaj.degisken("oyuncu", a[0]));
                    return true;
                }
                yonetici.davetGonder(oyuncu, hedef);
            }
        }
        return true;
    }

    // ---------------- /duelloalan ----------------

    private boolean alan(CommandSender gonderen, String[] a) {
        if (!gonderen.hasPermission("duello.admin")) {
            Mesaj.gonder(gonderen, "yetkin-yok");
            return true;
        }
        if (a.length == 0) {
            Mesaj.gonderHam(gonderen, "duello-alan-kullanim");
            return true;
        }

        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "olustur", "ekle" -> {
                if (!(gonderen instanceof Player oyuncu)) {
                    Mesaj.gonder(gonderen, "sadece-oyuncu");
                    return true;
                }
                if (a.length < 3) {
                    Mesaj.gonderHam(gonderen, "duello-alan-kullanim");
                    return true;
                }
                String ad = a[1];
                Double yaricap = yaricapCoz(a[2]);
                if (yaricap == null || yaricap < 3 || yaricap > 500) {
                    Mesaj.gonder(gonderen, "duello-alan-gecersiz-yaricap");
                    return true;
                }
                GuvenliBolge bolge = GuvenliBolge.konumdan(ad, oyuncu.getLocation(), yaricap);
                if (!yonetici.bolgeEkle(bolge)) {
                    Mesaj.gonder(gonderen, "duello-alan-zaten-var", Mesaj.degisken("ad", ad));
                    return true;
                }
                Mesaj.gonder(gonderen, "duello-alan-olusturuldu",
                        Mesaj.degisken("ad", ad, "yaricap", String.valueOf(yaricap.intValue())));
            }
            case "sil", "kaldir" -> {
                if (a.length < 2) {
                    Mesaj.gonderHam(gonderen, "duello-alan-kullanim");
                    return true;
                }
                if (!yonetici.bolgeSil(a[1])) {
                    Mesaj.gonder(gonderen, "duello-alan-yok", Mesaj.degisken("ad", a[1]));
                    return true;
                }
                Mesaj.gonder(gonderen, "duello-alan-silindi", Mesaj.degisken("ad", a[1]));
            }
            case "liste" -> {
                List<GuvenliBolge> liste = yonetici.bolgeler();
                gonderen.sendMessage(Mesaj.ayristir(Mesaj.ham("bilgi-baslik")));
                gonderen.sendMessage(Mesaj.ayristir(" <gold><bold>GÜVENLİ BÖLGELER"));
                gonderen.sendMessage(Mesaj.ayristir(""));
                if (liste.isEmpty()) {
                    gonderen.sendMessage(Mesaj.ayristir(" <gray>Henüz bölge yok."));
                    gonderen.sendMessage(Mesaj.ayristir(
                            " <dark_gray>/duelloalan olustur <ad> r=25"));
                }
                for (GuvenliBolge bolge : liste) {
                    Location merkez = bolge.merkez();
                    String konum = merkez == null ? "?"
                            : (int) merkez.getX() + ", " + (int) merkez.getY()
                              + ", " + (int) merkez.getZ();
                    gonderen.sendMessage(Mesaj.ayristir(
                            " <yellow>" + bolge.ad() + " <dark_gray>- <gray>"
                            + bolge.dunyaAdi() + " <dark_gray>| <white>" + konum
                            + " <dark_gray>| <gray>r=<white>" + (int) bolge.yaricap()));
                }
                gonderen.sendMessage(Mesaj.ayristir(Mesaj.ham("bilgi-baslik")));
            }
            case "bilgi" -> {
                if (!(gonderen instanceof Player oyuncu)) {
                    Mesaj.gonder(gonderen, "sadece-oyuncu");
                    return true;
                }
                GuvenliBolge bolge = yonetici.bolgeBul(oyuncu.getLocation());
                if (bolge == null) {
                    Mesaj.gonder(gonderen, "duello-alan-disindasin");
                    return true;
                }
                Mesaj.gonder(gonderen, "duello-alan-icindesin",
                        Mesaj.degisken("ad", bolge.ad(),
                                "mesafe", String.valueOf(
                                        (int) (bolge.yaricap()
                                               - bolge.mesafe(oyuncu.getLocation())))));
            }
            default -> Mesaj.gonderHam(gonderen, "duello-alan-kullanim");
        }
        return true;
    }

    /** "r=25" veya "25" bicimini sayiya cevirir. */
    private Double yaricapCoz(String metin) {
        String temiz = metin.trim().toLowerCase(Locale.ROOT);
        if (temiz.startsWith("r=")) {
            temiz = temiz.substring(2);
        } else if (temiz.startsWith("r:")) {
            temiz = temiz.substring(2);
        }
        try {
            return Double.parseDouble(temiz);
        } catch (NumberFormatException hata) {
            return null;
        }
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender gonderen, @NotNull Command komut,
                                      @NotNull String etiket, @NotNull String[] a) {
        List<String> sonuc = new ArrayList<>();

        if (!alanKomutu) {
            if (a.length == 1) {
                String onek = a[0].toLowerCase(Locale.ROOT);
                for (String s : List.of("kabul", "ret")) {
                    if (s.startsWith(onek)) {
                        sonuc.add(s);
                    }
                }
                for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                    if (oyuncu.getName().toLowerCase(Locale.ROOT).startsWith(onek)
                            && !oyuncu.equals(gonderen)) {
                        sonuc.add(oyuncu.getName());
                    }
                }
            }
            return sonuc;
        }

        if (!gonderen.hasPermission("duello.admin")) {
            return sonuc;
        }
        if (a.length == 1) {
            for (String s : List.of("olustur", "sil", "liste", "bilgi")) {
                if (s.startsWith(a[0].toLowerCase(Locale.ROOT))) {
                    sonuc.add(s);
                }
            }
        } else if (a.length == 2 && a[0].equalsIgnoreCase("sil")) {
            for (GuvenliBolge bolge : yonetici.bolgeler()) {
                if (bolge.ad().toLowerCase(Locale.ROOT)
                        .startsWith(a[1].toLowerCase(Locale.ROOT))) {
                    sonuc.add(bolge.ad());
                }
            }
        } else if (a.length == 3 && a[0].equalsIgnoreCase("olustur")) {
            sonuc.add("r=15");
            sonuc.add("r=25");
            sonuc.add("r=50");
        }
        return sonuc;
    }
}
