package com.sinifsistemi.duello;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

/**
 * Tek bir duello oturumu.
 *
 * Basta iki oyuncunun envanteri, cani, acligi, efektleri ve konumu
 * yedeklenir; duello bitince aynen geri yuklenir. Boylece harcanan
 * iksirler, oklar ve zirh dayanikliligi geri gelir.
 */
public class DuelloOturumu {

    /** Bir oyuncunun duello oncesi tam durumu. */
    public static class Yedek {
        final ItemStack[] envanter;
        final ItemStack[] zirh;
        final ItemStack yanEl;
        final double can;
        final double maxCan;
        final int aclik;
        final float doygunluk;
        final Location konum;
        final List<PotionEffect> efektler;
        final int deneyimSeviyesi;
        final float deneyimIlerleme;

        Yedek(Player oyuncu) {
            this.envanter = oyuncu.getInventory().getContents().clone();
            this.zirh = oyuncu.getInventory().getArmorContents().clone();
            this.yanEl = oyuncu.getInventory().getItemInOffHand().clone();
            this.can = oyuncu.getHealth();
            this.maxCan = oyuncu.getMaxHealth();
            this.aclik = oyuncu.getFoodLevel();
            this.doygunluk = oyuncu.getSaturation();
            this.konum = oyuncu.getLocation().clone();
            this.efektler = new ArrayList<>(oyuncu.getActivePotionEffects());
            this.deneyimSeviyesi = oyuncu.getLevel();
            this.deneyimIlerleme = oyuncu.getExp();
        }

        /** Oyuncuyu duello oncesi haline dondurur. */
        void geriYukle(Player oyuncu) {
            // Duelloda kazanilan/kaybedilen her sey silinir
            oyuncu.getInventory().clear();
            oyuncu.getInventory().setContents(envanter);
            oyuncu.getInventory().setArmorContents(zirh);
            oyuncu.getInventory().setItemInOffHand(yanEl);

            for (PotionEffect efekt : new ArrayList<>(oyuncu.getActivePotionEffects())) {
                oyuncu.removePotionEffect(efekt.getType());
            }
            for (PotionEffect efekt : efektler) {
                oyuncu.addPotionEffect(efekt);
            }

            oyuncu.setHealth(Math.min(can, oyuncu.getMaxHealth()));
            oyuncu.setFoodLevel(aclik);
            oyuncu.setSaturation(doygunluk);
            oyuncu.setLevel(deneyimSeviyesi);
            oyuncu.setExp(deneyimIlerleme);
            oyuncu.setFireTicks(0);
            oyuncu.updateInventory();
        }

        public Location konum() {
            return konum;
        }
    }

    private final UUID birinci;
    private final UUID ikinci;
    private final Yedek birinciYedek;
    private final Yedek ikinciYedek;
    private final GuvenliBolge bolge;
    private final long baslangic;
    private boolean bitti;

    public DuelloOturumu(Player a, Player b, GuvenliBolge bolge) {
        this.birinci = a.getUniqueId();
        this.ikinci = b.getUniqueId();
        this.birinciYedek = new Yedek(a);
        this.ikinciYedek = new Yedek(b);
        this.bolge = bolge;
        this.baslangic = System.currentTimeMillis();
    }

    public UUID birinci() {
        return birinci;
    }

    public UUID ikinci() {
        return ikinci;
    }

    public GuvenliBolge bolge() {
        return bolge;
    }

    public boolean bittiMi() {
        return bitti;
    }

    public void bitir() {
        this.bitti = true;
    }

    public long gecenSaniye() {
        return (System.currentTimeMillis() - baslangic) / 1000L;
    }

    public boolean icerir(UUID kimlik) {
        return birinci.equals(kimlik) || ikinci.equals(kimlik);
    }

    public UUID rakip(UUID kimlik) {
        if (birinci.equals(kimlik)) {
            return ikinci;
        }
        if (ikinci.equals(kimlik)) {
            return birinci;
        }
        return null;
    }

    public Yedek yedek(UUID kimlik) {
        return birinci.equals(kimlik) ? birinciYedek : ikinciYedek;
    }

    public Collection<UUID> katilimcilar() {
        return List.of(birinci, ikinci);
    }
}
