package com.sinifsistemi.duello;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.AreaEffectCloudApplyEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * DUELLO SISTEMI
 *
 * - /duello <oyuncu> : 10 blok icindeki oyuncuya davet gonderir
 * - Yalnizca GUVENLI BOLGE icinde duello atilabilir
 * - Guvenli bolgede duello disi PvP kapalidir
 * - Duello sirasinda bolgeden cikilamaz
 * - Olumcul hasarda oyuncu OLMEZ; 1 canla duello biter
 * - Harcanan iksir, ok ve zirh dayanikligi duello sonunda GERI GELIR
 * - Duelloda atilan ok/iksir duello disindaki kimseye zarar vermez
 * - Kazanan sohbette duyurulur
 */
public class DuelloYoneticisi implements Listener {

    private final SinifSistemi eklenti;

    private final Map<UUID, DuelloOturumu> aktif = new HashMap<>();
    private final Map<UUID, Davet> davetler = new HashMap<>();
    private final List<GuvenliBolge> bolgeler = new ArrayList<>();

    private File bolgeDosyasi;
    private BukkitTask gorev;

    private record Davet(UUID gonderen, long zaman) {
    }

    public DuelloYoneticisi(SinifSistemi eklenti) {
        this.eklenti = eklenti;
    }

    // ================= Yasam dongusu =================

    public void baslat() {
        bolgeleriYukle();
        Bukkit.getPluginManager().registerEvents(this, eklenti);

        gorev = Bukkit.getScheduler().runTaskTimer(eklenti, this::tik, 20L, 20L);
    }

    public void durdur() {
        if (gorev != null) {
            gorev.cancel();
            gorev = null;
        }
        // Sunucu kapanirken devam eden duellolari beraberlikle bitir
        for (DuelloOturumu oturum : new ArrayList<>(aktif.values())) {
            if (!oturum.bittiMi()) {
                bitir(oturum, null, "sunucu");
            }
        }
    }

    private void tik() {
        long simdi = System.currentTimeMillis();

        // Suresi dolan davetleri temizle
        int davetSuresi = eklenti.getConfig().getInt("duello.davet-suresi", 30);
        davetler.entrySet().removeIf(g -> simdi - g.getValue().zaman() > davetSuresi * 1000L);

        // Sure limiti dolan duellolar beraberlik
        int limit = eklenti.getConfig().getInt("duello.sure-limiti", 180);
        if (limit <= 0) {
            return;
        }
        for (DuelloOturumu oturum : new ArrayList<>(aktif.values())) {
            if (!oturum.bittiMi() && oturum.gecenSaniye() >= limit) {
                bitir(oturum, null, "sure");
            }
        }
    }

    // ================= Guvenli bolgeler =================

    private void bolgeleriYukle() {
        bolgeler.clear();
        bolgeDosyasi = new File(eklenti.getDataFolder(), "guvenli_bolgeler.txt");
        if (!bolgeDosyasi.exists()) {
            try {
                if (!eklenti.getDataFolder().exists()) {
                    eklenti.getDataFolder().mkdirs();
                }
                bolgeDosyasi.createNewFile();
            } catch (IOException hata) {
                eklenti.getLogger().warning("guvenli_bolgeler.txt olusturulamadi: " + hata.getMessage());
            }
            return;
        }
        try {
            for (String satir : java.nio.file.Files.readAllLines(bolgeDosyasi.toPath())) {
                if (satir.isBlank() || satir.startsWith("#")) {
                    continue;
                }
                GuvenliBolge bolge = GuvenliBolge.satirdan(satir.trim());
                if (bolge != null) {
                    bolgeler.add(bolge);
                }
            }
            eklenti.getLogger().info(bolgeler.size() + " guvenli bolge yuklendi.");
        } catch (IOException hata) {
            eklenti.getLogger().warning("Guvenli bolgeler okunamadi: " + hata.getMessage());
        }
    }

    private void bolgeleriKaydet() {
        if (bolgeDosyasi == null) {
            return;
        }
        List<String> satirlar = new ArrayList<>();
        satirlar.add("# ad,dunya,x,y,z,yaricap");
        for (GuvenliBolge bolge : bolgeler) {
            satirlar.add(bolge.kayitSatiri());
        }
        try {
            java.nio.file.Files.write(bolgeDosyasi.toPath(), satirlar);
        } catch (IOException hata) {
            eklenti.getLogger().warning("Guvenli bolgeler kaydedilemedi: " + hata.getMessage());
        }
    }

    public GuvenliBolge bolgeBul(Location konum) {
        for (GuvenliBolge bolge : bolgeler) {
            if (bolge.icinde(konum)) {
                return bolge;
            }
        }
        return null;
    }

    public GuvenliBolge bolgeAdaGore(String ad) {
        for (GuvenliBolge bolge : bolgeler) {
            if (bolge.ad().equalsIgnoreCase(ad)) {
                return bolge;
            }
        }
        return null;
    }

    public List<GuvenliBolge> bolgeler() {
        return new ArrayList<>(bolgeler);
    }

    public boolean bolgeEkle(GuvenliBolge bolge) {
        if (bolgeAdaGore(bolge.ad()) != null) {
            return false;
        }
        bolgeler.add(bolge);
        bolgeleriKaydet();
        return true;
    }

    public boolean bolgeSil(String ad) {
        GuvenliBolge bolge = bolgeAdaGore(ad);
        if (bolge == null) {
            return false;
        }
        bolgeler.remove(bolge);
        bolgeleriKaydet();
        return true;
    }

    // ================= Davet ve baslatma =================

    public DuelloOturumu oturum(Player oyuncu) {
        DuelloOturumu o = aktif.get(oyuncu.getUniqueId());
        return (o == null || o.bittiMi()) ? null : o;
    }

    public boolean duellodaMi(Player oyuncu) {
        return oturum(oyuncu) != null;
    }

    /** Davet gonderir. Basarisizsa sebebi mesaj olarak iletir. */
    public void davetGonder(Player gonderen, Player hedef) {
        if (gonderen.equals(hedef)) {
            Mesaj.gonder(gonderen, "duello-kendine");
            return;
        }
        if (duellodaMi(gonderen) || duellodaMi(hedef)) {
            Mesaj.gonder(gonderen, "duello-zaten-icinde");
            return;
        }

        double menzil = eklenti.getConfig().getDouble("duello.davet-menzili", 10.0);
        if (!gonderen.getWorld().equals(hedef.getWorld())
                || gonderen.getLocation().distance(hedef.getLocation()) > menzil) {
            Mesaj.gonder(gonderen, "duello-uzak",
                    Mesaj.degisken("menzil", String.valueOf((int) menzil)));
            return;
        }

        GuvenliBolge bolge = bolgeBul(gonderen.getLocation());
        if (bolge == null || !bolge.icinde(hedef.getLocation())) {
            Mesaj.gonder(gonderen, "duello-bolge-disi");
            return;
        }

        davetler.put(hedef.getUniqueId(), new Davet(gonderen.getUniqueId(), System.currentTimeMillis()));

        int sure = eklenti.getConfig().getInt("duello.davet-suresi", 30);
        Mesaj.gonder(gonderen, "duello-davet-gonderildi",
                Mesaj.degisken("oyuncu", hedef.getName(), "saniye", String.valueOf(sure)));
        Mesaj.gonder(hedef, "duello-davet-alindi",
                Mesaj.degisken("oyuncu", gonderen.getName(), "saniye", String.valueOf(sure)));
    }

    public void kabulEt(Player kabulEden) {
        Davet davet = davetler.remove(kabulEden.getUniqueId());
        if (davet == null) {
            Mesaj.gonder(kabulEden, "duello-davet-yok");
            return;
        }
        Player gonderen = Bukkit.getPlayer(davet.gonderen());
        if (gonderen == null || !gonderen.isOnline()) {
            Mesaj.gonder(kabulEden, "duello-rakip-yok");
            return;
        }
        if (duellodaMi(gonderen) || duellodaMi(kabulEden)) {
            Mesaj.gonder(kabulEden, "duello-zaten-icinde");
            return;
        }

        GuvenliBolge bolge = bolgeBul(kabulEden.getLocation());
        if (bolge == null || !bolge.icinde(gonderen.getLocation())) {
            Mesaj.gonder(kabulEden, "duello-bolge-disi");
            return;
        }

        baslat(gonderen, kabulEden, bolge);
    }

    public void reddet(Player reddeden) {
        Davet davet = davetler.remove(reddeden.getUniqueId());
        if (davet == null) {
            Mesaj.gonder(reddeden, "duello-davet-yok");
            return;
        }
        Player gonderen = Bukkit.getPlayer(davet.gonderen());
        Mesaj.gonder(reddeden, "duello-reddettin");
        if (gonderen != null) {
            Mesaj.gonder(gonderen, "duello-reddedildi",
                    Mesaj.degisken("oyuncu", reddeden.getName()));
        }
    }

    private void baslat(Player a, Player b, GuvenliBolge bolge) {
        DuelloOturumu oturum = new DuelloOturumu(a, b, bolge);
        aktif.put(a.getUniqueId(), oturum);
        aktif.put(b.getUniqueId(), oturum);

        // Ayni irktan olsalar bile vurusabilsinler
        eklenti.getIrkSistemi().duelloIzniVer(a.getUniqueId(), b.getUniqueId());

        for (Player oyuncu : List.of(a, b)) {
            Mesaj.gonder(oyuncu, "duello-basladi",
                    Mesaj.degisken("oyuncu", oyuncu.equals(a) ? b.getName() : a.getName()));
            oyuncu.playSound(oyuncu.getLocation(), "entity.ender_dragon.growl", 0.6f, 1.6f);
        }

        if (eklenti.getConfig().getBoolean("duello.baslangic-duyurusu", true)) {
            Bukkit.broadcast(Mesaj.ayristir(
                    Mesaj.ham("duello-duyuru-baslangic")
                            .replace("<oyuncu1>", a.getName())
                            .replace("<oyuncu2>", b.getName())));
        }
    }

    /**
     * Duelloyu bitirir.
     * kazanan null ise beraberlik (sure doldu / sunucu kapandi).
     */
    public void bitir(DuelloOturumu oturum, UUID kazanan, String sebep) {
        if (oturum.bittiMi()) {
            return;
        }
        oturum.bitir();

        UUID k1 = oturum.birinci();
        UUID k2 = oturum.ikinci();
        aktif.remove(k1);
        aktif.remove(k2);
        eklenti.getIrkSistemi().duelloIzniKaldir(k1, k2);

        // Durumu geri yukle
        for (UUID kimlik : oturum.katilimcilar()) {
            Player oyuncu = Bukkit.getPlayer(kimlik);
            if (oyuncu == null || !oyuncu.isOnline()) {
                continue;
            }
            DuelloOturumu.Yedek yedek = oturum.yedek(kimlik);
            yedek.geriYukle(oyuncu);
            if (eklenti.getConfig().getBoolean("duello.bitince-isinla", true)) {
                oyuncu.teleport(yedek.konum());
            }
        }

        // Duyuru
        if (kazanan == null) {
            String metin = "sunucu".equals(sebep)
                    ? "duello-iptal" : "duello-berabere";
            for (UUID kimlik : oturum.katilimcilar()) {
                Player oyuncu = Bukkit.getPlayer(kimlik);
                if (oyuncu != null) {
                    Mesaj.gonder(oyuncu, metin);
                }
            }
            return;
        }

        UUID kaybedenKimlik = oturum.rakip(kazanan);
        String kazananAd = adCoz(kazanan);
        String kaybedenAd = adCoz(kaybedenKimlik);

        Bukkit.broadcast(Mesaj.ayristir(
                Mesaj.ham("duello-duyuru-kazanan")
                        .replace("<kazanan>", kazananAd)
                        .replace("<kaybeden>", kaybedenAd)));

        Player kz = Bukkit.getPlayer(kazanan);
        if (kz != null) {
            Mesaj.gonder(kz, "duello-kazandin", Mesaj.degisken("oyuncu", kaybedenAd));
            kz.playSound(kz.getLocation(), "ui.toast.challenge_complete", 1.0f, 1.0f);
        }
        Player kb = Bukkit.getPlayer(kaybedenKimlik);
        if (kb != null) {
            Mesaj.gonder(kb, "duello-kaybettin", Mesaj.degisken("oyuncu", kazananAd));
        }
    }

    @SuppressWarnings("deprecation")
    private String adCoz(UUID kimlik) {
        Player oyuncu = Bukkit.getPlayer(kimlik);
        if (oyuncu != null) {
            return oyuncu.getName();
        }
        String ad = Bukkit.getOfflinePlayer(kimlik).getName();
        return ad == null ? "?" : ad;
    }

    // ================= Savas kurallari =================

    /** Saldirandan sorumlu oyuncuyu bulur (ok, iksir, TNT dahil). */
    private Player sorumlu(Entity vuran) {
        if (vuran instanceof Player oyuncu) {
            return oyuncu;
        }
        if (vuran instanceof Projectile mermi) {
            ProjectileSource kaynak = mermi.getShooter();
            if (kaynak instanceof Player oyuncu) {
                return oyuncu;
            }
        }
        if (vuran instanceof TNTPrimed tnt && tnt.getSource() instanceof Player oyuncu) {
            return oyuncu;
        }
        if (vuran instanceof AreaEffectCloud bulut && bulut.getSource() instanceof Player oyuncu) {
            return oyuncu;
        }
        return null;
    }

    /**
     * Bu iki oyuncu arasindaki hasara izin var mi?
     *
     * - Duellodaki oyuncu YALNIZCA rakibine vurabilir
     * - Duello disindaki biri duellodakine vuramaz
     * - Guvenli bolgede duello disi PvP tamamen kapalidir
     */
    private boolean hasarSerbest(Player saldiran, Player hedef) {
        DuelloOturumu sOturum = oturum(saldiran);
        DuelloOturumu hOturum = oturum(hedef);

        // Saldiran duelloda: sadece rakibine vurabilir
        if (sOturum != null) {
            return sOturum == hOturum;
        }
        // Hedef duelloda ama saldiran degil: disaridan mudahale yok
        if (hOturum != null) {
            return false;
        }
        // Ikisi de duello disi: guvenli bolgede PvP kapali
        return bolgeBul(saldiran.getLocation()) == null
                && bolgeBul(hedef.getLocation()) == null;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void hasar(EntityDamageByEntityEvent olay) {
        if (!(olay.getEntity() instanceof Player hedef)) {
            return;
        }
        Player saldiran = sorumlu(olay.getDamager());
        if (saldiran == null || saldiran.equals(hedef)) {
            return;
        }

        if (!hasarSerbest(saldiran, hedef)) {
            olay.setCancelled(true);
            if (bolgeBul(saldiran.getLocation()) != null && oturum(saldiran) == null) {
                uyar(saldiran, "duello-guvenli-bolge-pvp");
            }
        }
    }

    /** Olumcul hasarda oyuncu olmez; 1 canla duello biter. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void olumcul(EntityDamageEvent olay) {
        if (!(olay.getEntity() instanceof Player oyuncu)) {
            return;
        }
        DuelloOturumu oturum = oturum(oyuncu);
        if (oturum == null) {
            return;
        }
        if (oyuncu.getHealth() - olay.getFinalDamage() > 0.5) {
            return;
        }

        olay.setCancelled(true);
        oyuncu.setHealth(Math.min(1.0, oyuncu.getMaxHealth()));
        oyuncu.setFireTicks(0);

        UUID kazanan = oturum.rakip(oyuncu.getUniqueId());
        bitir(oturum, kazanan, "olum");
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void iksir(PotionSplashEvent olay) {
        Player atan = sorumlu(olay.getPotion());
        if (atan == null) {
            return;
        }
        for (LivingEntity varlik : new ArrayList<>(olay.getAffectedEntities())) {
            if (varlik instanceof Player hedef && !hedef.equals(atan)
                    && !hasarSerbest(atan, hedef)) {
                olay.setIntensity(hedef, 0.0);
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void bulut(AreaEffectCloudApplyEvent olay) {
        Player kaynak = sorumlu(olay.getEntity());
        if (kaynak == null) {
            return;
        }
        olay.getAffectedEntities().removeIf(varlik ->
                varlik instanceof Player hedef && !hedef.equals(kaynak)
                        && !hasarSerbest(kaynak, hedef));
    }

    // ================= Bolge siniri =================

    @EventHandler(ignoreCancelled = true)
    public void hareket(PlayerMoveEvent olay) {
        if (olay.getTo() == null) {
            return;
        }
        // Yalnizca blok degistirdiginde kontrol et
        if (olay.getFrom().getBlockX() == olay.getTo().getBlockX()
                && olay.getFrom().getBlockZ() == olay.getTo().getBlockZ()) {
            return;
        }
        Player oyuncu = olay.getPlayer();
        DuelloOturumu oturum = oturum(oyuncu);
        if (oturum == null) {
            return;
        }
        GuvenliBolge bolge = oturum.bolge();
        if (bolge.icinde(olay.getTo())) {
            return;
        }
        // Duello sirasinda bolgeden cikilamaz
        olay.setTo(bolge.sinirIcineCek(olay.getTo()));
        uyar(oyuncu, "duello-bolgeden-cikamazsin");
    }

    @EventHandler(ignoreCancelled = true)
    public void isinlanma(PlayerTeleportEvent olay) {
        DuelloOturumu oturum = oturum(olay.getPlayer());
        if (oturum == null || olay.getTo() == null) {
            return;
        }
        if (olay.getCause() == PlayerTeleportEvent.TeleportCause.PLUGIN) {
            return;   // sistemin kendi isinlamasi
        }
        if (!oturum.bolge().icinde(olay.getTo())) {
            olay.setCancelled(true);
            uyar(olay.getPlayer(), "duello-bolgeden-cikamazsin");
        }
    }

    @EventHandler
    public void cikis(PlayerQuitEvent olay) {
        Player oyuncu = olay.getPlayer();
        davetler.remove(oyuncu.getUniqueId());
        davetler.entrySet().removeIf(g -> g.getValue().gonderen().equals(oyuncu.getUniqueId()));

        DuelloOturumu oturum = oturum(oyuncu);
        if (oturum != null) {
            // Cikan taraf kaybeder
            bitir(oturum, oturum.rakip(oyuncu.getUniqueId()), "cikis");
        }
    }

    // ================= Yardimci =================

    private final Map<UUID, Long> sonUyari = new HashMap<>();

    private void uyar(Player oyuncu, String anahtar) {
        long simdi = System.currentTimeMillis();
        Long son = sonUyari.get(oyuncu.getUniqueId());
        if (son != null && simdi - son < 2500L) {
            return;
        }
        sonUyari.put(oyuncu.getUniqueId(), simdi);
        Mesaj.gonder(oyuncu, anahtar);
    }
}
