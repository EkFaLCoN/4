package com.sinifsistemi.duello;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

/**
 * Guvenli bolge: merkez + yaricap (silindir).
 *
 * - Icinde normal PvP KAPALIDIR
 * - Duello YALNIZCA burada atilabilir
 * - Duello sirasinda oyuncular disari cikamaz
 */
public class GuvenliBolge {

    private final String ad;
    private final String dunyaAdi;
    private final double x;
    private final double y;
    private final double z;
    private final double yaricap;

    public GuvenliBolge(String ad, String dunyaAdi, double x, double y, double z, double yaricap) {
        this.ad = ad;
        this.dunyaAdi = dunyaAdi;
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaricap = yaricap;
    }

    public static GuvenliBolge konumdan(String ad, Location konum, double yaricap) {
        return new GuvenliBolge(ad, konum.getWorld().getName(),
                konum.getX(), konum.getY(), konum.getZ(), yaricap);
    }

    public String ad() {
        return ad;
    }

    public String dunyaAdi() {
        return dunyaAdi;
    }

    public double yaricap() {
        return yaricap;
    }

    public Location merkez() {
        World dunya = Bukkit.getWorld(dunyaAdi);
        return dunya == null ? null : new Location(dunya, x, y, z);
    }

    /** Yatay mesafeye bakar; yukseklik sinirsizdir (silindir). */
    public boolean icinde(Location konum) {
        if (konum == null || konum.getWorld() == null) {
            return false;
        }
        if (!konum.getWorld().getName().equalsIgnoreCase(dunyaAdi)) {
            return false;
        }
        double dx = konum.getX() - x;
        double dz = konum.getZ() - z;
        return (dx * dx + dz * dz) <= (yaricap * yaricap);
    }

    /** Merkeze olan yatay mesafe. */
    public double mesafe(Location konum) {
        double dx = konum.getX() - x;
        double dz = konum.getZ() - z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    /**
     * Bolge disina cikan oyuncuyu sinirin hemen icine geri getirecek konum.
     * Yonu korur, sadece merkeze dogru ceker.
     */
    public Location sinirIcineCek(Location konum) {
        Location merkez = merkez();
        if (merkez == null) {
            return konum;
        }
        double dx = konum.getX() - x;
        double dz = konum.getZ() - z;
        double uzaklik = Math.sqrt(dx * dx + dz * dz);
        if (uzaklik < 0.0001) {
            return merkez;
        }
        double hedef = yaricap - 1.5;
        double oran = hedef / uzaklik;
        Location yeni = konum.clone();
        yeni.setX(x + dx * oran);
        yeni.setZ(z + dz * oran);
        return yeni;
    }

    public String kayitSatiri() {
        return ad + "," + dunyaAdi + "," + x + "," + y + "," + z + "," + yaricap;
    }

    public static GuvenliBolge satirdan(String satir) {
        String[] p = satir.split(",");
        if (p.length != 6) {
            return null;
        }
        try {
            return new GuvenliBolge(p[0], p[1],
                    Double.parseDouble(p[2]), Double.parseDouble(p[3]),
                    Double.parseDouble(p[4]), Double.parseDouble(p[5]));
        } catch (NumberFormatException hata) {
            return null;
        }
    }
}
