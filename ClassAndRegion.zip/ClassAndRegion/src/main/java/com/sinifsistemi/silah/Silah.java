package com.sinifsistemi.silah;

import com.sinifsistemi.Sinif;
import org.bukkit.Material;

import java.util.List;
import java.util.Locale;

/**
 * Sunucudaki ozel siniflara ait silahlar.
 * Her silah yalnizca kendi sinifi tarafindan kullanilabilir.
 */
public enum Silah {

    KANLI_SAVAS_BALTASI(
            "kanli_savas_baltasi",
            "Kanlı Savaş Baltası",
            "#C41E1E",
            "#4A0507",
            Material.NETHERITE_AXE,
            "cursedclasses:kanli_savas_baltasi",
            Sinif.SAVASCI,
            List.of(
                    "<dark_gray><italic>Çift ağzının biri hâlâ kurumadı.",
                    "",
                    "<gray>Kadim bir savaş alanından çıkarılan bu balta,",
                    "<gray>döktüğü kanı asla unutmaz. Sol ağzı sürekli",
                    "<gray><dark_red>kan damlatır<gray> ve her vuruşta daha da susar.",
                    "",
                    "<gold><bold>Yetenekler",
                    "<dark_red>✦ <gray>Saldırı hasarı: <white>13 <dark_gray>(6.5 kalp)",
                    "<dark_red>✦ <gray>Vuruşta <white>Kanama <dark_gray>(6 sn, saniyede 1.25 kalp)",
                    "<dark_red>✦ <gray>Kanama hasarının <white>%35'ini <gray>can olarak emer",
                    "<dark_red>✦ <white>Öfke<gray>: canın azaldıkça <white>%40<gray>'a kadar fazla hasar",
                    "<dark_red>✦ <white>Kanlı Hasat<gray>: kanayan hedefe <white>%25 <gray>fazla hasar",
                    "<dark_red>✦ <white>Kan Zırhı<gray>: çevrende kanayan her hedef için",
                    "<dark_gray>   <white>%8 <dark_gray>az hasar alırsın <dark_gray>(en fazla %32)",
                    "<dark_red>✦ <white>Kan Kalkanı<gray>: her öldürmede <white>+2 kalp <gray>kalkan",
                    "<dark_gray>   ve yetenek beklemeleri <white>5 sn <dark_gray>kısalır",
                    "",
                    "<gold><bold>Kullanım",
                    "<dark_red>➤ <gray>Sağ tık: <white>Kan Çağrısı <dark_gray>(çevreyi kanatır, 20 sn)",
                    "<dark_red>➤ <gray>Shift + sağ tık: <white>Kan Fırtınası",
                    "<dark_gray>   4 kalp alan hasarı + savurma + kanama <dark_gray>(35 sn)",
                    "",
                    "<dark_red>⚔ <gray>Yalnızca <red><bold>Savaşçı<gray> sınıfı kullanabilir."
            )
    ),

    ALACAKARANLIK(
            "alacakaranlik",
            "Alacakaranlık",
            "#8A5CFF",
            "#1B0A33",
            Material.NETHERITE_SWORD,
            "cursedclasses:alacakaranlik",
            Sinif.SUIKASTCI,
            List.of(
                    "<dark_gray><italic>Işığın bittiği yerde başlar.",
                    "",
                    "<gray>Karanlık tarafın hançeri. Gölgeye çekilmeyi",
                    "<gray>ve arkadan gelmeyi sever; ışıkta işe yaramaz.",
                    "",
                    "<gold><bold>Yetenekler",
                    "<dark_purple>✦ <gray>Saldırı hasarı: <white>7 <dark_gray>(hızlı tempo)",
                    "<dark_purple>✦ <white>Gölgeden Vuruş<gray>: arkadan veya görünmezken",
                    "<dark_gray>   <white>%80 <dark_gray>fazla hasar + hedefe körlük",
                    "<dark_purple>✦ <white>Kardeş Ağız<gray>: diğer el <white>Şafak <gray>tutuyorsa <white>%15 <gray>hasar",
                    "",
                    "<gold><bold>Kullanım",
                    "<dark_purple>➤ <gray>Sağ tık: <white>Gölge Sıçraması",
                    "<dark_gray>   en yakın hedefin arkasına ışınlanırsın <dark_gray>(12 sn)",
                    "",
                    "<dark_purple>⚔ <gray>Yalnızca <dark_purple><bold>Suikastçı<gray> sınıfı kullanabilir."
            )
    ),

    SAFAK(
            "safak",
            "Şafak",
            "#FFD98A",
            "#B26B00",
            Material.NETHERITE_SWORD,
            "cursedclasses:safak",
            Sinif.SUIKASTCI,
            List.of(
                    "<dark_gray><italic>Karanlığın en koyu anından hemen sonra.",
                    "",
                    "<gray>Aydınlık tarafın hançeri. Aynı hedefe binen",
                    "<gray>vuruşlarla ışık toplar ve son darbede boşaltır.",
                    "",
                    "<gold><bold>Yetenekler",
                    "<dark_purple>✦ <gray>Saldırı hasarı: <white>7 <dark_gray>(hızlı tempo)",
                    "<gold>✦ <white>Işık Yükü<gray>: aynı hedefe her vuruş <white>%12 <gray>hasar ekler",
                    "<dark_gray>   <white>5. yükte <dark_gray>patlar: ek hasar + sana <white>2 kalp",
                    "<gold>✦ <white>Kardeş Ağız<gray>: diğer el <white>Alacakaranlık <gray>tutuyorsa <white>%15 <gray>hasar",
                    "",
                    "<gold><bold>Kullanım",
                    "<gold>➤ <gray>Sağ tık: <white>Şafak Kesişi",
                    "<dark_gray>   öne atılıp önündeki herkesi biçersin <dark_gray>(14 sn)",
                    "",
                    "<dark_purple>⚔ <gray>Yalnızca <dark_purple><bold>Suikastçı<gray> sınıfı kullanabilir."
            )
    ),

    GOLGE_PELERINI(
            "golge_pelerini",
            "Gölge Pelerini",
            "#6F5CA8",
            "#120A20",
            Material.LEATHER_CHESTPLATE,
            "cursedclasses:suikast_yelek",
            Sinif.SUIKASTCI,
            List.of(
                    "<dark_gray><italic>Üzerine çektiğinde dünya seni unutur.",
                    "",
                    "<gray>Gölgeden dokunmuş bir pelerin. Giyeni",
                    "<gray>zırhıyla birlikte tamamen görünmez kılar.",
                    "",
                    "<gold><bold>Kullanım",
                    "<dark_purple>➤ <gray>Sağ tık: <white>Gölgeye Karış <dark_gray>(45 sn bekleme)",
                    "<dark_gray>   <white>10 saniye <dark_gray>boyunca kimse seni göremez",
                    "<dark_gray>   zırhın, silahın ve isim etiketin de gizlenir",
                    "",
                    "<dark_red>✦ <gray>Saldırırsan veya hasar alırsan gölge dağılır.",
                    "",
                    "<dark_purple>⚔ <gray>Yalnızca <dark_purple><bold>Suikastçı<gray> sınıfı kullanabilir."
            )
    );

    private final String kod;
    private final String ad;
    private final String gradyanBas;
    private final String gradyanSon;
    private final Material taban;
    private final String modelKimligi;
    private final Sinif gerekliSinif;
    private final List<String> aciklama;

    Silah(String kod, String ad, String gradyanBas, String gradyanSon, Material taban,
          String modelKimligi, Sinif gerekliSinif, List<String> aciklama) {
        this.kod = kod;
        this.ad = ad;
        this.gradyanBas = gradyanBas;
        this.gradyanSon = gradyanSon;
        this.taban = taban;
        this.modelKimligi = modelKimligi;
        this.gerekliSinif = gerekliSinif;
        this.aciklama = aciklama;
    }

    public String kod() {
        return kod;
    }

    public String ad() {
        return ad;
    }

    public String renkliAd() {
        return "<gradient:" + gradyanBas + ":" + gradyanSon + "><bold>" + ad + "</bold></gradient>";
    }

    public Material taban() {
        return taban;
    }

    public String modelKimligi() {
        return modelKimligi;
    }

    public Sinif gerekliSinif() {
        return gerekliSinif;
    }

    public List<String> aciklama() {
        return aciklama;
    }

    public static Silah bul(String metin) {
        if (metin == null || metin.isBlank()) {
            return null;
        }
        String temiz = metin.trim().toLowerCase(Locale.ROOT)
                .replace('ı', 'i').replace('ş', 's').replace('ç', 'c')
                .replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o')
                .replace(' ', '_');
        for (Silah silah : values()) {
            if (silah.kod.equals(temiz) || silah.name().equalsIgnoreCase(temiz)) {
                return silah;
            }
        }
        return null;
    }
}
