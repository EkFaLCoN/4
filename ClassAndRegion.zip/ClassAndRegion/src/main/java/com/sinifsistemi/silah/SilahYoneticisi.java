package com.sinifsistemi.silah;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import net.kyori.adventure.text.Component;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * Ozel silahlarin ItemStack olarak uretilmesi ve taninmasi.
 */
public class SilahYoneticisi {

    private final SinifSistemi eklenti;
    private final NamespacedKey anahtar;

    public SilahYoneticisi(SinifSistemi eklenti) {
        this.eklenti = eklenti;
        this.anahtar = new NamespacedKey(eklenti, "ozel_silah");
    }

    public NamespacedKey anahtar() {
        return anahtar;
    }

    /** Silahin oyun ici esyasini uretir. */
    public ItemStack uret(Silah silah) {
        ItemStack esya = new ItemStack(silah.taban());
        ItemMeta meta = esya.getItemMeta();

        meta.displayName(Mesaj.esya(silah.renkliAd()));

        List<Component> lore = new ArrayList<>();
        for (String satir : silah.aciklama()) {
            lore.add(Mesaj.esya(satir));
        }
        meta.lore(lore);

        // Resourcepack modeli
        try {
            String[] parca = silah.modelKimligi().split(":", 2);
            meta.setItemModel(new NamespacedKey(parca[0], parca[1]));
        } catch (Throwable hata) {
            eklenti.getLogger().warning("item_model ayarlanamadi (" + silah.kod()
                    + "): " + hata.getMessage());
        }

        // Sabit saldiri gucu: esyaya kendi attribute'unu verince
        // materyalin varsayilan degerleri devre disi kalir, hasar tam olarak
        // config'te yazan deger olur.
        double tabanHasar = eklenti.getConfig()
                .getDouble("silahlar." + silah.kod() + ".taban-hasar", 13.0);
        double saldiriHizi = eklenti.getConfig()
                .getDouble("silahlar." + silah.kod() + ".saldiri-hizi", 1.0);

        // taban-hasar 0 ise esyanin kendi varsayilan degerlerine dokunulmaz
        // (ornegin Golge Pelerini bir zirh parcasidir, silah degil).
        Attribute hasarAttr = tabanHasar <= 0 ? null
                : coz("ATTACK_DAMAGE", "GENERIC_ATTACK_DAMAGE");
        Attribute hizAttr = tabanHasar <= 0 ? null
                : coz("ATTACK_SPEED", "GENERIC_ATTACK_SPEED");

        if (hasarAttr != null) {
            // Oyuncunun taban saldiri hasari 1.0'dir, farki ekliyoruz.
            meta.addAttributeModifier(hasarAttr, new AttributeModifier(
                    new NamespacedKey(eklenti, "silah_hasar"),
                    tabanHasar - 1.0,
                    AttributeModifier.Operation.ADD_NUMBER,
                    EquipmentSlotGroup.MAINHAND));
        }
        if (hizAttr != null) {
            // Oyuncunun taban saldiri hizi 4.0'dir.
            meta.addAttributeModifier(hizAttr, new AttributeModifier(
                    new NamespacedKey(eklenti, "silah_hizi"),
                    saldiriHizi - 4.0,
                    AttributeModifier.Operation.ADD_NUMBER,
                    EquipmentSlotGroup.MAINHAND));
        }

        // Keskinlik yok: hasar yukarida sabitlendi, buyu ustune binmesin.
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES,
                ItemFlag.HIDE_ADDITIONAL_TOOLTIP, ItemFlag.HIDE_UNBREAKABLE);

        meta.getPersistentDataContainer().set(anahtar, PersistentDataType.STRING, silah.kod());

        esya.setItemMeta(meta);
        return esya;
    }

    /** Attribute alanini surum farklarina karsi reflection ile cozer. */
    private Attribute coz(String... adaylar) {
        for (String ad : adaylar) {
            try {
                Field alan = Attribute.class.getField(ad);
                Object deger = alan.get(null);
                if (deger instanceof Attribute attribute) {
                    return attribute;
                }
            } catch (ReflectiveOperationException | RuntimeException yoksay) {
                // Bu surumde bu isim yok, sonraki adayi dene
            }
        }
        eklenti.getLogger().warning("Attribute bulunamadi: " + String.join(" / ", adaylar));
        return null;
    }

    /** Esya bir ozel silah mi? Degilse null. */
    public Silah tani(ItemStack esya) {
        if (esya == null || esya.getType().isAir() || !esya.hasItemMeta()) {
            return null;
        }
        String kod = esya.getItemMeta().getPersistentDataContainer()
                .get(anahtar, PersistentDataType.STRING);
        return kod == null ? null : Silah.bul(kod);
    }
}
