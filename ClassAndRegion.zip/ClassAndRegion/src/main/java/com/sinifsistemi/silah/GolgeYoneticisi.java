package com.sinifsistemi.silah;

import com.sinifsistemi.Mesaj;
import com.sinifsistemi.SinifSistemi;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Golge Pelerini'nin gorunmezligi.
 *
 * Iksir gorunmezligi zirhi gizlemez; bu yuzden oyuncu digerlerinin
 * gozunden Bukkit'in hidePlayer cagrisiyla tamamen kaldirilir.
 * Boylece zirh, elindeki silah ve isim etiketi de kaybolur.
 */
public class GolgeYoneticisi {

    private final SinifSistemi eklenti;
    /** Gizli oyuncu -> gizliligin bitis zamani (ms). */
    private final Map<UUID, Long> gizliler = new HashMap<>();
    private BukkitTask gorev;

    public GolgeYoneticisi(SinifSistemi eklenti) {
        this.eklenti = eklenti;
    }

    public void baslat() {
        durdur();
        gorev = Bukkit.getScheduler().runTaskTimer(eklenti, this::tik, 10L, 10L);
    }

    public void durdur() {
        if (gorev != null) {
            gorev.cancel();
            gorev = null;
        }
        for (UUID kimlik : new java.util.ArrayList<>(gizliler.keySet())) {
            Player oyuncu = Bukkit.getPlayer(kimlik);
            if (oyuncu != null) {
                gorunurYap(oyuncu, false);
            }
        }
        gizliler.clear();
    }

    public boolean gizliMi(Player oyuncu) {
        return oyuncu != null && gizliler.containsKey(oyuncu.getUniqueId());
    }

    /** Oyuncuyu belirtilen saniye boyunca tamamen gorunmez yapar. */
    public void gizle(Player oyuncu, int saniye) {
        gizliler.put(oyuncu.getUniqueId(), System.currentTimeMillis() + saniye * 1000L);

        for (Player diger : Bukkit.getOnlinePlayers()) {
            if (!diger.equals(oyuncu) && !diger.hasPermission("sinif.golge.gorur")) {
                diger.hidePlayer(eklenti, oyuncu);
            }
        }
        // Yaratiklarin da gozden kacirmasi icin iksir gorunmezligi
        oyuncu.addPotionEffect(new PotionEffect(
                PotionEffectType.INVISIBILITY, saniye * 20, 0, false, false, false));

        duman(oyuncu);
        oyuncu.getWorld().playSound(oyuncu.getLocation(), "entity.illusioner.mirror_move", 0.9f, 0.7f);
        Mesaj.gonder(oyuncu, "golge-basladi",
                Mesaj.degisken("saniye", String.valueOf(saniye)));
    }

    /** Gizliligi erken bitirir (saldiri, hasar, cikis vb.). */
    public void boz(Player oyuncu) {
        if (!gizliMi(oyuncu)) {
            return;
        }
        gorunurYap(oyuncu, true);
    }

    private void gorunurYap(Player oyuncu, boolean mesaj) {
        gizliler.remove(oyuncu.getUniqueId());
        for (Player diger : Bukkit.getOnlinePlayers()) {
            diger.showPlayer(eklenti, oyuncu);
        }
        oyuncu.removePotionEffect(PotionEffectType.INVISIBILITY);
        duman(oyuncu);
        if (mesaj) {
            Mesaj.gonder(oyuncu, "golge-bozuldu", null);
        }
    }

    private void tik() {
        long simdi = System.currentTimeMillis();
        for (Map.Entry<UUID, Long> giris : new java.util.ArrayList<>(gizliler.entrySet())) {
            Player oyuncu = Bukkit.getPlayer(giris.getKey());
            if (oyuncu == null || !oyuncu.isOnline()) {
                gizliler.remove(giris.getKey());
                continue;
            }
            if (simdi >= giris.getValue()) {
                gizliler.remove(giris.getKey());
                for (Player diger : Bukkit.getOnlinePlayers()) {
                    diger.showPlayer(eklenti, oyuncu);
                }
                oyuncu.removePotionEffect(PotionEffectType.INVISIBILITY);
                duman(oyuncu);
                Mesaj.gonder(oyuncu, "golge-bitti", null);
                continue;
            }
            // Ayagin dibinde hafif golge izi (sadece kendisi konumunu hisseder)
            oyuncu.spawnParticle(Particle.DUST, oyuncu.getLocation(), 2, 0.2, 0.1, 0.2, 0.0,
                    new Particle.DustOptions(Color.fromRGB(70, 50, 110), 0.7f));
        }
    }

    private void duman(Player oyuncu) {
        if (oyuncu.getWorld() == null) {
            return;
        }
        oyuncu.getWorld().spawnParticle(Particle.LARGE_SMOKE,
                oyuncu.getLocation().add(0, 1.0, 0), 25, 0.35, 0.6, 0.35, 0.02);
        oyuncu.getWorld().spawnParticle(Particle.DUST,
                oyuncu.getLocation().add(0, 1.0, 0), 20, 0.4, 0.6, 0.4, 0.0,
                new Particle.DustOptions(Color.fromRGB(60, 40, 100), 1.3f));
    }
}
