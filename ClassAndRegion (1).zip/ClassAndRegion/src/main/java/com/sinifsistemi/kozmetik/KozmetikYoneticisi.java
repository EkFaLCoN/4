package com.sinifsistemi.kozmetik;

import com.sinifsistemi.SinifSistemi;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Kozmetiklerin tamami buradan yonetilir:
 *
 *  - Gorunum: oyuncuya binen (passenger) bir ItemDisplay. Boylece zirh
 *    slotlari bosta kalir, kozmetik oyunun kendi esyalariyla catismaz.
 *  - Guc: kozmetik_ onekli AttributeModifier'lar + surekli iksir etkileri.
 *    Sinif yeteneklerinden tamamen bagimsizdir, birbirini silmez.
 *  - Kayit: kozmetikler.yml (acilan kozmetikler + takili olanlar).
 */
public class KozmetikYoneticisi {

    private final SinifSistemi eklenti;

    /** Oyuncu -> kategori -> takili kozmetik */
    private final Map<UUID, Map<Kozmetik.Kategori, Kozmetik>> takililar = new HashMap<>();
    /** Oyuncu -> acilmis kozmetikler */
    private final Map<UUID, Set<Kozmetik>> acilanlar = new HashMap<>();
    /** Oyuncu -> kategori -> canli gorunum varligi */
    private final Map<UUID, Map<Kozmetik.Kategori, UUID>> gorunumler = new HashMap<>();

    private final Map<String, NamespacedKey> anahtarlar = new HashMap<>();

    private final Attribute MAX_CAN;
    private final Attribute HAREKET_HIZI;
    private final Attribute ZIRH;
    private final Attribute ZIRH_SAGLAMLIGI;
    private final Attribute GERI_TEPME_DIRENCI;
    private final Attribute SALDIRI_HASARI;

    private File dosya;
    private FileConfiguration veri;
    private BukkitTask gorev;
    private BukkitTask yonGorevi;
    private int sayac;

    /** Oyuncu -> kategori -> o an gosterilen animasyon karesi */
    private final Map<UUID, Map<Kozmetik.Kategori, Integer>> kareler = new HashMap<>();
    /** Oyuncu -> animasyon ilerlemesi (tick birikimi) */
    private final Map<UUID, Double> animSayaci = new HashMap<>();
    /** Oyuncu -> son konum (hareket hizini olcmek icin) */
    private final Map<UUID, Location> sonKonum = new HashMap<>();

    /** Zirh esyasina yazilan, kostum oncesi orijinal gorunumu saklayan anahtar. */
    private static final String ESKI_MODEL = "kozmetik_eski_model";

    public KozmetikYoneticisi(SinifSistemi eklenti) {
        this.eklenti = eklenti;

        MAX_CAN = coz("MAX_HEALTH", "GENERIC_MAX_HEALTH");
        HAREKET_HIZI = coz("MOVEMENT_SPEED", "GENERIC_MOVEMENT_SPEED");
        ZIRH = coz("ARMOR", "GENERIC_ARMOR");
        ZIRH_SAGLAMLIGI = coz("ARMOR_TOUGHNESS", "GENERIC_ARMOR_TOUGHNESS");
        GERI_TEPME_DIRENCI = coz("KNOCKBACK_RESISTANCE", "GENERIC_KNOCKBACK_RESISTANCE");
        SALDIRI_HASARI = coz("ATTACK_DAMAGE", "GENERIC_ATTACK_DAMAGE");

        yukle();
    }

    /** Attribute alan adlari surumler arasi degisti; adaylari sirayla dener. */
    private Attribute coz(String... adaylar) {
        for (String ad : adaylar) {
            try {
                Object deger = Attribute.class.getField(ad).get(null);
                if (deger instanceof Attribute attribute) {
                    return attribute;
                }
            } catch (ReflectiveOperationException | RuntimeException yoksay) {
                // sonraki aday
            }
        }
        return null;
    }

    private NamespacedKey anahtar(String ad) {
        return anahtarlar.computeIfAbsent(ad, a -> new NamespacedKey(eklenti, "kozmetik_" + a));
    }

    // ------------------------------------------------------------------
    //  Veri
    // ------------------------------------------------------------------

    public void yukle() {
        takililar.clear();
        acilanlar.clear();

        dosya = new File(eklenti.getDataFolder(), "kozmetikler.yml");
        if (!dosya.exists()) {
            try {
                if (!eklenti.getDataFolder().exists() && !eklenti.getDataFolder().mkdirs()) {
                    eklenti.getLogger().warning("Eklenti klasoru olusturulamadi!");
                }
                if (!dosya.createNewFile()) {
                    eklenti.getLogger().warning("kozmetikler.yml olusturulamadi!");
                }
            } catch (IOException hata) {
                eklenti.getLogger().log(Level.SEVERE, "kozmetikler.yml olusturulurken hata", hata);
            }
        }
        veri = YamlConfiguration.loadConfiguration(dosya);

        if (veri.isConfigurationSection("oyuncular")) {
            for (String ham : veri.getConfigurationSection("oyuncular").getKeys(false)) {
                UUID kimlik;
                try {
                    kimlik = UUID.fromString(ham);
                } catch (IllegalArgumentException yoksay) {
                    eklenti.getLogger().warning("Gecersiz UUID atlandi: " + ham);
                    continue;
                }

                Set<Kozmetik> acik = new LinkedHashSet<>();
                for (String kod : veri.getStringList("oyuncular." + ham + ".acilanlar")) {
                    Kozmetik k = Kozmetik.bul(kod);
                    if (k != null) {
                        acik.add(k);
                    }
                }
                if (!acik.isEmpty()) {
                    acilanlar.put(kimlik, acik);
                }

                Map<Kozmetik.Kategori, Kozmetik> takili = new EnumMap<>(Kozmetik.Kategori.class);
                for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
                    Kozmetik k = Kozmetik.bul(
                            veri.getString("oyuncular." + ham + ".takili." + kategori.kod()));
                    if (k != null && k.kategori() == kategori) {
                        takili.put(kategori, k);
                    }
                }
                if (!takili.isEmpty()) {
                    takililar.put(kimlik, takili);
                }
            }
        }
        eklenti.getLogger().info(takililar.size() + " oyuncunun kozmetik verisi yuklendi.");
    }

    public void kaydet() {
        if (veri == null || dosya == null) {
            return;
        }
        try {
            veri.save(dosya);
        } catch (IOException hata) {
            eklenti.getLogger().log(Level.SEVERE, "kozmetikler.yml kaydedilemedi", hata);
        }
    }

    private void diskeYaz(UUID kimlik) {
        String yol = "oyuncular." + kimlik;

        List<String> acikKodlar = new ArrayList<>();
        for (Kozmetik k : acilanlar.getOrDefault(kimlik, Collections.emptySet())) {
            acikKodlar.add(k.kod());
        }
        veri.set(yol + ".acilanlar", acikKodlar.isEmpty() ? null : acikKodlar);

        Map<Kozmetik.Kategori, Kozmetik> takili = takililar.get(kimlik);
        for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
            Kozmetik k = takili == null ? null : takili.get(kategori);
            veri.set(yol + ".takili." + kategori.kod(), k == null ? null : k.kod());
        }
        kaydet();
    }

    // ------------------------------------------------------------------
    //  Erisim / kilit
    // ------------------------------------------------------------------

    /** Oyuncu bu kozmetigi kullanabiliyor mu? */
    public boolean acikMi(Player oyuncu, Kozmetik kozmetik) {
        if (eklenti.getConfig().getBoolean("kozmetik.hepsi-acik", false)) {
            return true;
        }
        if (oyuncu.hasPermission("kozmetik.hepsi")
                || oyuncu.hasPermission("kozmetik." + kozmetik.kod())) {
            return true;
        }
        return acilanlar.getOrDefault(oyuncu.getUniqueId(), Collections.emptySet()).contains(kozmetik);
    }

    /** Kozmetigi kalici olarak acar. true -> yeni acildi, false -> zaten aciktI. */
    public boolean ac(UUID kimlik, Kozmetik kozmetik) {
        Set<Kozmetik> kume = acilanlar.computeIfAbsent(kimlik, k -> new LinkedHashSet<>());
        if (!kume.add(kozmetik)) {
            return false;
        }
        diskeYaz(kimlik);
        return true;
    }

    /** Acilmis kozmetigi geri alir. Takiliysa cikarilir. */
    public boolean kilitle(UUID kimlik, Kozmetik kozmetik) {
        Set<Kozmetik> kume = acilanlar.get(kimlik);
        boolean vardi = kume != null && kume.remove(kozmetik);

        Map<Kozmetik.Kategori, Kozmetik> takili = takililar.get(kimlik);
        if (takili != null && takili.get(kozmetik.kategori()) == kozmetik) {
            Player oyuncu = Bukkit.getPlayer(kimlik);
            if (oyuncu != null) {
                cikar(oyuncu, kozmetik.kategori());
            } else {
                takili.remove(kozmetik.kategori());
            }
        }
        if (vardi) {
            diskeYaz(kimlik);
        }
        return vardi;
    }

    public Set<Kozmetik> acilanlari(UUID kimlik) {
        return Collections.unmodifiableSet(
                acilanlar.getOrDefault(kimlik, Collections.emptySet()));
    }

    public Kozmetik takili(Player oyuncu, Kozmetik.Kategori kategori) {
        Map<Kozmetik.Kategori, Kozmetik> harita = takililar.get(oyuncu.getUniqueId());
        return harita == null ? null : harita.get(kategori);
    }

    // ------------------------------------------------------------------
    //  Takma / cikarma
    // ------------------------------------------------------------------

    public void tak(Player oyuncu, Kozmetik kozmetik) {
        UUID kimlik = oyuncu.getUniqueId();
        Map<Kozmetik.Kategori, Kozmetik> harita =
                takililar.computeIfAbsent(kimlik, k -> new EnumMap<>(Kozmetik.Kategori.class));

        Kozmetik eski = harita.get(kozmetik.kategori());
        if (eski != null) {
            gucKaldir(oyuncu, eski);
        }
        harita.put(kozmetik.kategori(), kozmetik);

        gorunumKaldir(oyuncu, kozmetik.kategori());
        if (kozmetik.kategori().zirhKatmani()) {
            kostumGeriAl(oyuncu);            // once eskisini temizle
            kostumUygula(oyuncu, kozmetik);
        } else {
            gorunumKur(oyuncu, kozmetik);
        }
        gucVer(oyuncu, kozmetik);
        diskeYaz(kimlik);
    }

    public void cikar(Player oyuncu, Kozmetik.Kategori kategori) {
        UUID kimlik = oyuncu.getUniqueId();
        Map<Kozmetik.Kategori, Kozmetik> harita = takililar.get(kimlik);
        if (harita == null) {
            return;
        }
        Kozmetik kozmetik = harita.remove(kategori);
        if (kozmetik == null) {
            return;
        }
        gucKaldir(oyuncu, kozmetik);
        gorunumKaldir(oyuncu, kategori);
        if (kategori.zirhKatmani()) {
            kostumGeriAl(oyuncu);
        }
        if (harita.isEmpty()) {
            takililar.remove(kimlik);
        }
        diskeYaz(kimlik);
    }

    /** Giris / respawn / dunya degisimi sonrasi her seyi yeniden kurar. */
    public void yenidenUygula(Player oyuncu) {
        Map<Kozmetik.Kategori, Kozmetik> harita = takililar.get(oyuncu.getUniqueId());
        tumGucleriKaldir(oyuncu);
        gorunumleriKaldir(oyuncu);
        if (harita == null) {
            return;
        }
        for (Kozmetik kozmetik : harita.values()) {
            gucVer(oyuncu, kozmetik);
            if (kozmetik.kategori().zirhKatmani()) {
                kostumUygula(oyuncu, kozmetik);
            } else {
                gorunumKur(oyuncu, kozmetik);
            }
        }
    }

    // ------------------------------------------------------------------
    //  Gorunum (ItemDisplay)
    // ------------------------------------------------------------------

    private void gorunumKur(Player oyuncu, Kozmetik kozmetik) {
        if (!eklenti.getConfig().getBoolean("kozmetik.gorunum-acik", true)) {
            return;
        }
        if (kozmetik.kategori().zirhKatmani()) {
            return;   // kostumler zirh gorunumu olarak uygulanir
        }
        if (eklenti.getGolgeYoneticisi() != null && eklenti.getGolgeYoneticisi().gizliMi(oyuncu)) {
            return; // Golge Pelerini ile gizliyken kozmetik de gorunmez
        }

        String yol = "kozmetik.gorunum." + kozmetik.kod() + ".";
        ItemStack esya = kareEsyasi(kozmetik, 0);

        float yukseklik = (float) eklenti.getConfig().getDouble(yol + "yukseklik", varsayilanYukseklik(kozmetik));
        float derinlik = (float) eklenti.getConfig().getDouble(yol + "derinlik", varsayilanDerinlik(kozmetik));
        float olcek = (float) eklenti.getConfig().getDouble(yol + "olcek", 1.0);

        Location konum = oyuncu.getLocation().clone();
        konum.setYaw(govdeYonu(oyuncu));
        konum.setPitch(0f);
        try {
            ItemDisplay ekran = oyuncu.getWorld().spawn(konum, ItemDisplay.class, varlik -> {
                varlik.setItemStack(esya);
                varlik.setPersistent(false);
                varlik.setBillboard(Display.Billboard.FIXED);
                // Modelin "fixed" display blogu uygulansin diye baglam FIXED secilir
                varlik.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                varlik.setTransformation(new Transformation(
                        new Vector3f(0f, yukseklik, derinlik),
                        new AxisAngle4f(0f, 0f, 0f, 1f),
                        new Vector3f(olcek, olcek, olcek),
                        new AxisAngle4f(0f, 0f, 0f, 1f)));
                varlik.setViewRange(0.7f);
                varlik.setInterpolationDuration(2);
                varlik.setTeleportDuration(0);
                varlik.getPersistentDataContainer().set(
                        anahtar("gorunum"), org.bukkit.persistence.PersistentDataType.STRING,
                        kozmetik.kod());
            });
            oyuncu.addPassenger(ekran);
            gorunumler.computeIfAbsent(oyuncu.getUniqueId(),
                    k -> new EnumMap<>(Kozmetik.Kategori.class)).put(kozmetik.kategori(), ekran.getUniqueId());
        } catch (RuntimeException hata) {
            eklenti.getLogger().warning("Kozmetik gorunumu olusturulamadi ("
                    + kozmetik.kod() + "): " + hata.getMessage());
        }
    }

    /**
     * Kozmetigin verilen animasyon karesi icin gosterilecek esyayi uretir.
     * Kare 0 ana model, digerleri "_1", "_2" ... son ekli modellerdir.
     */
    private ItemStack kareEsyasi(Kozmetik kozmetik, int kare) {
        String yol = "kozmetik.gorunum." + kozmetik.kod() + ".";
        Material materyal = materyalGetir(
                eklenti.getConfig().getString(yol + "materyal"), kozmetik.varsayilanModel());

        ItemStack esya = new ItemStack(materyal);
        ItemMeta meta = esya.getItemMeta();
        if (meta == null) {
            return esya;
        }
        String modelAnahtari = eklenti.getConfig().getString(yol + "model-anahtari");
        if (modelAnahtari != null && !modelAnahtari.isBlank()) {
            itemModelAyarla(meta, kare > 0 ? modelAnahtari + "_" + kare : modelAnahtari);
        }
        int modelVerisi = eklenti.getConfig().getInt(yol + "model-verisi", 0);
        if (modelVerisi > 0) {
            modelVerisiAyarla(meta, modelVerisi + kare);
        }
        esya.setItemMeta(meta);
        return esya;
    }

    /** Kategoriye gore makul varsayilan yukseklik (oyuncunun sirti hizasi). */
    private float varsayilanYukseklik(Kozmetik kozmetik) {
        return switch (kozmetik.kategori()) {
            case KANAT -> -0.95f;
            case PELERIN -> -1.05f;
            case KOSTUM -> -1.15f;
        };
    }

    private float varsayilanDerinlik(Kozmetik kozmetik) {
        return switch (kozmetik.kategori()) {
            case KANAT -> -0.30f;
            case PELERIN -> -0.28f;
            case KOSTUM -> 0.0f;
        };
    }

    private void gorunumKaldir(Player oyuncu, Kozmetik.Kategori kategori) {
        Map<Kozmetik.Kategori, UUID> harita = gorunumler.get(oyuncu.getUniqueId());
        if (harita == null) {
            return;
        }
        Map<Kozmetik.Kategori, Integer> kareHaritasi = kareler.get(oyuncu.getUniqueId());
        if (kareHaritasi != null) {
            kareHaritasi.remove(kategori);
        }
        UUID varlikKimligi = harita.remove(kategori);
        if (varlikKimligi != null) {
            var varlik = Bukkit.getEntity(varlikKimligi);
            if (varlik != null) {
                varlik.remove();
            }
        }
        if (harita.isEmpty()) {
            gorunumler.remove(oyuncu.getUniqueId());
        }
    }

    public void gorunumleriKaldir(Player oyuncu) {
        for (Kozmetik.Kategori kategori : Kozmetik.Kategori.values()) {
            gorunumKaldir(oyuncu, kategori);
        }
        kareler.remove(oyuncu.getUniqueId());
        animSayaci.remove(oyuncu.getUniqueId());
        sonKonum.remove(oyuncu.getUniqueId());
    }

    /** Cikista kostumu de zirhtan sokmek icin dinleyicinin cagirdigi metot. */
    public void oyuncuAyrildi(Player oyuncu) {
        gorunumleriKaldir(oyuncu);
        kostumGeriAl(oyuncu);
    }

    /**
     * Gorunumler olum, dunya degisimi veya chunk bosalmasi gibi durumlarda
     * kopabilir. Bu gorev her saniye kontrol edip eksigi tamamlar.
     */
    public void baslat() {
        durdur();
        gorev = Bukkit.getScheduler().runTaskTimer(eklenti, () -> {
            sayac++;
            for (Player oyuncu : Bukkit.getOnlinePlayers()) {
                Map<Kozmetik.Kategori, Kozmetik> harita = takililar.get(oyuncu.getUniqueId());
                if (harita == null || harita.isEmpty()) {
                    continue;
                }
                boolean gizli = eklenti.getGolgeYoneticisi() != null
                        && eklenti.getGolgeYoneticisi().gizliMi(oyuncu);

                for (Map.Entry<Kozmetik.Kategori, Kozmetik> giris : harita.entrySet()) {
                    if (gizli) {
                        gorunumKaldir(oyuncu, giris.getKey());
                        continue;
                    }
                    gorunumTazele(oyuncu, giris.getKey(), giris.getValue());
                    if (sayac % 2 == 0) {
                        parcacikCal(oyuncu, giris.getValue());
                    }
                }
                // Surekli iksir etkileri
                for (Kozmetik kozmetik : harita.values()) {
                    if (kozmetik.bonus().surekliEtki() != null) {
                        oyuncu.addPotionEffect(new PotionEffect(
                                kozmetik.bonus().surekliEtki(), 60, 0, true, false, false));
                    }
                }
            }
        }, 40L, 20L);

        yonGoreviBaslat();
    }

    private void gorunumTazele(Player oyuncu, Kozmetik.Kategori kategori, Kozmetik kozmetik) {
        Map<Kozmetik.Kategori, UUID> harita = gorunumler.get(oyuncu.getUniqueId());
        UUID varlikKimligi = harita == null ? null : harita.get(kategori);
        if (varlikKimligi != null) {
            var varlik = Bukkit.getEntity(varlikKimligi);
            if (varlik != null && varlik.isValid()
                    && oyuncu.getPassengers().contains(varlik)
                    && varlik.getWorld().equals(oyuncu.getWorld())) {
                return; // her sey yolunda
            }
            gorunumKaldir(oyuncu, kategori);
        }
        gorunumKur(oyuncu, kozmetik);
    }

    private void parcacikCal(Player oyuncu, Kozmetik kozmetik) {
        if (!eklenti.getConfig().getBoolean("kozmetik.parcacik-acik", true)) {
            return;
        }
        if (kozmetik.parcacik() == null) {
            return;
        }
        try {
            org.bukkit.Particle parcacik =
                    org.bukkit.Particle.valueOf(kozmetik.parcacik().toUpperCase(Locale.ROOT));
            if (parcacik.getDataType() != Void.class) {
                return; // ek veri isteyen parcaciklari atla
            }
            oyuncu.getWorld().spawnParticle(parcacik,
                    oyuncu.getLocation().add(0, 1.0, 0), 4, 0.25, 0.3, 0.25, 0.01);
        } catch (RuntimeException yoksay) {
            // Bu surumde bulunmayan parcacik adi -> sessizce gec
        }
    }

    public void durdur() {
        if (gorev != null) {
            gorev.cancel();
            gorev = null;
        }
        if (yonGorevi != null) {
            yonGorevi.cancel();
            yonGorevi = null;
        }
    }

    /**
     * Oyuncuya binen ItemDisplay kendi yonunu mount'tan DEVRALMAZ; oyuncu
     * donunce model oldugu yerde kalir ve yanda/onde gorunur. Bu gorev her
     * tick modelin yonunu oyuncunun govde yonune esitler.
     */
    private void yonGoreviBaslat() {
        yonGorevi = Bukkit.getScheduler().runTaskTimer(eklenti, () -> {
            for (Map.Entry<UUID, Map<Kozmetik.Kategori, UUID>> giris : gorunumler.entrySet()) {
                Player oyuncu = Bukkit.getPlayer(giris.getKey());
                if (oyuncu == null || !oyuncu.isOnline()) {
                    continue;
                }
                float yon = govdeYonu(oyuncu);
                for (UUID varlikKimligi : giris.getValue().values()) {
                    var varlik = Bukkit.getEntity(varlikKimligi);
                    if (varlik == null || !varlik.isValid()) {
                        continue;
                    }
                    if (Math.abs(varlik.getLocation().getYaw() - yon) > 0.6f) {
                        varlik.setRotation(yon, 0f);
                    }
                }
                animasyonIlerlet(oyuncu);
            }
        }, 1L, 1L);
    }

    /**
     * Kanat carpma / pelerin savrulma animasyonu.
     *
     * Hiz arttikca kare degistirme araligi kisalir; oyuncu dururken kanatlar
     * yavasca dinlenme karesine doner. Kareler resourcepack'teki ayri
     * modellerdir, ItemDisplay'in esyasi degistirilerek gecis yapilir.
     */
    private void animasyonIlerlet(Player oyuncu) {
        if (!eklenti.getConfig().getBoolean("kozmetik.animasyon-acik", true)) {
            return;
        }
        Map<Kozmetik.Kategori, Kozmetik> takili = takililar.get(oyuncu.getUniqueId());
        Map<Kozmetik.Kategori, UUID> ekranlar = gorunumler.get(oyuncu.getUniqueId());
        if (takili == null || ekranlar == null) {
            return;
        }

        UUID kimlik = oyuncu.getUniqueId();
        Location simdi = oyuncu.getLocation();
        Location onceki = sonKonum.put(kimlik, simdi.clone());

        double hiz = 0.0;
        if (onceki != null && onceki.getWorld() != null
                && onceki.getWorld().equals(simdi.getWorld())) {
            hiz = onceki.distance(simdi);
        }
        boolean havada = !oyuncu.isOnGround();
        // Havadayken kanatlar her zaman calisir (suzulme hissi)
        double etki = havada ? Math.max(hiz, 0.16) : hiz;

        double carpan = eklenti.getConfig().getDouble("kozmetik.animasyon-hizi", 1.0);
        double artis = etki * 2.2 * carpan;
        if (artis < 0.02) {
            // Duruyor -> dinlenme karesine don
            for (Map.Entry<Kozmetik.Kategori, UUID> giris : ekranlar.entrySet()) {
                kareUygula(oyuncu, giris.getKey(), takili.get(giris.getKey()),
                        giris.getValue(), 0);
            }
            animSayaci.remove(kimlik);
            return;
        }

        double ilerleme = animSayaci.getOrDefault(kimlik, 0.0) + artis;
        animSayaci.put(kimlik, ilerleme);

        for (Map.Entry<Kozmetik.Kategori, UUID> giris : ekranlar.entrySet()) {
            Kozmetik kozmetik = takili.get(giris.getKey());
            if (kozmetik == null) {
                continue;
            }
            int toplam = kozmetik.kategori().kareSayisi();
            if (toplam <= 1) {
                continue;
            }
            int kare = (int) (ilerleme % toplam);
            kareUygula(oyuncu, giris.getKey(), kozmetik, giris.getValue(), kare);
        }
    }

    /** Gosterilen kare degistiyse ItemDisplay'in esyasini gunceller. */
    private void kareUygula(Player oyuncu, Kozmetik.Kategori kategori, Kozmetik kozmetik,
                            UUID varlikKimligi, int kare) {
        if (kozmetik == null) {
            return;
        }
        Map<Kozmetik.Kategori, Integer> harita =
                kareler.computeIfAbsent(oyuncu.getUniqueId(),
                        k -> new EnumMap<>(Kozmetik.Kategori.class));
        Integer mevcut = harita.get(kategori);
        if (mevcut != null && mevcut == kare) {
            return;   // zaten bu karede, bosuna paket gonderme
        }
        var varlik = Bukkit.getEntity(varlikKimligi);
        if (!(varlik instanceof ItemDisplay ekran) || !ekran.isValid()) {
            return;
        }
        ekran.setItemStack(kareEsyasi(kozmetik, kare));
        harita.put(kategori, kare);
    }

    // ------------------------------------------------------------------
    //  KOSTUM: zirh gorunumu
    // ------------------------------------------------------------------

    /**
     * Kostumu oyuncunun UZERINDEKI zirha uygular. Zirhin istatistikleri
     * degismez, yalnizca equippable bileseninin model anahtari degisir; boylece
     * kostum kol, bacak ve govde dahil tum sette gorunur.
     *
     * Orijinal gorunum esyanin PersistentDataContainer'ina yazilir, kostum
     * cikarilinca oradan geri yuklenir.
     */
    private void kostumUygula(Player oyuncu, Kozmetik kozmetik) {
        String anahtarMetni = eklenti.getConfig().getString(
                "kozmetik.gorunum." + kozmetik.kod() + ".zirh-deseni");
        if (anahtarMetni == null || anahtarMetni.isBlank()) {
            return;
        }
        NamespacedKey desen = NamespacedKey.fromString(anahtarMetni.toLowerCase(Locale.ROOT));
        if (desen == null) {
            eklenti.getLogger().warning("Gecersiz zirh deseni: " + anahtarMetni);
            return;
        }
        int islenen = 0;
        for (EquipmentSlot slot : ZIRH_SLOTLARI) {
            ItemStack parca = oyuncu.getInventory().getItem(slot);
            if (parca == null || parca.getType().isAir()) {
                continue;
            }
            if (zirhDeseniYaz(parca, desen)) {
                islenen++;
                oyuncu.getInventory().setItem(slot, parca);
            }
        }
        if (islenen == 0) {
            // Kostum zirhin gorunumu oldugu icin ciplakken gorunmez
            com.sinifsistemi.Mesaj.gonder(oyuncu, "kozmetik-zirh-gerekli");
        }
    }

    /** Kostum cikarilinca zirhin eski gorunumunu geri yukler. */
    private void kostumGeriAl(Player oyuncu) {
        for (EquipmentSlot slot : ZIRH_SLOTLARI) {
            ItemStack parca = oyuncu.getInventory().getItem(slot);
            if (parca == null || parca.getType().isAir()) {
                continue;
            }
            if (zirhDeseniGeriAl(parca)) {
                oyuncu.getInventory().setItem(slot, parca);
            }
        }
    }

    private static final EquipmentSlot[] ZIRH_SLOTLARI = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private boolean zirhDeseniYaz(ItemStack parca, NamespacedKey desen) {
        try {
            ItemMeta meta = parca.getItemMeta();
            if (meta == null) {
                return false;
            }
            Object bilesen = meta.getClass().getMethod("getEquippable").invoke(meta);
            if (bilesen == null) {
                return false;   // giyilebilir degil -> dokunma
            }
            Object eski = bilesen.getClass().getMethod("getModel").invoke(bilesen);

            PersistentDataContainer kap = meta.getPersistentDataContainer();
            NamespacedKey saklama = anahtar(ESKI_MODEL);
            if (!kap.has(saklama, PersistentDataType.STRING)) {
                // Ilk kez degistiriliyor -> orijinali sakla ("" = model yoktu)
                kap.set(saklama, PersistentDataType.STRING,
                        eski == null ? "" : eski.toString());
            }

            bilesen.getClass().getMethod("setModel", NamespacedKey.class).invoke(bilesen, desen);
            if (!bileseniYaz(meta, bilesen)) {
                return false;
            }
            parca.setItemMeta(meta);
            return true;
        } catch (ReflectiveOperationException | RuntimeException hata) {
            eklenti.getLogger().warning("Kostum zirha uygulanamadi: " + hata.getMessage());
            return false;
        }
    }

    private boolean zirhDeseniGeriAl(ItemStack parca) {
        try {
            ItemMeta meta = parca.getItemMeta();
            if (meta == null) {
                return false;
            }
            PersistentDataContainer kap = meta.getPersistentDataContainer();
            NamespacedKey saklama = anahtar(ESKI_MODEL);
            if (!kap.has(saklama, PersistentDataType.STRING)) {
                return false;   // bu parca hic degistirilmemis
            }
            String eski = kap.get(saklama, PersistentDataType.STRING);
            kap.remove(saklama);

            Object bilesen = meta.getClass().getMethod("getEquippable").invoke(meta);
            if (bilesen != null) {
                NamespacedKey geri = (eski == null || eski.isBlank())
                        ? null : NamespacedKey.fromString(eski);
                bilesen.getClass().getMethod("setModel", NamespacedKey.class).invoke(bilesen, geri);
                bileseniYaz(meta, bilesen);
            }
            parca.setItemMeta(meta);
            return true;
        } catch (ReflectiveOperationException | RuntimeException hata) {
            eklenti.getLogger().warning("Kostum geri alinamadi: " + hata.getMessage());
            return false;
        }
    }

    /**
     * setEquippable'in parametre tipi surumden surume degisebildigi icin
     * metot, adiyla ve parametre sayisiyla aranir.
     */
    private boolean bileseniYaz(ItemMeta meta, Object bilesen) {
        for (java.lang.reflect.Method metot : meta.getClass().getMethods()) {
            if (!metot.getName().equals("setEquippable") || metot.getParameterCount() != 1) {
                continue;
            }
            if (!metot.getParameterTypes()[0].isInstance(bilesen)) {
                continue;
            }
            try {
                metot.invoke(meta, bilesen);
                return true;
            } catch (ReflectiveOperationException | RuntimeException yoksay) {
                return false;
            }
        }
        return false;
    }

    /** Oyuncu zirh degistirdiginde yeni parcaya da kostumu isler. */
    public void zirhDegisti(Player oyuncu) {
        Kozmetik kostum = takili(oyuncu, Kozmetik.Kategori.KOSTUM);
        if (kostum != null) {
            kostumUygula(oyuncu, kostum);
        }
    }

    /**
     * Oyuncunun GOVDE yonu. Bas yonu kullanilirsa kanatlar saga sola bakinca
     * savruluyor; Paper'da getBodyYaw varsa o tercih edilir.
     */
    private float govdeYonu(Player oyuncu) {
        try {
            Object deger = oyuncu.getClass().getMethod("getBodyYaw").invoke(oyuncu);
            if (deger instanceof Float f) {
                return f;
            }
        } catch (ReflectiveOperationException | RuntimeException yoksay) {
            // Bu surumde yok -> bas yonuna dus
        }
        return oyuncu.getLocation().getYaw();
    }

    /** Sunucu kapanirken / oyuncu cikarken artik varlik birakmamak icin. */
    public void hepsiniTemizle() {
        for (Player oyuncu : Bukkit.getOnlinePlayers()) {
            gorunumleriKaldir(oyuncu);
            tumGucleriKaldir(oyuncu);
            kostumGeriAl(oyuncu);
        }
        gorunumler.clear();
        kareler.clear();
        animSayaci.clear();
        sonKonum.clear();
    }

    // ------------------------------------------------------------------
    //  Guc (attribute)
    // ------------------------------------------------------------------

    private void gucVer(Player oyuncu, Kozmetik kozmetik) {
        Kozmetik.Bonus bonus = kozmetik.bonus();
        String ek = kozmetik.kategori().kod();

        ekle(oyuncu, MAX_CAN, "can_" + ek, bonus.maxCan(), AttributeModifier.Operation.ADD_NUMBER);
        ekle(oyuncu, HAREKET_HIZI, "hiz_" + ek, bonus.hizYuzde(), AttributeModifier.Operation.ADD_SCALAR);
        ekle(oyuncu, ZIRH, "zirh_" + ek, bonus.zirh(), AttributeModifier.Operation.ADD_NUMBER);
        ekle(oyuncu, ZIRH_SAGLAMLIGI, "saglamlik_" + ek, bonus.zirhSaglamlik(), AttributeModifier.Operation.ADD_NUMBER);
        ekle(oyuncu, GERI_TEPME_DIRENCI, "tepme_" + ek, bonus.geriTepme(), AttributeModifier.Operation.ADD_NUMBER);
        ekle(oyuncu, SALDIRI_HASARI, "hasar_" + ek, bonus.saldiriHasari(), AttributeModifier.Operation.ADD_NUMBER);
    }

    private void gucKaldir(Player oyuncu, Kozmetik kozmetik) {
        String ek = kozmetik.kategori().kod();
        kaldir(oyuncu, MAX_CAN, "can_" + ek);
        kaldir(oyuncu, HAREKET_HIZI, "hiz_" + ek);
        kaldir(oyuncu, ZIRH, "zirh_" + ek);
        kaldir(oyuncu, ZIRH_SAGLAMLIGI, "saglamlik_" + ek);
        kaldir(oyuncu, GERI_TEPME_DIRENCI, "tepme_" + ek);
        kaldir(oyuncu, SALDIRI_HASARI, "hasar_" + ek);
        canDuzelt(oyuncu);
    }

    /** Oyuncudaki TUM kozmetik_ modifier'larini siler (sinif yeteneklerine dokunmaz). */
    public void tumGucleriKaldir(Player oyuncu) {
        Attribute[] hepsi = {MAX_CAN, HAREKET_HIZI, ZIRH, ZIRH_SAGLAMLIGI,
                GERI_TEPME_DIRENCI, SALDIRI_HASARI};
        Set<String> silinen = new HashSet<>();
        for (Attribute attribute : hepsi) {
            if (attribute == null) {
                continue;
            }
            AttributeInstance ornek = oyuncu.getAttribute(attribute);
            if (ornek == null) {
                continue;
            }
            for (AttributeModifier mod : new ArrayList<>(ornek.getModifiers())) {
                NamespacedKey k = mod.getKey();
                if (k != null && k.getNamespace().equals(anahtar("x").getNamespace())
                        && k.getKey().startsWith("kozmetik_")) {
                    ornek.removeModifier(mod);
                    silinen.add(k.getKey());
                }
            }
        }
        if (!silinen.isEmpty()) {
            canDuzelt(oyuncu);
        }
    }

    private void ekle(Player oyuncu, Attribute attribute, String ad, double miktar,
                      AttributeModifier.Operation islem) {
        if (attribute == null || miktar == 0) {
            return;
        }
        try {
            AttributeInstance ornek = oyuncu.getAttribute(attribute);
            if (ornek == null) {
                return;
            }
            NamespacedKey k = anahtar(ad);
            for (AttributeModifier mevcut : new ArrayList<>(ornek.getModifiers())) {
                if (k.equals(mevcut.getKey())) {
                    ornek.removeModifier(mevcut);
                }
            }
            ornek.addModifier(new AttributeModifier(k, miktar, islem, EquipmentSlotGroup.ANY));
        } catch (RuntimeException hata) {
            eklenti.getLogger().warning("Kozmetik attribute eklenemedi (" + ad + "): " + hata.getMessage());
        }
    }

    private void kaldir(Player oyuncu, Attribute attribute, String ad) {
        if (attribute == null) {
            return;
        }
        try {
            AttributeInstance ornek = oyuncu.getAttribute(attribute);
            if (ornek == null) {
                return;
            }
            NamespacedKey k = anahtar(ad);
            for (AttributeModifier mod : new ArrayList<>(ornek.getModifiers())) {
                if (k.equals(mod.getKey())) {
                    ornek.removeModifier(mod);
                }
            }
        } catch (RuntimeException yoksay) {
            // gec
        }
    }

    /** Max can dustuyse mevcut cani tasirmamak icin kirpar. */
    private void canDuzelt(Player oyuncu) {
        try {
            if (MAX_CAN == null) {
                return;
            }
            AttributeInstance ornek = oyuncu.getAttribute(MAX_CAN);
            if (ornek != null && oyuncu.getHealth() > ornek.getValue()) {
                oyuncu.setHealth(Math.max(1.0, ornek.getValue()));
            }
        } catch (RuntimeException yoksay) {
            // gec
        }
    }

    // ------------------------------------------------------------------
    //  Yardimcilar
    // ------------------------------------------------------------------

    private Material materyalGetir(String ad, Material varsayilan) {
        if (ad == null || ad.isBlank()) {
            return varsayilan;
        }
        Material materyal = Material.matchMaterial(ad.toUpperCase(Locale.ROOT));
        return materyal == null ? varsayilan : materyal;
    }

    /** ItemMeta#setItemModel surum farkliliklarina karsi reflection ile cagrilir. */
    private void itemModelAyarla(ItemMeta meta, String anahtarMetni) {
        try {
            NamespacedKey k = NamespacedKey.fromString(anahtarMetni.toLowerCase(Locale.ROOT));
            if (k == null) {
                return;
            }
            meta.getClass().getMethod("setItemModel", NamespacedKey.class).invoke(meta, k);
        } catch (ReflectiveOperationException | RuntimeException yoksay) {
            // Bu surumde item-model bilesenin yok -> model-verisi kullanilsin
        }
    }

    /** setCustomModelData(Integer) surumden bagimsiz cagrilir. */
    private void modelVerisiAyarla(ItemMeta meta, int deger) {
        try {
            meta.getClass().getMethod("setCustomModelData", Integer.class).invoke(meta, deger);
        } catch (ReflectiveOperationException | RuntimeException yoksay) {
            // gec
        }
    }
}
