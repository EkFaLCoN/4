package com.sinifsistemi.kozmetik;

import org.bukkit.Material;
import org.bukkit.potion.PotionEffectType;

import java.util.Locale;

/**
 * Takilabilir kozmetikler. Her biri bir kategoriye (kanat / pelerin / kostum)
 * aittir ve oyuncuya hem gorsel bir ItemDisplay hem de pasif guc kazandirir.
 *
 * Ayni kategoriden ayni anda yalnizca BIR kozmetik takilabilir.
 */
public enum Kozmetik {

    // ---------------- KANATLAR ----------------
    ALEV_KANATLARI(Kategori.KANAT, "<red><bold>Alev Kanatları", Material.BLAZE_ROD, Material.BLAZE_ROD,
            new String[]{
                    "<gray>Nether'ın küllerinden örülmüş,",
                    "<gray>sırtında için için yanan kanatlar."
            },
            new Bonus(0, 0, 1.0, 0, 0, 1.0, null),
            "FLAME"),

    MELEK_KANATLARI(Kategori.KANAT, "<white><bold>Melek Kanatları", Material.FEATHER, Material.FEATHER,
            new String[]{
                    "<gray>Bembeyaz tüyler seni yere",
                    "<gray>hiçbir zaman sert bırakmaz."
            },
            new Bonus(2.0, 0, 0, 0, 0, 0, PotionEffectType.SLOW_FALLING),
            "END_ROD"),

    GOLGE_KANATLARI(Kategori.KANAT, "<dark_purple><bold>Gölge Kanatları", Material.PHANTOM_MEMBRANE, Material.PHANTOM_MEMBRANE,
            new String[]{
                    "<gray>Karanlıktan dokunmuş kanatlar;",
                    "<gray>adımlarını hafifletir."
            },
            new Bonus(0, 0.08, 0, 0, 0, 0.5, null),
            "SMOKE"),

    // ---------------- PELERİNLER ----------------
    KANLI_PELERIN(Kategori.PELERIN, "<dark_red><bold>Kanlı Pelerin", Material.RED_BANNER, Material.RED_BANNER,
            new String[]{
                    "<gray>Kurumuş kan lekeleriyle dolu,",
                    "<gray>savaş alanından çıkma bir pelerin."
            },
            new Bonus(0, 0, 0, 0, 0, 1.0, null),
            "CRIMSON_SPORE"),

    KUTSAL_PELERIN(Kategori.PELERIN, "<gold><bold>Kutsal Pelerin", Material.WHITE_BANNER, Material.WHITE_BANNER,
            new String[]{
                    "<gray>Üzerine işlenen dualar",
                    "<gray>darbeleri hafifletir."
            },
            new Bonus(0, 0, 2.0, 1.0, 0, 0, null),
            "HAPPY_VILLAGER"),

    RUZGAR_PELERINI(Kategori.PELERIN, "<aqua><bold>Rüzgâr Pelerini", Material.LIGHT_BLUE_BANNER, Material.LIGHT_BLUE_BANNER,
            new String[]{
                    "<gray>Sürekli dalgalanır ve seni",
                    "<gray>arkandan iter gibi hissettirir."
            },
            new Bonus(0, 0.10, 0, 0, 0, 0, null),
            "CLOUD"),

    // ---------------- KOSTÜMLER ----------------
    BUZ_KOSTUMU(Kategori.KOSTUM, "<blue><bold>Buz Kostümü", Material.BLUE_ICE, Material.BLUE_ICE,
            new String[]{
                    "<gray>Donmuş plakalar seni",
                    "<gray>yerinden oynatılamaz kılar."
            },
            new Bonus(0, 0, 1.0, 0, 0.20, 0, null),
            "SNOWFLAKE"),

    EJDERHA_KOSTUMU(Kategori.KOSTUM, "<dark_green><bold>Ejderha Kostümü", Material.DRAGON_HEAD, Material.DRAGON_HEAD,
            new String[]{
                    "<gray>Pullu zırh; dayanıklılığını",
                    "<gray>gözle görülür şekilde artırır."
            },
            new Bonus(4.0, 0, 1.0, 0, 0, 0, null),
            "DRAGON_BREATH"),

    DERIN_DENIZ_KOSTUMU(Kategori.KOSTUM, "<dark_aqua><bold>Derin Deniz Kostümü", Material.NAUTILUS_SHELL, Material.NAUTILUS_SHELL,
            new String[]{
                    "<gray>Su altında evindeymiş gibi",
                    "<gray>nefes alır ve görürsün."
            },
            new Bonus(0, 0.05, 0, 0, 0, 0, PotionEffectType.CONDUIT_POWER),
            "BUBBLE_POP");

    /** Kozmetik kategorileri. Her kategoriden tek parca takilabilir. */
    public enum Kategori {
        /** Sirta binen ItemDisplay olarak cizilir, animasyon karesi vardir. */
        KANAT("<light_purple><bold>Kanatlar", Material.FEATHER, 4),
        PELERIN("<gold><bold>Pelerinler", Material.RED_BANNER, 3),
        /**
         * ItemDisplay DEGIL: oyuncunun giydigi zirhin equippable gorunumunu
         * degistirir, boylece kol/bacak/govde dahil tum sete uygulanir.
         */
        KOSTUM("<aqua><bold>Kostümler", Material.LEATHER_CHESTPLATE, 0);

        private final String renkliAd;
        private final Material ikon;
        private final int kareSayisi;

        Kategori(String renkliAd, Material ikon, int kareSayisi) {
            this.renkliAd = renkliAd;
            this.ikon = ikon;
            this.kareSayisi = kareSayisi;
        }

        /** Animasyon kare sayisi. 0 -> bu kategori ItemDisplay kullanmaz. */
        public int kareSayisi() {
            return kareSayisi;
        }

        /** Zirh katmani olarak mi cizilir? */
        public boolean zirhKatmani() {
            return this == KOSTUM;
        }

        public String renkliAd() {
            return renkliAd;
        }

        public Material ikon() {
            return ikon;
        }

        public String kod() {
            return name().toLowerCase(Locale.ROOT);
        }

        public static Kategori bul(String kod) {
            if (kod == null) {
                return null;
            }
            for (Kategori k : values()) {
                if (k.kod().equalsIgnoreCase(kod)) {
                    return k;
                }
            }
            return null;
        }
    }

    /**
     * Pasif guc degerleri.
     *
     * @param maxCan        ham can puani (2.0 = 1 kalp)
     * @param hizYuzde      hareket hizi orani (0.10 = %10)
     * @param zirh          ham zirh puani
     * @param zirhSaglamlik ham zirh saglamligi
     * @param geriTepme     geri tepme direnci (0.0 - 1.0)
     * @param saldiriHasari ham saldiri hasari
     * @param surekliEtki   surekli uygulanan iksir etkisi (yoksa null)
     */
    public record Bonus(double maxCan, double hizYuzde, double zirh, double zirhSaglamlik,
                        double geriTepme, double saldiriHasari, PotionEffectType surekliEtki) {
    }

    private final Kategori kategori;
    private final String renkliAd;
    private final Material ikon;
    private final Material varsayilanModel;
    private final String[] aciklama;
    private final Bonus bonus;
    private final String parcacik;

    Kozmetik(Kategori kategori, String renkliAd, Material ikon, Material varsayilanModel,
             String[] aciklama, Bonus bonus, String parcacik) {
        this.kategori = kategori;
        this.renkliAd = renkliAd;
        this.ikon = ikon;
        this.varsayilanModel = varsayilanModel;
        this.aciklama = aciklama;
        this.bonus = bonus;
        this.parcacik = parcacik;
    }

    public Kategori kategori() {
        return kategori;
    }

    public String renkliAd() {
        return renkliAd;
    }

    /** Renk kodlarindan arindirilmis, bold'suz ad (mesajlarda kullanilir). */
    public String basitRenkliAd() {
        return renkliAd.replace("<bold>", "");
    }

    public Material ikon() {
        return ikon;
    }

    public Material varsayilanModel() {
        return varsayilanModel;
    }

    public String[] aciklama() {
        return aciklama;
    }

    public Bonus bonus() {
        return bonus;
    }

    public String parcacik() {
        return parcacik;
    }

    public String kod() {
        return name().toLowerCase(Locale.ROOT);
    }

    /** Menu ve lore icin okunabilir guc satirlari uretir. */
    public java.util.List<String> gucSatirlari() {
        java.util.List<String> satirlar = new java.util.ArrayList<>();
        if (bonus.maxCan() != 0) {
            satirlar.add("<green>+ <white>" + bicim(bonus.maxCan() / 2.0) + " kalp <gray>can");
        }
        if (bonus.hizYuzde() != 0) {
            satirlar.add("<green>+ <white>%" + bicim(bonus.hizYuzde() * 100) + " <gray>hareket hızı");
        }
        if (bonus.zirh() != 0) {
            satirlar.add("<green>+ <white>" + bicim(bonus.zirh()) + " <gray>zırh");
        }
        if (bonus.zirhSaglamlik() != 0) {
            satirlar.add("<green>+ <white>" + bicim(bonus.zirhSaglamlik()) + " <gray>zırh sağlamlığı");
        }
        if (bonus.geriTepme() != 0) {
            satirlar.add("<green>+ <white>%" + bicim(bonus.geriTepme() * 100) + " <gray>geri tepme direnci");
        }
        if (bonus.saldiriHasari() != 0) {
            satirlar.add("<green>+ <white>" + bicim(bonus.saldiriHasari()) + " <gray>saldırı hasarı");
        }
        if (bonus.surekliEtki() != null) {
            satirlar.add("<green>+ <gray>Sürekli etki: <white>" + etkiAdi(bonus.surekliEtki()));
        }
        if (satirlar.isEmpty()) {
            satirlar.add("<dark_gray>Yalnızca görünüm");
        }
        return satirlar;
    }

    private static String etkiAdi(PotionEffectType tur) {
        String ad = tur.getKey().getKey();
        return switch (ad) {
            case "slow_falling" -> "Yavaş Düşüş";
            case "conduit_power" -> "Su Altı Ustalığı";
            case "night_vision" -> "Gece Görüşü";
            default -> ad;
        };
    }

    private static String bicim(double deger) {
        if (deger == Math.floor(deger)) {
            return String.valueOf((int) deger);
        }
        return String.valueOf(deger).replace('.', ',');
    }

    public static Kozmetik bul(String kod) {
        if (kod == null) {
            return null;
        }
        for (Kozmetik k : values()) {
            if (k.kod().equalsIgnoreCase(kod)) {
                return k;
            }
        }
        return null;
    }
}
